"""
HTML 대시보드 생성기
인터랙티브 200종목 전광판 + 컨플루언스 히트맵
"""
import json
from datetime import datetime

def generate_dashboard(results, output_path):
    """분석 결과를 인터랙티브 HTML 대시보드로 생성"""
    
    # JSON 직렬화 (NaN/Inf 처리)
    def clean_for_json(obj):
        if isinstance(obj, float):
            if obj != obj or obj == float('inf') or obj == float('-inf'):
                return None
            return round(obj, 4)
        if isinstance(obj, dict):
            return {k: clean_for_json(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [clean_for_json(i) for i in obj]
        return obj
    
    results_json = json.dumps(clean_for_json(results), ensure_ascii=False)
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
    total_count = len(results)
    
    strong_buy = len([r for r in results if r['total_score'] >= 2 and r['total_direction'] == '매수'])
    strong_sell = len([r for r in results if r['total_score'] >= 2 and r['total_direction'] == '매도'])
    neutral = total_count - strong_buy - strong_sell
    
    html = f'''<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>멀티팩터 × 멀티타임프레임 대시보드</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Noto+Sans+KR:wght@300;400;500;700;900&display=swap');

:root {{
  --bg-primary: #0a0e17;
  --bg-card: #111827;
  --bg-card-hover: #1a2332;
  --border: #1e293b;
  --text-primary: #e2e8f0;
  --text-secondary: #94a3b8;
  --text-muted: #64748b;
  --green: #22c55e;
  --green-bg: rgba(34,197,94,0.12);
  --red: #ef4444;
  --red-bg: rgba(239,68,68,0.12);
  --yellow: #f59e0b;
  --yellow-bg: rgba(245,158,11,0.12);
  --blue: #3b82f6;
  --blue-bg: rgba(59,130,246,0.12);
  --purple: #a855f7;
  --cyan: #06b6d4;
}}

* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{
  font-family: 'Noto Sans KR', sans-serif;
  background: var(--bg-primary);
  color: var(--text-primary);
  min-height: 100vh;
}}

.header {{
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
  border-bottom: 1px solid var(--border);
  padding: 24px 32px;
  position: sticky; top: 0; z-index: 100;
  backdrop-filter: blur(20px);
}}
.header-inner {{
  max-width: 1600px; margin: 0 auto;
  display: flex; justify-content: space-between; align-items: center;
}}
.header h1 {{
  font-size: 20px; font-weight: 900;
  background: linear-gradient(135deg, #818cf8, #c084fc, #f472b6);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  letter-spacing: -0.5px;
}}
.header-meta {{
  display: flex; gap: 24px; align-items: center;
  font-family: 'JetBrains Mono', monospace; font-size: 12px;
  color: var(--text-muted);
}}

.stats-bar {{
  max-width: 1600px; margin: 0 auto;
  padding: 16px 32px;
  display: flex; gap: 12px; flex-wrap: wrap;
}}
.stat-chip {{
  display: flex; align-items: center; gap: 8px;
  padding: 8px 16px; border-radius: 8px;
  font-size: 13px; font-weight: 500;
  border: 1px solid var(--border);
  background: var(--bg-card);
}}
.stat-chip .num {{ font-family: 'JetBrains Mono', monospace; font-weight: 700; font-size: 16px; }}
.stat-chip.buy {{ border-color: var(--green); color: var(--green); background: var(--green-bg); }}
.stat-chip.sell {{ border-color: var(--red); color: var(--red); background: var(--red-bg); }}
.stat-chip.neutral {{ border-color: var(--text-muted); }}

.controls {{
  max-width: 1600px; margin: 0 auto;
  padding: 12px 32px;
  display: flex; gap: 10px; flex-wrap: wrap; align-items: center;
}}
.control-btn {{
  padding: 6px 14px; border-radius: 6px;
  border: 1px solid var(--border);
  background: var(--bg-card);
  color: var(--text-secondary);
  cursor: pointer; font-size: 12px; font-weight: 500;
  transition: all 0.15s;
  font-family: 'Noto Sans KR', sans-serif;
}}
.control-btn:hover {{ background: var(--bg-card-hover); color: var(--text-primary); }}
.control-btn.active {{ background: var(--blue-bg); border-color: var(--blue); color: var(--blue); }}
.search-input {{
  padding: 6px 14px; border-radius: 6px;
  border: 1px solid var(--border);
  background: var(--bg-card);
  color: var(--text-primary);
  font-size: 12px; width: 200px;
  font-family: 'Noto Sans KR', sans-serif;
  outline: none;
}}
.search-input:focus {{ border-color: var(--blue); }}

.table-wrapper {{
  max-width: 1600px; margin: 0 auto;
  padding: 0 32px 32px;
  overflow-x: auto;
}}
table {{
  width: 100%; border-collapse: collapse;
  font-size: 12px;
}}
thead th {{
  position: sticky; top: 72px; z-index: 50;
  background: #0f172a;
  padding: 10px 8px;
  text-align: left;
  font-weight: 600;
  color: var(--text-muted);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  border-bottom: 2px solid var(--border);
  white-space: nowrap;
  cursor: pointer;
  user-select: none;
}}
thead th:hover {{ color: var(--text-primary); }}
thead th.sorted {{ color: var(--cyan); }}

tbody tr {{
  border-bottom: 1px solid rgba(30,41,59,0.5);
  transition: background 0.1s;
  cursor: pointer;
}}
tbody tr:hover {{ background: var(--bg-card-hover); }}
tbody td {{
  padding: 10px 8px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 11.5px;
  white-space: nowrap;
}}

.name-cell {{
  font-family: 'Noto Sans KR', sans-serif;
  font-weight: 500;
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
}}
.sector-tag {{
  display: inline-block;
  padding: 2px 8px; border-radius: 4px;
  font-size: 10px;
  font-family: 'Noto Sans KR', sans-serif;
  font-weight: 400;
  background: rgba(100,116,139,0.15);
  color: var(--text-muted);
}}

.signal {{
  display: inline-flex; align-items: center; justify-content: center;
  width: 44px; height: 24px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 700;
  font-family: 'Noto Sans KR', sans-serif;
}}
.signal.buy {{ background: var(--green-bg); color: var(--green); }}
.signal.sell {{ background: var(--red-bg); color: var(--red); }}
.signal.neutral {{ background: rgba(100,116,139,0.1); color: var(--text-muted); }}

.score-badge {{
  display: inline-flex; align-items: center; justify-content: center;
  width: 32px; height: 24px;
  border-radius: 4px;
  font-weight: 700; font-size: 12px;
}}
.score-3 {{ background: var(--green-bg); color: var(--green); }}
.score-2 {{ background: var(--blue-bg); color: var(--blue); }}
.score-1 {{ background: var(--yellow-bg); color: var(--yellow); }}
.score-0 {{ background: rgba(100,116,139,0.1); color: var(--text-muted); }}

.alignment-tag {{
  font-size: 10px;
  font-family: 'Noto Sans KR', sans-serif;
}}
.alignment-tag.aligned {{ color: var(--green); }}
.alignment-tag.conflict {{ color: var(--red); }}
.alignment-tag.partial {{ color: var(--yellow); }}

.price {{ color: var(--text-primary); }}
.rr {{ font-size: 11px; }}
.rr.good {{ color: var(--green); }}
.rr.ok {{ color: var(--yellow); }}
.rr.bad {{ color: var(--red); }}

.strength {{
  font-size: 10px;
  font-family: 'Noto Sans KR', sans-serif;
}}
.strength.strong-up {{ color: var(--green); }}
.strength.weak-up {{ color: #86efac; }}
.strength.flat {{ color: var(--text-muted); }}
.strength.weak-down {{ color: #fca5a5; }}
.strength.strong-down {{ color: var(--red); }}

/* Detail panel */
.detail-panel {{
  display: none;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 8px;
  margin: 8px 32px;
  padding: 20px;
}}
.detail-panel.open {{ display: block; }}
.detail-grid {{
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}}
.detail-section {{
  background: rgba(15,23,42,0.5);
  border-radius: 6px;
  padding: 14px;
  border: 1px solid var(--border);
}}
.detail-section h3 {{
  font-size: 12px;
  font-weight: 700;
  margin-bottom: 10px;
  color: var(--cyan);
}}
.detail-row {{
  display: flex;
  justify-content: space-between;
  padding: 3px 0;
  font-size: 11px;
}}
.detail-row .label {{ color: var(--text-muted); font-family: 'Noto Sans KR', sans-serif; }}
.detail-row .value {{ font-family: 'JetBrains Mono', monospace; }}

.fund-score {{
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 32px; height: 20px; padding: 0 4px;
  border-radius: 3px; font-size: 11px; font-weight: 600;
}}
.fund-score.high {{ background: var(--green-bg); color: var(--green); }}
.fund-score.mid {{ background: var(--yellow-bg); color: var(--yellow); }}
.fund-score.low {{ background: var(--red-bg); color: var(--red); }}
.fund-score.none {{ background: rgba(100,116,139,0.1); color: var(--text-muted); }}

.total-score-cell {{
  font-weight: 700;
  font-size: 13px;
}}

@media (max-width: 1200px) {{
  .detail-grid {{ grid-template-columns: 1fr; }}
  .controls {{ padding: 12px 16px; }}
  .table-wrapper {{ padding: 0 16px 16px; }}
  .stats-bar {{ padding: 16px 16px; }}
  .header {{ padding: 16px; }}
}}
</style>
</head>
<body>

<div class="header">
  <div class="header-inner">
    <h1>🎯 멀티팩터 × 멀티타임프레임 대시보드</h1>
    <div class="header-meta">
      <span>📅 {timestamp}</span>
      <span>📊 {total_count}종목</span>
    </div>
  </div>
</div>

<div class="stats-bar">
  <div class="stat-chip buy"><span class="num">{strong_buy}</span> 강한 매수</div>
  <div class="stat-chip sell"><span class="num">{strong_sell}</span> 강한 매도</div>
  <div class="stat-chip neutral"><span class="num">{neutral}</span> 중립/관망</div>
</div>

<div class="controls" id="controls">
  <input type="text" class="search-input" id="searchInput" placeholder="🔍 종목명 / 티커 검색..." oninput="filterTable()">
  <button class="control-btn active" data-filter="all" onclick="setSectorFilter('all', this)">전체</button>
</div>

<div class="table-wrapper">
  <table id="mainTable">
    <thead>
      <tr>
        <th onclick="sortTable(0)">#</th>
        <th onclick="sortTable(1)">종목</th>
        <th onclick="sortTable(2)">섹터</th>
        <th onclick="sortTable(3)">현재가</th>
        <th onclick="sortTable(4)">펀더멘탈</th>
        <th onclick="sortTable(5)" style="text-align:center" title="단기 가격구조">S.F1</th>
        <th onclick="sortTable(6)" style="text-align:center" title="단기 거래량">S.F2</th>
        <th onclick="sortTable(7)" style="text-align:center" title="단기 모멘텀">S.F3</th>
        <th onclick="sortTable(8)" style="text-align:center">단기</th>
        <th onclick="sortTable(9)" style="text-align:center" title="중기 가격구조">M.F1</th>
        <th onclick="sortTable(10)" style="text-align:center" title="중기 거래량">M.F2</th>
        <th onclick="sortTable(11)" style="text-align:center" title="중기 모멘텀">M.F3</th>
        <th onclick="sortTable(12)" style="text-align:center">중기</th>
        <th onclick="sortTable(13)" style="text-align:center" title="장기 가격구조">L.F1</th>
        <th onclick="sortTable(14)" style="text-align:center" title="장기 거래량">L.F2</th>
        <th onclick="sortTable(15)" style="text-align:center" title="장기 모멘텀">L.F3</th>
        <th onclick="sortTable(16)" style="text-align:center">장기</th>
        <th onclick="sortTable(17)" style="text-align:center">종합</th>
        <th onclick="sortTable(18)">정렬</th>
        <th onclick="sortTable(19)">추세강도</th>
      </tr>
    </thead>
    <tbody id="tableBody">
    </tbody>
  </table>
</div>

<div id="detailPanel" class="detail-panel"></div>

<script>
const DATA = {results_json};
let currentSort = {{ col: 17, asc: false }};
let sectorFilter = 'all';
let sectors = new Set();

// 섹터 목록 추출
DATA.forEach(d => {{ if(d.sector) sectors.add(d.sector); }});

// 섹터 필터 버튼 생성
const controlsEl = document.getElementById('controls');
[...sectors].sort().forEach(s => {{
  const btn = document.createElement('button');
  btn.className = 'control-btn';
  btn.dataset.filter = s;
  btn.textContent = s;
  btn.onclick = () => setSectorFilter(s, btn);
  controlsEl.appendChild(btn);
}});

function signalHTML(signal) {{
  const cls = signal === '매수' ? 'buy' : signal === '매도' ? 'sell' : 'neutral';
  return `<span class="signal ${{cls}}">${{signal}}</span>`;
}}

function scoreHTML(score) {{
  return `<span class="score-badge score-${{score}}">${{score}}/3</span>`;
}}

function fundScoreHTML(score) {{
  if (!score) return `<span class="fund-score none">-</span>`;
  const cls = score >= 75 ? 'high' : score >= 55 ? 'mid' : 'low';
  return `<span class="fund-score ${{cls}}">${{score}}</span>`;
}}

function alignmentHTML(al) {{
  const cls = al.bonus ? 'aligned' : al.conflict ? 'conflict' : 'partial';
  const text = al.bonus ? '✅정렬' : al.conflict ? '⚠️충돌' : '—';
  return `<span class="alignment-tag ${{cls}}">${{text}}</span>`;
}}

function strengthHTML(s) {{
  if (!s) return '';
  const map = {{
    '강한 상승': 'strong-up',
    '약한 상승': 'weak-up',
    '중립': 'flat',
    '약한 하락': 'weak-down',
    '강한 하락': 'strong-down'
  }};
  return `<span class="strength ${{map[s] || 'flat'}}">${{s}}</span>`;
}}

function formatPrice(price, ticker) {{
  if (!price) return '-';
  const isKR = ticker && ticker.includes('.');
  if (isKR) return '₩' + Math.round(price).toLocaleString();
  return '$' + price.toLocaleString(undefined, {{minimumFractionDigits: 2, maximumFractionDigits: 2}});
}}

function renderTable() {{
  const tbody = document.getElementById('tableBody');
  const search = document.getElementById('searchInput').value.toLowerCase();
  
  let filtered = DATA.filter(d => {{
    if (sectorFilter !== 'all' && d.sector !== sectorFilter) return false;
    if (search) {{
      return d.name.toLowerCase().includes(search) || d.ticker.toLowerCase().includes(search);
    }}
    return true;
  }});
  
  // 정렬
  filtered.sort((a, b) => {{
    let va, vb;
    switch(currentSort.col) {{
      case 1: va = a.name; vb = b.name; break;
      case 2: va = a.sector; vb = b.sector; break;
      case 3: va = a.current_price; vb = b.current_price; break;
      case 4: va = a.fundamental_score||0; vb = b.fundamental_score||0; break;
      case 5: va = a.short_term.f1.signal; vb = b.short_term.f1.signal; break;
      case 8: va = a.short_term.score; vb = b.short_term.score; break;
      case 12: va = a.mid_term.score; vb = b.mid_term.score; break;
      case 16: va = a.long_term.score; vb = b.long_term.score; break;
      case 17: va = a.total_score; vb = b.total_score; break;
      default: va = a.total_score; vb = b.total_score;
    }}
    if (typeof va === 'string') return currentSort.asc ? va.localeCompare(vb) : vb.localeCompare(va);
    return currentSort.asc ? (va||0) - (vb||0) : (vb||0) - (va||0);
  }});
  
  tbody.innerHTML = filtered.map((d, i) => `
    <tr onclick="toggleDetail('${{d.ticker}}')" data-ticker="${{d.ticker}}">
      <td style="color:var(--text-muted)">${{i+1}}</td>
      <td class="name-cell" title="${{d.ticker}}">${{d.name}}</td>
      <td><span class="sector-tag">${{d.sector}}</span></td>
      <td class="price">${{formatPrice(d.current_price, d.ticker)}}</td>
      <td>${{fundScoreHTML(d.fundamental_score)}}</td>
      <td style="text-align:center">${{signalHTML(d.short_term.f1.signal)}}</td>
      <td style="text-align:center">${{signalHTML(d.short_term.f2.signal)}}</td>
      <td style="text-align:center">${{signalHTML(d.short_term.f3.signal)}}</td>
      <td style="text-align:center">${{scoreHTML(d.short_term.score)}}</td>
      <td style="text-align:center">${{signalHTML(d.mid_term.f1.signal)}}</td>
      <td style="text-align:center">${{signalHTML(d.mid_term.f2.signal)}}</td>
      <td style="text-align:center">${{signalHTML(d.mid_term.f3.signal)}}</td>
      <td style="text-align:center">${{scoreHTML(d.mid_term.score)}}</td>
      <td style="text-align:center">${{signalHTML(d.long_term.f1.signal)}}</td>
      <td style="text-align:center">${{signalHTML(d.long_term.f2.signal)}}</td>
      <td style="text-align:center">${{signalHTML(d.long_term.f3.signal)}}</td>
      <td style="text-align:center">${{scoreHTML(d.long_term.score)}}</td>
      <td style="text-align:center" class="total-score-cell">${{d.total_score.toFixed(1)}}</td>
      <td>${{alignmentHTML(d.alignment)}}</td>
      <td>${{strengthHTML(d.short_term.f3.trend_strength)}}</td>
    </tr>
  `).join('');
}}

function sortTable(col) {{
  if (currentSort.col === col) currentSort.asc = !currentSort.asc;
  else {{ currentSort.col = col; currentSort.asc = false; }}
  renderTable();
}}

function setSectorFilter(s, btn) {{
  sectorFilter = s;
  document.querySelectorAll('.control-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderTable();
}}

function filterTable() {{ renderTable(); }}

function toggleDetail(ticker) {{
  const panel = document.getElementById('detailPanel');
  const d = DATA.find(x => x.ticker === ticker);
  if (!d) return;
  
  if (panel.dataset.ticker === ticker && panel.classList.contains('open')) {{
    panel.classList.remove('open');
    return;
  }}
  
  panel.dataset.ticker = ticker;
  
  const lev = d.levels || {{}};
  const shortLev = lev.short || {{}};
  const midLev = lev.mid || {{}};
  const longLev = lev.long || {{}};
  
  function fmtP(v) {{ return v ? formatPrice(v, d.ticker) : '-'; }}
  function fmtRR(v) {{ 
    if (!v) return '-';
    const cls = v >= 2 ? 'good' : v >= 1.5 ? 'ok' : 'bad';
    return `<span class="rr ${{cls}}">${{v}}:1</span>`;
  }}
  
  panel.innerHTML = `
    <h2 style="font-size:16px;margin-bottom:16px;font-weight:700">${{d.name}} <span style="color:var(--text-muted);font-weight:400;font-size:13px">${{d.ticker}}</span></h2>
    <div class="detail-grid">
      <div class="detail-section">
        <h3>📈 단기 타점 (일봉) — ${{d.short_term.grade}}</h3>
        <div class="detail-row"><span class="label">추세</span><span class="value">${{d.short_term.f1.trend || '-'}}</span></div>
        <div class="detail-row"><span class="label">RSI(14)</span><span class="value">${{d.short_term.f3.rsi || '-'}}</span></div>
        <div class="detail-row"><span class="label">VWAP</span><span class="value">${{fmtP(d.short_term.f2.vwap)}}</span></div>
        <div class="detail-row"><span class="label">볼린저 하단</span><span class="value">${{fmtP(d.short_term.f3.bb_lower)}}</span></div>
        <hr style="border-color:var(--border);margin:8px 0">
        <div class="detail-row"><span class="label">진입가</span><span class="value">${{fmtP(shortLev.entry)}}</span></div>
        <div class="detail-row"><span class="label">손절가</span><span class="value" style="color:var(--red)">${{fmtP(shortLev.stop)}}</span></div>
        <div class="detail-row"><span class="label">목표가</span><span class="value" style="color:var(--green)">${{fmtP(shortLev.target)}}</span></div>
        <div class="detail-row"><span class="label">손익비</span><span class="value">${{fmtRR(shortLev.rr)}}</span></div>
      </div>
      <div class="detail-section">
        <h3>📊 중기 타점 (주봉) — ${{d.mid_term.grade}}</h3>
        <div class="detail-row"><span class="label">추세</span><span class="value">${{d.mid_term.f1.trend || '-'}}</span></div>
        <div class="detail-row"><span class="label">RSI(14)</span><span class="value">${{d.mid_term.f3.rsi || '-'}}</span></div>
        <div class="detail-row"><span class="label">ADX</span><span class="value">${{d.mid_term.f3.adx || '-'}}</span></div>
        <div class="detail-row"><span class="label">VCP 감지</span><span class="value">${{d.mid_term.f1.vcp?.detected ? '✅' : '—'}}</span></div>
        <div class="detail-row"><span class="label">20주 MA</span><span class="value">${{fmtP(d.mid_term.f1.ma20w)}}</span></div>
        <hr style="border-color:var(--border);margin:8px 0">
        <div class="detail-row"><span class="label">진입가</span><span class="value">${{fmtP(midLev.entry)}}</span></div>
        <div class="detail-row"><span class="label">손절가</span><span class="value" style="color:var(--red)">${{fmtP(midLev.stop)}}</span></div>
        <div class="detail-row"><span class="label">목표가</span><span class="value" style="color:var(--green)">${{fmtP(midLev.target)}}</span></div>
        <div class="detail-row"><span class="label">손익비</span><span class="value">${{fmtRR(midLev.rr)}}</span></div>
      </div>
      <div class="detail-section">
        <h3>🏗️ 장기 타점 (월봉) — ${{d.long_term.grade}}</h3>
        <div class="detail-row"><span class="label">추세</span><span class="value">${{d.long_term.f1.trend || '-'}}</span></div>
        <div class="detail-row"><span class="label">RSI(14)</span><span class="value">${{d.long_term.f3.rsi || '-'}}</span></div>
        <div class="detail-row"><span class="label">역사적 위치</span><span class="value">${{d.long_term.f1.historical_position ? d.long_term.f1.historical_position + '%' : '-'}}</span></div>
        <div class="detail-row"><span class="label">60개월 MA</span><span class="value">${{fmtP(d.long_term.f1.ma60m)}}</span></div>
        <div class="detail-row"><span class="label">역대 고점</span><span class="value">${{fmtP(d.long_term.f1.all_time_high)}}</span></div>
        <hr style="border-color:var(--border);margin:8px 0">
        <div class="detail-row"><span class="label">락바텀 진입가</span><span class="value">${{fmtP(longLev.entry)}}</span></div>
        <div class="detail-row"><span class="label">손절가</span><span class="value" style="color:var(--red)">${{fmtP(longLev.stop)}}</span></div>
        <div class="detail-row"><span class="label">목표가</span><span class="value" style="color:var(--green)">${{fmtP(longLev.target)}}</span></div>
        <div class="detail-row"><span class="label">손익비</span><span class="value">${{fmtRR(longLev.rr)}}</span></div>
      </div>
    </div>
  `;
  
  panel.classList.add('open');
  
  // 패널을 클릭한 행 바로 아래로 이동
  const row = document.querySelector(`tr[data-ticker="${{ticker}}"]`);
  if (row) row.parentNode.insertBefore(document.createElement('tr'), row.nextSibling).replaceWith(panel);
}}

// 초기 렌더
renderTable();
</script>
</body>
</html>'''
    
    import os
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"  ✅ 대시보드 생성 완료: {output_path}")

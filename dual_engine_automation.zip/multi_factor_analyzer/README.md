# 🎯 멀티팩터 × 멀티타임프레임 분석 시스템

200종목을 자동으로 3-Factor × 3-Timeframe 분석하여 컨플루언스 대시보드를 생성합니다.

## 🚀 빠른 시작

### 1. 설치
```bash
pip install yfinance pandas numpy
```

### 2. 실행
```bash
# 전체 200종목 분석 (약 15~20분 소요)
python main.py --mode all

# 미국 주식만 (약 8분)
python main.py --mode us

# 한국 주식만 (약 7분)
python main.py --mode kr

# 테스트: 10종목만
python main.py --mode us --limit 10
```

### 3. 결과 확인
- `output/dashboard.html` — 브라우저에서 열기
- `output/results.json` — 프로그래밍 활용

---

## 📁 파일 구조

```
multi_factor_analyzer/
├── main.py               # 🏗️ 메인 파이프라인 (이것만 실행하면 됨)
├── config.py             # 📋 200종목 리스트 + 분석 파라미터
├── data_fetcher.py       # 📡 yfinance 데이터 수집 + 캐싱
├── confluence.py         # 🎯 컨플루언스 스코어링 엔진
├── report_generator.py   # 📊 HTML 대시보드 생성기
├── demo_generator.py     # 🧪 데모 데이터 생성 (테스트용)
├── factors/
│   ├── price_structure.py  # Factor 1: 가격구조 (SMC, VCP, 피보나치)
│   ├── volume_profile.py   # Factor 2: 거래량 (VWAP, VP, OBV)
│   └── momentum.py         # Factor 3: 모멘텀 (RSI, MACD, BB, ADX)
├── cache/                  # 데이터 캐시 (자동 생성)
└── output/                 # 결과 파일
    ├── dashboard.html      # 인터랙티브 대시보드
    └── results.json        # 분석 결과 JSON
```

---

## 📊 분석 체계

### 3-Factor × 3-Timeframe 매트릭스

| | Factor 1: 가격구조 | Factor 2: 거래량 | Factor 3: 모멘텀 |
|---|---|---|---|
| **단기** (일봉) | SMC: OB, FVG, BOS/CHoCH | VWAP, 세션 VP | RSI, 스토캐스틱, 볼린저, MACD |
| **중기** (주봉) | VCP + 피보나치 | 고정범위 VP, HVN/LVN | MACD 주봉, RSI, ADX |
| **장기** (월봉) | 다우이론 + 이평선 | 누적 VP, OBV | RSI 월봉, MACD 히스토그램 |

### 컨플루언스 스코어

- **3/3** ⭐ 강한 → 적극 진입
- **2/3** ✅ 보통 → 분할 진입
- **1/3** ⚠️ 약한 → 관망
- **0/3** ❌ 없음 → 진입 금지

---

## ⚙️ 커스터마이징

### 종목 추가/제거
`config.py`에서 딕셔너리에 종목을 추가하세요:

```python
US_STOCKS = {
    "NVDA": {"name": "엔비디아", "sector": "AI반도체", "score": 91.5},
    # 새 종목 추가
    "NEW_TICKER": {"name": "새종목", "sector": "섹터명", "score": 75},
}
```

### 자동 실행 (크론잡)
```bash
# 매일 오전 9시 실행
0 9 * * * cd /path/to/multi_factor_analyzer && python main.py --mode all
```

### Claude API 연동 (선택)
`results.json`을 Claude API에 넘겨 자연어 리포트를 생성할 수 있습니다:

```python
import anthropic
import json

client = anthropic.Anthropic(api_key="your-key")
results = json.load(open("output/results.json"))

# 상위 10종목만 분석 요청
top10 = results[:10]
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=4000,
    messages=[{
        "role": "user",
        "content": f"아래 멀티팩터 분석 결과를 바탕으로 투자 리포트를 작성해주세요:\\n{json.dumps(top10, ensure_ascii=False)}"
    }]
)
```

---

## ⚠️ 면책 조항

이 시스템은 기술적 분석 보조 도구이며, 투자 조언이 아닙니다.
모든 투자 결정은 본인의 판단과 책임 하에 이루어져야 합니다.

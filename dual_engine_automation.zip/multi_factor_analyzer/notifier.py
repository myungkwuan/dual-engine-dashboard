#!/usr/bin/env python3
"""
알림 시스템 — 텔레그램 + 슬랙 + 이메일 알림
분석 결과를 자동으로 전송합니다.
"""
import os
import json
import urllib.request
import urllib.parse
from datetime import datetime

# ============================================================
# 설정 로드
# ============================================================
def load_config():
    """환경변수 또는 .env 파일에서 설정 로드"""
    config = {
        'telegram_token': os.environ.get('TELEGRAM_BOT_TOKEN', ''),
        'telegram_chat_id': os.environ.get('TELEGRAM_CHAT_ID', ''),
        'slack_webhook': os.environ.get('SLACK_WEBHOOK_URL', ''),
        'enable_telegram': os.environ.get('ENABLE_TELEGRAM', 'true').lower() == 'true',
        'enable_slack': os.environ.get('ENABLE_SLACK', 'false').lower() == 'true',
    }
    
    # .env 파일이 있으면 로드
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, val = line.split('=', 1)
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    os.environ[key] = val
        # 재로드
        config['telegram_token'] = os.environ.get('TELEGRAM_BOT_TOKEN', config['telegram_token'])
        config['telegram_chat_id'] = os.environ.get('TELEGRAM_CHAT_ID', config['telegram_chat_id'])
        config['slack_webhook'] = os.environ.get('SLACK_WEBHOOK_URL', config['slack_webhook'])
        config['enable_telegram'] = os.environ.get('ENABLE_TELEGRAM', 'true').lower() == 'true'
        config['enable_slack'] = os.environ.get('ENABLE_SLACK', 'false').lower() == 'true'
    
    return config


# ============================================================
# 텔레그램 알림
# ============================================================
def send_telegram(token, chat_id, message, parse_mode='HTML'):
    """텔레그램 봇으로 메시지 전송"""
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    
    # 텔레그램 메시지 길이 제한 (4096자)
    chunks = []
    if len(message) > 4000:
        lines = message.split('\n')
        chunk = ''
        for line in lines:
            if len(chunk) + len(line) + 1 > 4000:
                chunks.append(chunk)
                chunk = line + '\n'
            else:
                chunk += line + '\n'
        if chunk:
            chunks.append(chunk)
    else:
        chunks = [message]
    
    results = []
    for chunk in chunks:
        data = json.dumps({
            'chat_id': chat_id,
            'text': chunk,
            'parse_mode': parse_mode,
            'disable_web_page_preview': True,
        }).encode('utf-8')
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={'Content-Type': 'application/json'},
        )
        
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
                results.append(result.get('ok', False))
        except Exception as e:
            print(f'  ❌ 텔레그램 전송 실패: {e}')
            results.append(False)
    
    return all(results)


# ============================================================
# 슬랙 알림
# ============================================================
def send_slack(webhook_url, message):
    """슬랙 Incoming Webhook으로 메시지 전송"""
    data = json.dumps({'text': message}).encode('utf-8')
    
    req = urllib.request.Request(
        webhook_url,
        data=data,
        headers={'Content-Type': 'application/json'},
    )
    
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status == 200
    except Exception as e:
        print(f'  ❌ 슬랙 전송 실패: {e}')
        return False


# ============================================================
# 알림 메시지 포맷터
# ============================================================
def format_telegram_report(results, market_data):
    """텔레그램용 HTML 포맷 분석 리포트"""
    now = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    # 시장 필터 상태
    us_mode = market_data.get('us', {})
    kr_mode = market_data.get('kr', {})
    us_emoji = us_mode.get('mode_emoji', '⚪')
    kr_emoji = kr_mode.get('mode_emoji', '⚪')
    
    msg = f'<b>🎯 듀얼엔진 일일 리포트</b>\n'
    msg += f'<code>{now}</code>\n\n'
    
    # 시장 모드
    msg += f'━━━ 시장 필터 ━━━\n'
    msg += f'{us_emoji} 미국: {us_mode.get("mode_label", "N/A")} '
    msg += f'(건강도 {us_mode.get("health_score", 0)}/4)\n'
    msg += f'{kr_emoji} 한국: {kr_mode.get("mode_label", "N/A")} '
    msg += f'(건강도 {kr_mode.get("health_score", 0)}/4)\n\n'
    
    # SEPA 매수준비 종목
    sepa_buys = [r for r in results if '🟢' in r.get('sepa', {}).get('verdict', '')]
    sepa_watch = [r for r in results if '🟡' in r.get('sepa', {}).get('verdict', '')]
    
    if sepa_buys:
        msg += f'━━━ 🟢 SEPA 매수준비 ({len(sepa_buys)}) ━━━\n'
        for r in sepa_buys[:15]:
            kr = r.get('is_kr', False)
            price_str = f"₩{int(r['current_price']):,}" if kr else f"${r['current_price']:.2f}"
            chg = r.get('change_pct', 0)
            chg_str = f"+{chg:.1f}%" if chg > 0 else f"{chg:.1f}%"
            tt = r['sepa']['template']['score']
            vcp = r['sepa']['vcp']['score']
            pivot = r['sepa']['vcp'].get('pivot', 0)
            pivot_str = f"₩{int(pivot):,}" if kr else f"${pivot:.2f}"
            msg += f'<b>{r["name"]}</b> ({r["ticker"]})\n'
            msg += f'  {price_str} ({chg_str}) | TT:{tt}/8 VCP:{vcp}/7\n'
            msg += f'  피봇: {pivot_str} | R:R {r["sepa"]["trade"]["rr"]}:1\n'
    
    if sepa_watch:
        msg += f'\n━━━ 🟡 워치리스트 ({len(sepa_watch)}) ━━━\n'
        for r in sepa_watch[:10]:
            kr = r.get('is_kr', False)
            price_str = f"₩{int(r['current_price']):,}" if kr else f"${r['current_price']:.2f}"
            tt = r['sepa']['template']['score']
            msg += f'• {r["name"]} {price_str} TT:{tt}/8\n'
    
    # MF 강매수 종목
    mf_strong = [r for r in results 
                 if r.get('mf', {}).get('total_score', 0) >= 2.0 
                 and r.get('mf', {}).get('total_dir', '') == '매수']
    
    if mf_strong:
        msg += f'\n━━━ 🎯 MF 강매수 ({len(mf_strong)}) ━━━\n'
        for r in mf_strong[:10]:
            kr = r.get('is_kr', False)
            price_str = f"₩{int(r['current_price']):,}" if kr else f"${r['current_price']:.2f}"
            ts = r['mf']['total_score']
            al = '✅정렬' if r['mf'].get('alignment', {}).get('bonus', False) else ''
            s = r['mf']['short']['score']
            m = r['mf']['mid']['score']
            l = r['mf']['long']['score']
            msg += f'• {r["name"]} {price_str} <b>{ts:.1f}점</b> [{s}/{m}/{l}] {al}\n'
    
    # 듀얼엔진 톱픽 (SEPA 매수준비 + MF 2.0 이상)
    dual_picks = [r for r in results 
                  if '🟢' in r.get('sepa', {}).get('verdict', '')
                  and r.get('mf', {}).get('total_score', 0) >= 1.8]
    
    if dual_picks:
        msg += f'\n━━━ ⭐ 듀얼엔진 TOP PICK ━━━\n'
        for r in dual_picks[:5]:
            kr = r.get('is_kr', False)
            price_str = f"₩{int(r['current_price']):,}" if kr else f"${r['current_price']:.2f}"
            entry = r['sepa']['trade']['entry']
            stop = r['sepa']['trade']['stop']
            t1 = r['sepa']['trade']['target1']
            entry_str = f"₩{int(entry):,}" if kr else f"${entry:.2f}"
            stop_str = f"₩{int(stop):,}" if kr else f"${stop:.2f}"
            t1_str = f"₩{int(t1):,}" if kr else f"${t1:.2f}"
            msg += f'🏆 <b>{r["name"]}</b> ({r["ticker"]})\n'
            msg += f'  현재: {price_str}\n'
            msg += f'  진입: {entry_str} → 손절: {stop_str} → 목표: {t1_str}\n'
            msg += f'  MF: {r["mf"]["total_score"]:.1f} | SEPA: TT{r["sepa"]["template"]["score"]}/8\n\n'
    
    # 변동 경고 (전일 대비 ±5% 이상)
    big_movers = [r for r in results if abs(r.get('change_pct', 0)) >= 5.0]
    if big_movers:
        msg += f'━━━ ⚡ 급등락 ({len(big_movers)}) ━━━\n'
        for r in sorted(big_movers, key=lambda x: abs(x.get('change_pct', 0)), reverse=True)[:8]:
            chg = r.get('change_pct', 0)
            emoji = '🔺' if chg > 0 else '🔻'
            msg += f'{emoji} {r["name"]} {chg:+.1f}%\n'
    
    # 요약 통계
    msg += f'\n━━━ 📊 요약 ━━━\n'
    msg += f'분석종목: {len(results)}개\n'
    msg += f'SEPA매수: {len(sepa_buys)} | 워치: {len(sepa_watch)}\n'
    msg += f'MF강매수: {len(mf_strong)} | 듀얼TOP: {len(dual_picks)}\n'
    
    return msg


def format_slack_report(results, market_data):
    """슬랙용 Markdown 포맷 분석 리포트"""
    now = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    us_mode = market_data.get('us', {})
    kr_mode = market_data.get('kr', {})
    
    msg = f'*🎯 듀얼엔진 일일 리포트* ({now})\n\n'
    
    # 시장 모드
    msg += f'*시장 필터:* '
    msg += f'{us_mode.get("mode_emoji", "⚪")} US {us_mode.get("mode_label", "N/A")} | '
    msg += f'{kr_mode.get("mode_emoji", "⚪")} KR {kr_mode.get("mode_label", "N/A")}\n\n'
    
    # SEPA 매수준비
    sepa_buys = [r for r in results if '🟢' in r.get('sepa', {}).get('verdict', '')]
    if sepa_buys:
        msg += f'*🟢 SEPA 매수준비 ({len(sepa_buys)})*\n'
        for r in sepa_buys[:10]:
            kr = r.get('is_kr', False)
            p = f"₩{int(r['current_price']):,}" if kr else f"${r['current_price']:.2f}"
            msg += f'> {r["name"]} ({r["ticker"]}) {p} | TT:{r["sepa"]["template"]["score"]}/8 R:R {r["sepa"]["trade"]["rr"]}:1\n'
    
    # MF 강매수
    mf_strong = [r for r in results 
                 if r.get('mf', {}).get('total_score', 0) >= 2.0 
                 and r.get('mf', {}).get('total_dir', '') == '매수']
    if mf_strong:
        msg += f'\n*🎯 MF 강매수 ({len(mf_strong)})*\n'
        for r in mf_strong[:10]:
            kr = r.get('is_kr', False)
            p = f"₩{int(r['current_price']):,}" if kr else f"${r['current_price']:.2f}"
            msg += f'> {r["name"]} {p} *{r["mf"]["total_score"]:.1f}*점\n'
    
    # 듀얼 TOP
    dual_picks = [r for r in results 
                  if '🟢' in r.get('sepa', {}).get('verdict', '')
                  and r.get('mf', {}).get('total_score', 0) >= 1.8]
    if dual_picks:
        msg += f'\n*⭐ 듀얼엔진 TOP PICK*\n'
        for r in dual_picks[:5]:
            msg += f'> 🏆 *{r["name"]}* — 진입: ${r["sepa"]["trade"]["entry"]:.2f} 목표: ${r["sepa"]["trade"]["target1"]:.2f}\n'
    
    msg += f'\n_분석종목 {len(results)}개 | SEPA매수 {len(sepa_buys)} | MF강매수 {len(mf_strong)}_'
    
    return msg


def format_change_alert(new_signals, lost_signals):
    """전일 대비 변동 알림 (새로운 매수 시그널, 이탈 종목)"""
    if not new_signals and not lost_signals:
        return None
    
    msg = '<b>🔔 시그널 변동 알림</b>\n\n'
    
    if new_signals:
        msg += '━━━ 🆕 새 매수 시그널 ━━━\n'
        for item in new_signals:
            msg += f'🟢 <b>{item["name"]}</b> ({item["ticker"]}) → {item["signal_type"]}\n'
    
    if lost_signals:
        msg += '\n━━━ ❌ 시그널 이탈 ━━━\n'
        for item in lost_signals:
            msg += f'🔴 <b>{item["name"]}</b> ({item["ticker"]}) → {item["reason"]}\n'
    
    return msg


# ============================================================
# 메인 전송 함수
# ============================================================
def send_all(results, market_data, prev_results=None):
    """설정된 모든 채널로 알림 전송"""
    config = load_config()
    sent = []
    
    # 텔레그램
    if config['enable_telegram'] and config['telegram_token'] and config['telegram_chat_id']:
        print('  📱 텔레그램 리포트 전송 중...')
        tg_msg = format_telegram_report(results, market_data)
        ok = send_telegram(config['telegram_token'], config['telegram_chat_id'], tg_msg)
        status = '✅' if ok else '❌'
        print(f'  {status} 텔레그램 전송 {"완료" if ok else "실패"}')
        sent.append(('telegram', ok))
        
        # 전일 대비 변동 알림
        if prev_results:
            new_sigs, lost_sigs = compare_signals(results, prev_results)
            change_msg = format_change_alert(new_sigs, lost_sigs)
            if change_msg:
                send_telegram(config['telegram_token'], config['telegram_chat_id'], change_msg)
    
    # 슬랙
    if config['enable_slack'] and config['slack_webhook']:
        print('  💬 슬랙 리포트 전송 중...')
        slack_msg = format_slack_report(results, market_data)
        ok = send_slack(config['slack_webhook'], slack_msg)
        status = '✅' if ok else '❌'
        print(f'  {status} 슬랙 전송 {"완료" if ok else "실패"}')
        sent.append(('slack', ok))
    
    if not sent:
        print('  ⚠️ 알림 채널이 설정되지 않았습니다. .env 파일을 확인하세요.')
    
    return sent


def compare_signals(current, previous):
    """전일 대비 시그널 변동 비교"""
    curr_sepa = {r['ticker'] for r in current if '🟢' in r.get('sepa', {}).get('verdict', '')}
    prev_sepa = set()
    
    if isinstance(previous, list):
        prev_sepa = {r['ticker'] for r in previous if '🟢' in r.get('sepa', {}).get('verdict', '')}
    elif isinstance(previous, dict) and 'results' in previous:
        prev_sepa = {r['ticker'] for r in previous['results'] if '🟢' in r.get('sepa', {}).get('verdict', '')}
    
    new_tickers = curr_sepa - prev_sepa
    lost_tickers = prev_sepa - curr_sepa
    
    curr_map = {r['ticker']: r for r in current}
    prev_map = {}
    if isinstance(previous, list):
        prev_map = {r['ticker']: r for r in previous}
    elif isinstance(previous, dict) and 'results' in previous:
        prev_map = {r['ticker']: r for r in previous['results']}
    
    new_signals = []
    for tk in new_tickers:
        r = curr_map.get(tk, {})
        new_signals.append({
            'ticker': tk,
            'name': r.get('name', tk),
            'signal_type': 'SEPA 매수준비 🟢',
        })
    
    lost_signals = []
    for tk in lost_tickers:
        r = prev_map.get(tk, {})
        lost_signals.append({
            'ticker': tk,
            'name': r.get('name', tk),
            'reason': 'SEPA 이탈',
        })
    
    return new_signals, lost_signals


# ============================================================
# 테스트
# ============================================================
if __name__ == '__main__':
    print('🔧 알림 시스템 테스트')
    config = load_config()
    
    if config['telegram_token'] and config['telegram_chat_id']:
        test_msg = '<b>🧪 테스트 메시지</b>\n\n듀얼엔진 알림 시스템이 정상 연결되었습니다!'
        ok = send_telegram(config['telegram_token'], config['telegram_chat_id'], test_msg)
        print(f'텔레그램: {"✅ 성공" if ok else "❌ 실패"}')
    else:
        print('텔레그램: ⚠️ 토큰/채팅ID 미설정')
    
    if config['slack_webhook']:
        ok = send_slack(config['slack_webhook'], '🧪 듀얼엔진 알림 시스템 테스트 — 정상 연결!')
        print(f'슬랙: {"✅ 성공" if ok else "❌ 실패"}')
    else:
        print('슬랙: ⚠️ 웹훅 URL 미설정')

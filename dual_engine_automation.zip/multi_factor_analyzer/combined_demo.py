"""
Combined Demo Generator — PDF 전광판 데이터 기반
멀티팩터 + SEPA 듀얼 분석 결과 생성
"""
import json, random, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ============================================================
# PDF에서 추출한 전체 종목 데이터
# ============================================================
ALL_STOCKS = [
    # ═══ 한국 주식 ═══
    # AI반도체
    {"t":"000660.KS","n":"SK하이닉스","s":"AI반도체","p":1018000,"fs":96.5,"kr":True,"chg":1.29,"h22":1005000,"brk22":True},
    {"t":"005930.KS","n":"삼성전자","s":"AI반도체","p":203500,"fs":84,"kr":True,"chg":1.75,"h22":200000,"brk22":True},
    {"t":"042700.KQ","n":"한미반도체","s":"AI반도체","p":214500,"fs":81,"kr":True,"chg":2.14,"h22":224500,"brk22":False},
    {"t":"403870.KQ","n":"HPSP","s":"AI반도체","p":41000,"fs":90.5,"kr":True,"chg":0.12,"h22":48800,"brk22":False},
    {"t":"058470.KQ","n":"리노공업","s":"AI반도체","p":97200,"fs":92,"kr":True,"chg":0,"h22":114300,"brk22":False},
    # 전력설비
    {"t":"267260.KS","n":"HD현대일렉트릭","s":"전력설비","p":1065000,"fs":78.5,"kr":True,"chg":-0.47},
    {"t":"010120.KS","n":"LS ELECTRIC","s":"전력설비","p":753000,"fs":80.5,"kr":True,"chg":0.94},
    {"t":"298040.KS","n":"효성중공업","s":"전력설비","p":2763000,"fs":73,"kr":True,"chg":0.18},
    {"t":"229640.KQ","n":"LS에코에너지","s":"전력설비","p":45500,"fs":59.5,"kr":True,"chg":-0.44},
    {"t":"001440.KS","n":"대한전선","s":"전력설비","p":34000,"fs":56.5,"kr":True,"chg":0.29},
    # 원전SMR
    {"t":"034020.KS","n":"두산에너빌리티","s":"원전SMR","p":103200,"fs":69,"kr":True,"chg":1.88},
    {"t":"052690.KS","n":"한전기술","s":"원전SMR","p":168200,"fs":61,"kr":True,"chg":4.80},
    {"t":"051600.KS","n":"한전KPS","s":"원전SMR","p":62400,"fs":64,"kr":True,"chg":0.48},
    {"t":"105840.KQ","n":"우진","s":"원전SMR","p":26750,"fs":59.5,"kr":True,"chg":-0.19},
    {"t":"083650.KQ","n":"비에이치아이","s":"원전SMR","p":88700,"fs":66,"kr":True,"chg":-0.34},
    # K-방산
    {"t":"012450.KS","n":"한화에어로스페이스","s":"K-방산","p":1212000,"fs":78,"kr":True,"chg":-2.34},
    {"t":"064350.KS","n":"현대로템","s":"K-방산","p":222500,"fs":71,"kr":True,"chg":0.45},
    {"t":"079550.KS","n":"LIG넥스원","s":"K-방산","p":509000,"fs":65,"kr":True,"chg":-2.30},
    {"t":"047810.KS","n":"한국항공우주","s":"K-방산","p":182500,"fs":65,"kr":True,"chg":-0.60},
    {"t":"272210.KS","n":"한화시스템","s":"K-방산","p":111400,"fs":54,"kr":True,"chg":0.54},
    # 조선해양
    {"t":"329180.KS","n":"HD현대중공업","s":"조선해양","p":594000,"fs":66.5,"kr":True,"chg":-0.34},
    {"t":"010140.KS","n":"삼성중공업","s":"조선해양","p":28950,"fs":71.5,"kr":True,"chg":-0.17},
    {"t":"042660.KS","n":"한화오션","s":"조선해양","p":142000,"fs":72.5,"kr":True,"chg":-0.77},
    {"t":"009540.KS","n":"HD한국조선해양","s":"조선해양","p":467500,"fs":81.5,"kr":True,"chg":2.19},
    {"t":"082740.KS","n":"한화엔진","s":"조선해양","p":55100,"fs":61.5,"kr":True,"chg":-0.54},
    # 바이오
    {"t":"207940.KS","n":"삼성바이오로직스","s":"바이오","p":1728000,"fs":77.5,"kr":True,"chg":0.29},
    {"t":"196170.KQ","n":"알테오젠","s":"바이오","p":402000,"fs":64.5,"kr":True,"chg":-1.47},
    {"t":"068270.KS","n":"셀트리온","s":"바이오","p":244500,"fs":81,"kr":True,"chg":-1.61},
    {"t":"000100.KS","n":"유한양행","s":"바이오","p":113100,"fs":62,"kr":True,"chg":-0.44},
    # K-뷰티
    {"t":"278470.KQ","n":"에이피알","s":"K-뷰티","p":302000,"fs":93,"kr":True,"chg":2.37},
    {"t":"214150.KQ","n":"클래시스","s":"K-뷰티","p":59900,"fs":89,"kr":True,"chg":-11.13},
    {"t":"192820.KQ","n":"코스맥스","s":"K-뷰티","p":192900,"fs":61,"kr":True,"chg":-1.68},
    {"t":"257720.KQ","n":"실리콘투","s":"K-뷰티","p":43850,"fs":72,"kr":True,"chg":-2.66},
    {"t":"214450.KQ","n":"파마리서치","s":"K-뷰티","p":347500,"fs":84,"kr":True,"chg":-2.52},
    # 이차전지
    {"t":"373220.KS","n":"LG에너지솔루션","s":"이차전지","p":426000,"fs":40,"kr":True,"chg":3.27},
    {"t":"005490.KS","n":"POSCO홀딩스","s":"이차전지","p":406500,"fs":58,"kr":True,"chg":1.75,"brk22":True},
    {"t":"006400.KS","n":"삼성SDI","s":"이차전지","p":433000,"fs":56,"kr":True,"chg":2.73,"brk22":True},
    # 로봇
    {"t":"277810.KQ","n":"레인보우로보틱스","s":"로봇","p":788000,"fs":36.5,"kr":True,"chg":8.09,"brk22":True},
    {"t":"058610.KQ","n":"에스피지","s":"로봇","p":147300,"fs":64.5,"kr":True,"chg":11.09},
    {"t":"022100.KS","n":"포스코DX","s":"로봇","p":39250,"fs":50.5,"kr":True,"chg":3.97},
    # 자동차
    {"t":"005380.KS","n":"현대차","s":"자동차부품","p":572000,"fs":78.8,"kr":True,"chg":9.16,"brk22":True},
    {"t":"000270.KS","n":"기아","s":"자동차부품","p":196100,"fs":70.5,"kr":True,"chg":12.70,"brk22":True},
    {"t":"012330.KS","n":"현대모비스","s":"자동차부품","p":469500,"fs":68,"kr":True,"chg":3.64},
    {"t":"086280.KS","n":"현대글로비스","s":"자동차부품","p":280500,"fs":69.5,"kr":True,"chg":4.08},
    # 소프트웨어
    {"t":"035420.KS","n":"NAVER","s":"소프트웨어","p":253000,"fs":85.5,"kr":True,"chg":-0.78},
    {"t":"035720.KS","n":"카카오","s":"소프트웨어","p":57400,"fs":79,"kr":True,"chg":-0.86},
    {"t":"012510.KS","n":"더존비즈온","s":"소프트웨어","p":119100,"fs":0,"kr":True,"chg":0.25,"brk22":True},
    # 엔터
    {"t":"352820.KS","n":"하이브","s":"엔터","p":396500,"fs":72,"kr":True,"chg":-0.63},

    # ═══ 미국 주식 ═══
    # AI반도체
    {"t":"NVDA","n":"엔비디아","s":"AI반도체","p":192.85,"fs":91.5,"chg":0.68,"brk22":False},
    {"t":"AVGO","n":"브로드컴","s":"AI반도체","p":325.49,"fs":83,"chg":-1.47},
    {"t":"AMD","n":"AMD","s":"AI반도체","p":213.84,"fs":77.5,"chg":8.77},
    {"t":"ASML","n":"ASML","s":"AI반도체","p":1497.80,"fs":90.5,"chg":0.79},
    {"t":"TSM","n":"TSMC","s":"AI반도체","p":385.75,"fs":87,"chg":4.25},
    {"t":"MU","n":"마이크론","s":"AI반도체","p":418.01,"fs":80,"chg":-0.70},
    {"t":"INTC","n":"인텔","s":"AI반도체","p":46.12,"fs":30,"chg":5.71},
    {"t":"ARM","n":"ARM홀딩스","s":"AI반도체","p":128.14,"fs":70.5,"chg":3.52},
    {"t":"SNDK","n":"샌디스크","s":"AI반도체","p":638.52,"fs":74.5,"chg":-4.20},
    # 반도체장비
    {"t":"AMAT","n":"어플라이드머티리얼즈","s":"반도체장비","p":377.93,"fs":79,"chg":1.17},
    {"t":"LRCX","n":"램리서치","s":"반도체장비","p":244.25,"fs":80,"chg":0.82},
    {"t":"KLAC","n":"KLA","s":"반도체장비","p":1506.65,"fs":71.5,"chg":1.28},
    {"t":"SNPS","n":"시놉시스","s":"반도체장비","p":440.72,"fs":68,"chg":4.73},
    {"t":"CDNS","n":"케이던스","s":"반도체장비","p":290.63,"fs":80.5,"chg":3.87},
    # 빅테크
    {"t":"MSFT","n":"마이크로소프트","s":"빅테크","p":389.00,"fs":85.5,"chg":1.18},
    {"t":"GOOGL","n":"알파벳(구글)","s":"빅테크","p":310.90,"fs":88.6,"chg":-0.19},
    {"t":"AMZN","n":"아마존","s":"빅테크","p":208.56,"fs":59,"chg":1.60},
    {"t":"META","n":"메타","s":"빅테크","p":639.30,"fs":74,"chg":0.32},
    {"t":"AAPL","n":"애플","s":"빅테크","p":272.14,"fs":86,"chg":2.24},
    # 클라우드
    {"t":"ORCL","n":"오라클","s":"클라우드","p":146.14,"fs":62,"chg":3.42},
    {"t":"PLTR","n":"팔란티어","s":"클라우드","p":128.84,"fs":85,"chg":-1.35},
    {"t":"SNOW","n":"스노우플레이크","s":"클라우드","p":161.06,"fs":78,"chg":2.20},
    {"t":"ADBE","n":"어도비","s":"클라우드","p":255.17,"fs":80,"chg":3.44},
    {"t":"CRM","n":"세일즈포스","s":"클라우드","p":185.42,"fs":80.5,"chg":4.07},
    # 사이버보안
    {"t":"PANW","n":"팔로알토네트웍스","s":"사이버보안","p":141.67,"fs":70,"chg":-1.71},
    {"t":"CRWD","n":"크라우드스트라이크","s":"사이버보안","p":350.25,"fs":70,"chg":-0.02},
    # 전력인프라
    {"t":"VST","n":"비스트라에너지","s":"전력인프라","p":171.62,"fs":75,"chg":2.28},
    {"t":"GEV","n":"GE버노바","s":"전력인프라","p":879.73,"fs":82.5,"chg":5.77},
    {"t":"VRT","n":"버티브","s":"전력인프라","p":253.15,"fs":84.5,"chg":3.15},
    {"t":"PWR","n":"콴타서비스","s":"전력인프라","p":568.21,"fs":82.5,"chg":3.48},
    # 원자력
    {"t":"CEG","n":"컨스텔레이션에너지","s":"원자력","p":312.64,"fs":41.5,"chg":6.41},
    {"t":"OKLO","n":"오클로","s":"원자력","p":65.06,"fs":38,"chg":3.12},
    # 태양광
    {"t":"FSLR","n":"퍼스트솔라","s":"태양광","p":243.21,"fs":63.5,"chg":0.44},
    {"t":"ENPH","n":"엔파스에너지","s":"태양광","p":49.74,"fs":50,"chg":4.94},
    {"t":"NEE","n":"넥스트에라에너지","s":"태양광","p":95.68,"fs":81,"chg":1.72},
    # 방산우주
    {"t":"RTX","n":"RTX(레이시온)","s":"방산우주","p":198.46,"fs":73.5,"chg":-1.71},
    {"t":"LMT","n":"록히드마틴","s":"방산우주","p":664.43,"fs":70.5,"chg":0.58},
    {"t":"NOC","n":"노스롭그루먼","s":"방산우주","p":727.73,"fs":80,"chg":0.32},
    {"t":"GD","n":"제너럴다이내믹스","s":"방산우주","p":351.18,"fs":71.5,"chg":0.63},
    {"t":"KTOS","n":"크라토스","s":"방산우주","p":90.68,"fs":54.5,"chg":-3.85},
    # 로봇자율
    {"t":"TSLA","n":"테슬라","s":"로봇자율","p":409.38,"fs":55,"chg":2.39},
    {"t":"ISRG","n":"인튜이티브서지컬","s":"로봇자율","p":494.02,"fs":82.5,"chg":0.39},
    {"t":"UBER","n":"우버","s":"로봇자율","p":71.38,"fs":77.5,"chg":0.93},
    {"t":"DE","n":"디어앤컴퍼니","s":"로봇자율","p":644.54,"fs":62.5,"chg":-0.36},
    # 비만치료
    {"t":"LLY","n":"일라이릴리","s":"비만치료","p":1042.15,"fs":91,"chg":-1.55},
    {"t":"NVO","n":"노보노디스크","s":"비만치료","p":38.59,"fs":61,"chg":-2.62},
    {"t":"VRTX","n":"버텍스파마슈티컬","s":"비만치료","p":487.43,"fs":79,"chg":1.33},
    {"t":"AMGN","n":"암젠","s":"비만치료","p":382.87,"fs":76.5,"chg":0.91},
    # 산업재
    {"t":"CAT","n":"캐터필러","s":"산업재","p":768.23,"fs":76,"chg":1.55},
    {"t":"URI","n":"유나이티드렌탈","s":"산업재","p":896.88,"fs":78,"chg":1.61},
    {"t":"PH","n":"파커하니핀","s":"산업재","p":1023.02,"fs":77,"chg":1.39},
    {"t":"GE","n":"GE에어로스페이스","s":"산업재","p":345.64,"fs":75,"chg":1.96},
    {"t":"WM","n":"웨이스트매니지먼트","s":"산업재","p":229.58,"fs":72.5,"chg":-0.43},
    # 크립토
    {"t":"COIN","n":"코인베이스","s":"크립토","p":162.03,"fs":56.5,"chg":1.12},
    {"t":"HOOD","n":"로빈후드","s":"크립토","p":73.39,"fs":65,"chg":2.24},
    # 데이터센터
    {"t":"EQIX","n":"에퀴닉스","s":"데이터센터","p":951.90,"fs":79,"chg":0.66},
    {"t":"DLR","n":"디지털리얼티","s":"데이터센터","p":178.24,"fs":77.5,"chg":1.22},
    {"t":"IRM","n":"아이언마운틴","s":"데이터센터","p":113.24,"fs":74,"chg":1.84},
    {"t":"DELL","n":"델테크놀로지","s":"데이터센터","p":119.78,"fs":74,"chg":0.54},
    # 광케이블
    {"t":"ANET","n":"아리스타네트웍스","s":"광케이블","p":128.77,"fs":80,"chg":1.05},
    {"t":"GLW","n":"코닝","s":"광케이블","p":151.59,"fs":81.5,"chg":4.36},
    {"t":"CIEN","n":"시에나","s":"광케이블","p":342.70,"fs":68,"chg":-0.62},
    {"t":"COHR","n":"코히런트","s":"광케이블","p":254.86,"fs":64,"chg":2.40},
    # 제약
    {"t":"ABBV","n":"애브비","s":"제약","p":228.44,"fs":78,"chg":-0.45},
    {"t":"JNJ","n":"존슨앤존슨","s":"제약","p":246.28,"fs":77.5,"chg":0.71},
    {"t":"MRK","n":"머크","s":"제약","p":123.93,"fs":73,"chg":0.09},
    {"t":"BMY","n":"브리스톨마이어스","s":"제약","p":61.60,"fs":68,"chg":0.57},
    # 소비재
    {"t":"NFLX","n":"넷플릭스","s":"소비재","p":78.04,"fs":78.5,"chg":2.66},
    {"t":"COST","n":"코스트코","s":"소비재","p":998.43,"fs":0,"chg":1.26},
    # 우주
    {"t":"RKLB","n":"로켓랩","s":"우주","p":69.97,"fs":58.5,"chg":-0.34},
    # 원유
    {"t":"XOM","n":"엑슨모빌","s":"원유","p":149.26,"fs":70,"chg":-0.99},
]

SIGNALS = ['매수','매도','중립']
TRENDS = ['상승추세','하락추세','횡보']
STRENGTHS = ['강한 상승','약한 상승','중립','약한 하락','강한 하락']

def gen_sig(bias=0):
    r = random.random() + bias*0.3
    if r > 0.65: return '매수'
    elif r < 0.35: return '매도'
    return '중립'

def confluence(s1,s2,s3):
    sigs=[s1,s2,s3]; b=sigs.count('매수'); sl=sigs.count('매도')
    if b==3: return 3,'매수','⭐ 강한 매수'
    if sl==3: return 3,'매도','⭐ 강한 매도'
    if b==2: return 2,'매수','✅ 매수 우세'
    if sl==2: return 2,'매도','✅ 매도 우세'
    if b==1 and sl==0: return 1,'매수','⚠️ 약한 매수'
    if sl==1 and b==0: return 1,'매도','⚠️ 약한 매도'
    return 0,'중립','❌ 관망'

def gen_market_filter():
    """시장 필터 데이터 생성"""
    return {
        'us': {
            'spy_12m': 14.2,
            'abs_pass': True,
            'spy_vs_200d': 'above',
            'new_hl': 'bullish',
            'ad_trend': 'up',
            'vix': 16.8,
            'health_score': 4,
            'mode': 'attack',
            'mode_emoji': '🟢',
            'mode_label': '공격 모드',
            'sectors': [('XLK 기술',18.5),('XLI 산업재',12.3),('XLV 헬스케어',9.8),('XLF 금융',8.2),('XLE 에너지',5.1)],
            'markets': [('SPY 미국',14.2),('EWY 한국',11.5),('EFA 선진국',8.3),('EEM 신흥국',3.1)],
        },
        'kr': {
            'kospi_12m': 11.5,
            'abs_pass': True,
            'kospi_vs_200d': 'above',
            'new_hl': 'bullish',
            'ad_trend': 'up',
            'vix': 16.8,
            'health_score': 3,
            'mode': 'attack',
            'mode_emoji': '🟢',
            'mode_label': '공격 모드',
        }
    }

def generate_combined_results():
    random.seed(42)
    results = []
    mkt = gen_market_filter()
    
    for d in ALL_STOCKS:
        p = d['p']; fs = d.get('fs',0); kr = d.get('kr',False)
        chg = d.get('chg',0); brk = d.get('brk22',False)
        bias = (fs-55)/45 if fs > 0 else -0.1
        if brk: bias += 0.3
        if chg > 3: bias += 0.15
        elif chg < -3: bias -= 0.15
        
        # ═══ Method 1: 멀티팩터 분석 ═══
        sf1,sf2,sf3 = gen_sig(bias),gen_sig(bias*0.8),gen_sig(bias*0.6)
        ss,sd,sg = confluence(sf1,sf2,sf3)
        mf1,mf2,mf3 = gen_sig(bias*0.7),gen_sig(bias*0.5),gen_sig(bias*0.4)
        ms,md,mg = confluence(mf1,mf2,mf3)
        lf1,lf2,lf3 = gen_sig(bias*0.9),gen_sig(bias*0.6),gen_sig(bias*0.5)
        ls,ld,lg = confluence(lf1,lf2,lf3)
        
        dirs=[sd,md,ld]
        if all(x=='매수' for x in dirs): align={'status':'완전정렬(매수)','bonus':True,'conflict':False}
        elif all(x=='매도' for x in dirs): align={'status':'완전정렬(매도)','bonus':True,'conflict':False}
        elif ld!=sd and ld!='중립' and sd!='중립': align={'status':'충돌','bonus':False,'conflict':True}
        else: align={'status':'부분정렬','bonus':False,'conflict':False}
        
        rsi_s = round(random.uniform(25,75),1)
        strength = random.choice(STRENGTHS)
        trend = random.choice(TRENDS)
        
        mf_total = round(ls*0.4+ms*0.35+ss*0.25,2)
        
        # ═══ Method 2: SEPA 분석 ═══
        # 트렌드 템플릿 — 펀더멘탈 높고 돌파신호면 높은 점수
        base_tt = 5
        if fs >= 80: base_tt += 2
        elif fs >= 60: base_tt += 1
        if brk: base_tt += 1
        if chg > 2: base_tt = min(base_tt+1, 8)
        if chg < -5: base_tt = max(base_tt-2, 2)
        tt_score = min(max(base_tt + random.randint(-1,1), 2), 8)
        
        if tt_score == 8: tt_stage = 'Stage 2 ✅'
        elif tt_score == 7: tt_stage = 'Early Stage 2 ⚠️'
        else: tt_stage = f'탈락 ❌'
        
        ma50 = round(p*random.uniform(0.92,1.02),2)
        ma150 = round(p*random.uniform(0.85,0.98),2)
        ma200 = round(p*random.uniform(0.78,0.95),2)
        
        # RS Rating
        stock_6m = round(random.uniform(-15,40) + bias*10, 1)
        stock_3m = round(random.uniform(-10,25) + bias*8, 1)
        bench_6m = 8.5; bench_3m = 4.2
        rs_out = stock_6m > bench_6m and stock_3m > bench_3m
        rs_score = round((stock_6m-bench_6m)*0.6+(stock_3m-bench_3m)*0.4, 1)
        
        # VCP
        n_t = random.randint(1,4)
        depths = sorted([round(random.uniform(5,30),1) for _ in range(n_t)], reverse=True)
        vcp_score = 0
        if n_t >= 2: vcp_score += 1
        if len(depths)>=2 and all(depths[i]>depths[i+1] for i in range(len(depths)-1)): vcp_score += 1
        if random.random() > 0.4: vcp_score += 1  # vol decrease
        vcp_score += 1  # base period
        corr = round(random.uniform(8,35),1)
        if 10 <= corr <= 35: vcp_score += 1
        if random.random() > 0.5: vcp_score += 1  # pivot
        pct_to_pivot = round(random.uniform(-8,10),1)
        if -2 <= pct_to_pivot <= 5: vcp_score += 1
        
        vcp_score = min(vcp_score, 7)
        if vcp_score >= 6: vcp_mat = '성숙 🟢'
        elif vcp_score >= 4: vcp_mat = '형성중 🟡'
        else: vcp_mat = '미성숙 🔴'
        
        pivot = round(p * (1 + pct_to_pivot/100), 2)
        
        # 펀더멘탈 등급
        if fs >= 85: fund_grade = '⭐⭐⭐ A'
        elif fs >= 65: fund_grade = '⭐⭐ B'
        elif fs >= 45: fund_grade = '⭐ C'
        else: fund_grade = '❌ 탈락'
        
        # SEPA 종합 판정
        if tt_score >= 7 and rs_out and vcp_score >= 4:
            sepa_verdict = '매수준비 🟢'
        elif tt_score >= 7 and (rs_out or vcp_score >= 4):
            sepa_verdict = '워치리스트 🟡'
        else:
            sepa_verdict = '패스 🔴'
        
        # 매매 계획
        entry = round(pivot * 1.001, 2)
        stop = round(entry * 0.93, 2)
        t1 = round(entry * 1.15, 2)
        t2 = round(entry * 1.30, 2)
        risk_ps = round(entry - stop, 2)
        rr = round((t1-entry)/risk_ps, 1) if risk_ps > 0 else 0
        
        result = {
            'ticker': d['t'],
            'name': d['n'],
            'sector': d['s'],
            'current_price': p,
            'change_pct': chg,
            'fundamental_score': fs,
            'is_kr': kr,
            'breakout_22d': brk,
            
            # ═══ 멀티팩터 결과 ═══
            'mf': {
                'short': {'f1':sf1,'f2':sf2,'f3':sf3,'score':ss,'dir':sd,'grade':sg,
                          'rsi':rsi_s,'trend':trend,'strength':strength,
                          'bb_lower':round(p*0.96,2),'bb_upper':round(p*1.04,2),
                          'vwap':round(p*0.99,2)},
                'mid':   {'f1':mf1,'f2':mf2,'f3':mf3,'score':ms,'dir':md,'grade':mg,
                          'rsi':round(random.uniform(35,65),1),'adx':round(random.uniform(15,45),1),
                          'ma20w':round(p*0.95,2)},
                'long':  {'f1':lf1,'f2':lf2,'f3':lf3,'score':ls,'dir':ld,'grade':lg,
                          'rsi':round(random.uniform(35,65),1),
                          'hist_pos':round(random.uniform(30,85),1),
                          'ma60m':round(p*0.85,2),'ath':round(p*1.3,2)},
                'alignment': align,
                'total_score': mf_total,
                'total_dir': ld if ld!='중립' else (md if md!='중립' else sd),
                'levels': {
                    'short':{'entry':round(p*0.98,2),'stop':round(p*0.95,2),'target':round(p*1.05,2),'rr':round(random.uniform(1.2,3.5),2)},
                    'mid':{'entry':round(p*0.93,2),'stop':round(p*0.85,2),'target':round(p*1.15,2),'rr':round(random.uniform(1.5,4),2)},
                    'long':{'entry':round(p*0.85,2),'stop':round(p*0.7,2),'target':round(p*1.3,2),'rr':round(random.uniform(2,5),2)},
                },
            },
            
            # ═══ SEPA 결과 ═══
            'sepa': {
                'template': {'score':tt_score,'stage':tt_stage,'ma50':ma50,'ma150':ma150,'ma200':ma200,
                             'high_52w':round(p*random.uniform(1.0,1.4),2),'low_52w':round(p*random.uniform(0.5,0.85),2),
                             'pct_from_high':round(random.uniform(0,30),1),'pct_from_low':round(random.uniform(20,80),1)},
                'rs': {'stock_6m':stock_6m,'stock_3m':stock_3m,'bench_6m':bench_6m,'bench_3m':bench_3m,
                       'outperform':rs_out,'rs_score':rs_score},
                'vcp': {'score':vcp_score,'maturity':vcp_mat,'contractions':depths,
                        'pivot':pivot,'pct_to_pivot':pct_to_pivot,'correction':corr,
                        'base_weeks':round(random.uniform(3,20),1)},
                'fundamental_grade': fund_grade,
                'verdict': sepa_verdict,
                'trade': {'entry':entry,'stop':stop,'target1':t1,'target2':t2,'rr':rr,'risk_ps':risk_ps},
            },
        }
        results.append(result)
    
    # 정렬: 종합 점수
    results.sort(key=lambda x: (
        1 if x['sepa']['verdict'].startswith('매수') else (0.5 if x['sepa']['verdict'].startswith('워치') else 0),
        x['mf']['total_score'],
        x['fundamental_score']
    ), reverse=True)
    
    return results, mkt


if __name__ == '__main__':
    results, mkt = generate_combined_results()
    print(f"✅ {len(results)}개 종목 데이터 생성 완료")
    
    # JSON 저장
    out_dir = os.path.join(os.path.dirname(__file__), 'output')
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, 'combined_results.json'), 'w', encoding='utf-8') as f:
        json.dump({'results': results, 'market': mkt}, f, ensure_ascii=False, indent=2, default=str)
    print(f"✅ JSON 저장: output/combined_results.json")

#!/usr/bin/env python3
"""
멀티팩터 × 멀티타임프레임 분석 시스템 — 메인 파이프라인
200종목 자동 분석 + HTML 대시보드 생성
"""
import sys
import os
import json
import time
from datetime import datetime

# 프로젝트 루트를 path에 추가
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import get_all_tickers, get_us_tickers, get_kr_tickers, US_STOCKS, KR_STOCKS, ETFS, PORTFOLIO_EXTRA
from data_fetcher import fetch_batch
from confluence import analyze_stock
from report_generator import generate_dashboard

def run_analysis(mode='all', limit=None):
    """
    메인 분석 파이프라인
    mode: 'all' | 'us' | 'kr' | 'etf'
    limit: 분석할 종목 수 제한 (테스트용)
    """
    print("=" * 60)
    print(f"🎯 멀티팩터 × 멀티타임프레임 분석 시스템")
    print(f"📅 실행 시각: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 1. 종목 선택
    if mode == 'us':
        tickers = {**US_STOCKS, **ETFS, **PORTFOLIO_EXTRA}
    elif mode == 'kr':
        tickers = KR_STOCKS
    elif mode == 'etf':
        tickers = ETFS
    else:
        tickers = get_all_tickers()
    
    if limit:
        tickers = dict(list(tickers.items())[:limit])
    
    total = len(tickers)
    print(f"\n📊 분석 대상: {total}개 종목 ({mode} 모드)")
    print("-" * 60)
    
    # 2. 데이터 수집
    print("\n🔄 [1/3] 데이터 수집 중...")
    start_time = time.time()
    raw_data = fetch_batch(tickers)
    fetch_time = time.time() - start_time
    print(f"  ✅ {len(raw_data)}/{total}개 종목 데이터 수집 완료 ({fetch_time:.1f}초)")
    
    # 3. 3-Factor 분석
    print("\n🔬 [2/3] 3-Factor 멀티타임프레임 분석 중...")
    results = []
    errors = []
    
    for i, (ticker, stock_data) in enumerate(raw_data.items(), 1):
        name = stock_data['info'].get('name', ticker)
        try:
            result = analyze_stock(ticker, stock_data['info'], stock_data['data'])
            results.append(result)
            
            # 진행 상황 표시
            grade = result['short_term']['grade']
            mid_grade = result['mid_term']['grade']
            print(f"  [{i}/{len(raw_data)}] {name:20s} | 단기:{grade} | 중기:{mid_grade}")
        except Exception as e:
            errors.append((ticker, name, str(e)))
            print(f"  [{i}/{len(raw_data)}] {name:20s} | ❌ 분석 실패: {e}")
    
    analysis_time = time.time() - start_time - fetch_time
    print(f"  ✅ {len(results)}개 종목 분석 완료 ({analysis_time:.1f}초)")
    
    if errors:
        print(f"  ⚠️ {len(errors)}개 종목 분석 실패")
    
    # 4. 결과 정렬 및 리포트 생성
    print("\n📋 [3/3] 대시보드 생성 중...")
    
    # 종합 점수 기준 정렬
    results.sort(key=lambda x: x['total_score'], reverse=True)
    
    # HTML 대시보드 생성
    output_path = os.path.join(os.path.dirname(__file__), 'output', 'dashboard.html')
    generate_dashboard(results, output_path)
    
    # JSON 결과 저장
    json_path = os.path.join(os.path.dirname(__file__), 'output', 'results.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)
    
    total_time = time.time() - start_time
    
    # 5. 요약 출력
    print("\n" + "=" * 60)
    print("📊 분석 완료 요약")
    print("=" * 60)
    
    # 강한 매수 신호 종목
    strong_buys = [r for r in results if r['total_score'] >= 2 and r['total_direction'] == '매수']
    if strong_buys:
        print(f"\n🟢 강한 매수 신호 ({len(strong_buys)}개):")
        for r in strong_buys[:10]:
            print(f"  • {r['name']:20s} | 점수: {r['total_score']} | {r['alignment']['status']}")
    
    # 강한 매도 신호 종목
    strong_sells = [r for r in results if r['total_direction'] == '매도' and r['total_score'] >= 2]
    if strong_sells:
        print(f"\n🔴 강한 매도 신호 ({len(strong_sells)}개):")
        for r in strong_sells[:10]:
            print(f"  • {r['name']:20s} | 점수: {r['total_score']} | {r['alignment']['status']}")
    
    print(f"\n⏱️ 총 소요 시간: {total_time:.1f}초")
    print(f"📁 대시보드: {output_path}")
    print(f"📁 JSON 결과: {json_path}")
    
    return results

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='멀티팩터 분석 시스템')
    parser.add_argument('--mode', choices=['all', 'us', 'kr', 'etf'], default='all')
    parser.add_argument('--limit', type=int, default=None, help='분석 종목 수 제한')
    args = parser.parse_args()
    
    run_analysis(mode=args.mode, limit=args.limit)

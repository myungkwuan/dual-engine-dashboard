"""
SEPA 분석 엔진 — 미너비니 Trend Template + VCP + RS Rating + 펀더멘탈
"""
import pandas as pd
import numpy as np

# ====================================================================
# 2-1. 트렌드 템플릿 (8가지 필수 조건)
# ====================================================================
def check_trend_template(df):
    """
    미너비니 트렌드 템플릿 8개 조건 체크
    Returns: dict with each condition result and overall score
    """
    if df is None or len(df) < 200:
        return {'score': 0, 'total': 8, 'conditions': {}, 'stage': '데이터부족'}
    
    close = df['Close']
    current = float(close.iloc[-1])
    
    # 이동평균선 계산
    ma50 = float(close.rolling(50).mean().iloc[-1])
    ma150 = float(close.rolling(150).mean().iloc[-1])
    ma200 = float(close.rolling(200).mean().iloc[-1])
    
    # 200일선 1개월 전 값 (우상향 확인)
    ma200_1m_ago = float(close.rolling(200).mean().iloc[-22]) if len(df) > 222 else ma200
    
    # 52주 고저
    high_52w = float(close.tail(252).max()) if len(close) >= 252 else float(close.max())
    low_52w = float(close.tail(252).min()) if len(close) >= 252 else float(close.min())
    
    conditions = {}
    
    # 1. 현재가 > 150일선
    conditions['c1_above_ma150'] = {
        'pass': current > ma150,
        'label': '현재가 > 150일선',
        'current': current,
        'target': round(ma150, 2),
    }
    
    # 2. 현재가 > 200일선
    conditions['c2_above_ma200'] = {
        'pass': current > ma200,
        'label': '현재가 > 200일선',
        'current': current,
        'target': round(ma200, 2),
    }
    
    # 3. 150일선 > 200일선
    conditions['c3_ma150_above_ma200'] = {
        'pass': ma150 > ma200,
        'label': '150일선 > 200일선',
        'current': round(ma150, 2),
        'target': round(ma200, 2),
    }
    
    # 4. 200일선 우상향 (1개월+)
    conditions['c4_ma200_rising'] = {
        'pass': ma200 > ma200_1m_ago,
        'label': '200일선 우상향',
        'current': round(ma200, 2),
        'target': round(ma200_1m_ago, 2),
    }
    
    # 5. 정배열: 50일 > 150일 > 200일
    conditions['c5_alignment'] = {
        'pass': ma50 > ma150 > ma200,
        'label': '정배열 (50>150>200)',
        'values': f"{round(ma50,2)} > {round(ma150,2)} > {round(ma200,2)}",
    }
    
    # 6. 현재가 > 50일선
    conditions['c6_above_ma50'] = {
        'pass': current > ma50,
        'label': '현재가 > 50일선',
        'current': current,
        'target': round(ma50, 2),
    }
    
    # 7. 52주 저점 대비 30% 이상
    pct_from_low = (current / low_52w - 1) * 100
    conditions['c7_above_52w_low'] = {
        'pass': pct_from_low >= 30,
        'label': '52주 저점 +30%↑',
        'pct': round(pct_from_low, 1),
        'low': round(low_52w, 2),
    }
    
    # 8. 52주 고점 대비 25% 이내
    pct_from_high = (1 - current / high_52w) * 100
    conditions['c8_near_52w_high'] = {
        'pass': pct_from_high <= 25,
        'label': '52주 고점 -25% 이내',
        'pct': round(pct_from_high, 1),
        'high': round(high_52w, 2),
    }
    
    score = sum(1 for c in conditions.values() if c['pass'])
    
    if score == 8:
        stage = 'Stage 2 ✅'
    elif score == 7:
        stage = 'Early Stage 2 ⚠️'
    else:
        stage = f'탈락 ❌ ({score}/8)'
    
    return {
        'score': score,
        'total': 8,
        'stage': stage,
        'conditions': conditions,
        'ma50': round(ma50, 2),
        'ma150': round(ma150, 2),
        'ma200': round(ma200, 2),
        'high_52w': round(high_52w, 2),
        'low_52w': round(low_52w, 2),
        'pct_from_high': round(pct_from_high, 1),
        'pct_from_low': round(pct_from_low, 1),
    }

# ====================================================================
# 2-3. RS (Relative Strength) 분석
# ====================================================================
def calc_rs_rating(stock_df, benchmark_df):
    """
    종목 vs 벤치마크 상대강도 계산
    """
    if stock_df is None or benchmark_df is None:
        return {'rs_6m': 0, 'rs_3m': 0, 'outperform': False}
    
    stock_close = stock_df['Close']
    bench_close = benchmark_df['Close']
    
    # 6개월 수익률
    stock_6m = float((stock_close.iloc[-1] / stock_close.iloc[-min(126, len(stock_close))] - 1) * 100) if len(stock_close) > 126 else 0
    bench_6m = float((bench_close.iloc[-1] / bench_close.iloc[-min(126, len(bench_close))] - 1) * 100) if len(bench_close) > 126 else 0
    
    # 3개월 수익률
    stock_3m = float((stock_close.iloc[-1] / stock_close.iloc[-min(63, len(stock_close))] - 1) * 100) if len(stock_close) > 63 else 0
    bench_3m = float((bench_close.iloc[-1] / bench_close.iloc[-min(63, len(bench_close))] - 1) * 100) if len(bench_close) > 63 else 0
    
    outperform_6m = stock_6m > bench_6m
    outperform_3m = stock_3m > bench_3m
    
    return {
        'stock_6m': round(stock_6m, 1),
        'stock_3m': round(stock_3m, 1),
        'bench_6m': round(bench_6m, 1),
        'bench_3m': round(bench_3m, 1),
        'outperform_6m': outperform_6m,
        'outperform_3m': outperform_3m,
        'outperform': outperform_6m and outperform_3m,
        'rs_score': round((stock_6m - bench_6m) * 0.6 + (stock_3m - bench_3m) * 0.4, 1),
    }

# ====================================================================
# 3-1 ~ 3-3. VCP 패턴 정밀 분석
# ====================================================================
def analyze_vcp_detailed(df, lookback_weeks=25):
    """
    미너비니 VCP 정밀 분석
    수축 횟수, 깊이, 거래량 감소, 피봇 라인
    """
    if df is None or len(df) < 30:
        return {'maturity': '데이터부족', 'score': 0}
    
    lookback = min(lookback_weeks * 5, len(df))  # 일봉 기준
    subset = df.tail(lookback).copy()
    close = subset['Close'].values
    high = subset['High'].values
    low = subset['Low'].values
    volume = subset['Volume'].values
    
    # 스윙 고점/저점 찾기
    swing_highs = []
    swing_lows = []
    window = 5
    
    for i in range(window, len(close) - window):
        if high[i] == max(high[i-window:i+window+1]):
            swing_highs.append((i, float(high[i])))
        if low[i] == min(low[i-window:i+window+1]):
            swing_lows.append((i, float(low[i])))
    
    if len(swing_highs) < 2 or len(swing_lows) < 2:
        return {'maturity': '미성숙 🔴', 'score': 0, 'contractions': []}
    
    # 전체 기간 고점
    period_high = float(max(high))
    current_price = float(close[-1])
    
    # 수축(T) 식별 — 각 스윙 고점에서 다음 저점까지의 하락폭
    contractions = []
    for i in range(min(len(swing_highs), len(swing_lows))):
        if i < len(swing_lows):
            h = swing_highs[i][1] if i < len(swing_highs) else period_high
            l = swing_lows[i][1]
            depth = (1 - l / h) * 100
            contractions.append({
                'depth': round(depth, 1),
                'high': round(h, 2),
                'low': round(l, 2),
            })
    
    # 체크리스트 평가
    checks = {}
    
    # 1. 수축 횟수
    n_contractions = len(contractions)
    checks['contraction_count'] = {
        'pass': n_contractions >= 2,
        'value': n_contractions,
        'label': f'수축 {n_contractions}회 (≥2)',
    }
    
    # 2. 수축 깊이 감소
    depth_decreasing = True
    if len(contractions) >= 2:
        for i in range(1, len(contractions)):
            if contractions[i]['depth'] >= contractions[i-1]['depth']:
                depth_decreasing = False
                break
    else:
        depth_decreasing = False
    
    checks['depth_decreasing'] = {
        'pass': depth_decreasing,
        'label': '수축 깊이 감소',
        'depths': [c['depth'] for c in contractions],
    }
    
    # 3. 거래량 감소
    if len(volume) > 20:
        vol_first_half = float(np.mean(volume[:len(volume)//2]))
        vol_second_half = float(np.mean(volume[len(volume)//2:]))
        vol_decreasing = vol_second_half < vol_first_half
    else:
        vol_decreasing = False
    
    checks['volume_decreasing'] = {
        'pass': vol_decreasing,
        'label': '거래량 감소',
    }
    
    # 4. 베이스 기간
    base_weeks = lookback / 5
    checks['base_period'] = {
        'pass': base_weeks >= 3,
        'value': round(base_weeks, 1),
        'label': f'베이스 {round(base_weeks,1)}주 (≥3)',
    }
    
    # 5. 전체 조정 폭
    total_correction = (1 - min(low) / period_high) * 100
    checks['total_correction'] = {
        'pass': 10 <= total_correction <= 35,
        'value': round(total_correction, 1),
        'label': f'조정 -{round(total_correction,1)}% (10~35%)',
    }
    
    # 6. 피봇 라인 형성 — 최근 수축의 고점들
    recent_highs = [sh[1] for sh in swing_highs[-3:]] if len(swing_highs) >= 2 else [period_high]
    pivot_line = max(recent_highs) if recent_highs else period_high
    pivot_range = (max(recent_highs) - min(recent_highs)) / max(recent_highs) * 100 if len(recent_highs) >= 2 else 0
    
    checks['pivot_formed'] = {
        'pass': pivot_range < 5,  # 고점들이 5% 이내로 모여있으면 피봇 형성
        'value': round(pivot_range, 1),
        'label': '피봇 라인 형성',
    }
    
    # 7. 피봇 근접도
    pct_to_pivot = (pivot_line - current_price) / pivot_line * 100
    checks['near_pivot'] = {
        'pass': pct_to_pivot <= 5 and pct_to_pivot >= -2,
        'value': round(pct_to_pivot, 1),
        'label': f'피봇 근접 ({round(pct_to_pivot,1)}%)',
    }
    
    # 성숙도 판정
    pass_count = sum(1 for c in checks.values() if c['pass'])
    
    if pass_count >= 6:
        maturity = '성숙 🟢'
    elif pass_count >= 4:
        maturity = '형성중 🟡'
    else:
        maturity = '미성숙 🔴'
    
    # 추격 판정
    if pct_to_pivot < -5:
        chase_status = '추격금지 ❌ (피봇+5% 초과)'
    elif pct_to_pivot < 0:
        chase_status = '추격허용 ⚠️'
    else:
        chase_status = '진입대기 ✅'
    
    return {
        'maturity': maturity,
        'score': pass_count,
        'total': 7,
        'checks': checks,
        'contractions': contractions[:5],
        'pivot_line': round(pivot_line, 2),
        'pct_to_pivot': round(pct_to_pivot, 1),
        'total_correction': round(total_correction, 1),
        'base_weeks': round(base_weeks, 1),
        'chase_status': chase_status,
    }

# ====================================================================
# 4. 진입/손절/목표 산출
# ====================================================================
def calc_sepa_trade_plan(current_price, pivot_line, vcp_data, account_size=100000, risk_pct=1.5):
    """SEPA 기반 매매 계획 산출"""
    if not pivot_line or pivot_line <= 0:
        return {}
    
    entry = round(pivot_line * 1.001, 2)  # 피봇 + 0.1%
    chase_limit = round(pivot_line * 1.05, 2)  # 피봇 + 5%
    
    # 손절: 피봇 아래 -7% 또는 최근 수축 저점
    stop_default = round(entry * 0.93, 2)
    if vcp_data.get('contractions') and len(vcp_data['contractions']) > 0:
        last_low = vcp_data['contractions'][-1].get('low', stop_default)
        stop_vcp = round(last_low * 0.99, 2)
        stop = max(stop_default, stop_vcp)
    else:
        stop = stop_default
    
    risk_per_share = entry - stop
    if risk_per_share <= 0:
        risk_per_share = entry * 0.07
        stop = round(entry - risk_per_share, 2)
    
    risk_amount = account_size * (risk_pct / 100)
    shares = int(risk_amount / risk_per_share) if risk_per_share > 0 else 0
    position_size = shares * entry
    position_pct = round(position_size / account_size * 100, 1)
    
    target1 = round(entry * 1.15, 2)
    target2 = round(entry * 1.30, 2)
    
    rr = round((target1 - entry) / risk_per_share, 1) if risk_per_share > 0 else 0
    
    return {
        'entry': entry,
        'chase_limit': chase_limit,
        'stop': stop,
        'risk_per_share': round(risk_per_share, 2),
        'shares': shares,
        'position_size': round(position_size, 2),
        'position_pct': position_pct,
        'target1': target1,
        'target2': target2,
        'rr_ratio': rr,
    }

# ====================================================================
# 종합 SEPA 분석
# ====================================================================
def run_sepa_analysis(ticker, info, daily_df, benchmark_df=None):
    """단일 종목 SEPA 전체 분석"""
    current_price = float(daily_df['Close'].iloc[-1]) if daily_df is not None and len(daily_df) > 0 else 0
    
    # 트렌드 템플릿
    template = check_trend_template(daily_df)
    
    # RS Rating
    rs = calc_rs_rating(daily_df, benchmark_df) if benchmark_df is not None else {
        'outperform': False, 'rs_score': 0, 'stock_6m': 0, 'stock_3m': 0
    }
    
    # VCP 분석
    vcp = analyze_vcp_detailed(daily_df)
    
    # 매매 계획
    trade_plan = calc_sepa_trade_plan(current_price, vcp.get('pivot_line', 0), vcp)
    
    # 종합 판정
    template_pass = template['score'] >= 7
    rs_pass = rs.get('outperform', False) or rs.get('rs_score', 0) > 0
    vcp_ready = vcp.get('score', 0) >= 4
    
    if template_pass and rs_pass and vcp_ready:
        verdict = '매수준비 🟢'
    elif template_pass and (rs_pass or vcp_ready):
        verdict = '워치리스트 🟡'
    else:
        verdict = '패스 🔴'
    
    return {
        'ticker': ticker,
        'name': info.get('name', ticker),
        'sector': info.get('sector', ''),
        'current_price': current_price,
        'template': template,
        'rs': rs,
        'vcp': vcp,
        'trade_plan': trade_plan,
        'verdict': verdict,
    }

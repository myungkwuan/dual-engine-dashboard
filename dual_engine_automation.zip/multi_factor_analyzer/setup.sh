#!/bin/bash
# ============================================================
# 듀얼엔진 자동화 시스템 — 원클릭 설정 스크립트
# ============================================================
# 사용법: chmod +x setup.sh && ./setup.sh
# ============================================================

set -e

# 색상
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}  🎯 듀얼엔진 자동화 시스템 설정${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# ── Step 1: Python 의존성 설치 ──
echo -e "${GREEN}[1/5]${NC} Python 패키지 설치 중..."
pip3 install yfinance pandas numpy --quiet 2>/dev/null || \
pip install yfinance pandas numpy --quiet 2>/dev/null || \
{ echo -e "${RED}pip 설치 실패. Python 3.8+이 필요합니다.${NC}"; exit 1; }
echo -e "  ${GREEN}✅${NC} yfinance, pandas, numpy 설치 완료"

# ── Step 2: 디렉토리 생성 ──
echo -e "${GREEN}[2/5]${NC} 디렉토리 생성..."
mkdir -p "$SCRIPT_DIR/output"
mkdir -p "$SCRIPT_DIR/cache"
mkdir -p "$SCRIPT_DIR/logs"
mkdir -p "$SCRIPT_DIR/history"
echo -e "  ${GREEN}✅${NC} output, cache, logs, history 생성 완료"

# ── Step 3: .env 파일 확인 ──
echo -e "${GREEN}[3/5]${NC} 설정 파일 확인..."
if [ ! -f "$SCRIPT_DIR/.env" ]; then
    cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"
    echo -e "  ${YELLOW}⚠️  .env 파일이 생성되었습니다.${NC}"
    echo -e "  ${YELLOW}    텔레그램/슬랙 토큰을 입력해주세요:${NC}"
    echo -e "  ${YELLOW}    nano $SCRIPT_DIR/.env${NC}"
else
    echo -e "  ${GREEN}✅${NC} .env 파일 존재"
fi

# ── Step 4: 테스트 실행 ──
echo -e "${GREEN}[4/5]${NC} 테스트 실행 (5종목)..."
cd "$SCRIPT_DIR"
python3 auto_runner.py --mode us --limit 5 --no-notify --no-html 2>&1 | tail -5
echo -e "  ${GREEN}✅${NC} 테스트 실행 완료"

# ── Step 5: 크론잡 설정 ──
echo ""
echo -e "${GREEN}[5/5]${NC} 크론잡 설정"
echo ""

# .env에서 시간 읽기
CRON_HOUR=$(grep CRON_HOUR "$SCRIPT_DIR/.env" 2>/dev/null | grep -v '^#' | cut -d= -f2 | tr -d ' ' || echo "7")
CRON_MINUTE=$(grep CRON_MINUTE "$SCRIPT_DIR/.env" 2>/dev/null | grep -v '^#' | cut -d= -f2 | tr -d ' ' || echo "30")
CRON_HOUR=${CRON_HOUR:-7}
CRON_MINUTE=${CRON_MINUTE:-30}

CRON_CMD="$CRON_MINUTE $CRON_HOUR * * 1-5 cd $SCRIPT_DIR && /usr/bin/python3 auto_runner.py --mode all >> $SCRIPT_DIR/logs/cron.log 2>&1"

echo "  등록할 크론잡:"
echo -e "  ${CYAN}$CRON_CMD${NC}"
echo ""
read -p "  크론잡을 등록하시겠습니까? (y/N): " confirm

if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
    # 기존 듀얼엔진 크론 제거 후 새로 추가
    (crontab -l 2>/dev/null | grep -v "auto_runner.py"; echo "$CRON_CMD") | crontab -
    echo -e "  ${GREEN}✅${NC} 크론잡 등록 완료!"
    echo -e "  매일 ${CRON_HOUR}시 ${CRON_MINUTE}분에 자동 실행됩니다."
    echo ""
    echo "  현재 크론잡 목록:"
    crontab -l 2>/dev/null | grep "auto_runner" || echo "  (없음)"
else
    echo -e "  ${YELLOW}⏭️${NC}  크론잡 등록을 건너뛰었습니다."
    echo "  수동 등록: crontab -e 에서 아래 줄 추가"
    echo "  $CRON_CMD"
fi

echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}  ✅ 설정 완료!${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "  사용법:"
echo -e "    ${GREEN}전체 실행:${NC}    python3 auto_runner.py --mode all"
echo -e "    ${GREEN}미국만:${NC}      python3 auto_runner.py --mode us"
echo -e "    ${GREEN}한국만:${NC}      python3 auto_runner.py --mode kr"
echo -e "    ${GREEN}테스트 (10):${NC} python3 auto_runner.py --limit 10"
echo -e "    ${GREEN}알림 테스트:${NC} python3 auto_runner.py --test-notify"
echo -e "    ${GREEN}알림 없이:${NC}   python3 auto_runner.py --no-notify"
echo ""
echo "  텔레그램 봇 설정이 아직이라면:"
echo -e "    1) ${CYAN}nano .env${NC} 에서 토큰/채팅ID 입력"
echo -e "    2) ${CYAN}python3 notifier.py${NC} 로 테스트"
echo ""

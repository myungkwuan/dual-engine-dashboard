"""
듀얼 모멘텀 시장 필터
절대 모멘텀 + 상대 모멘텀 + 시장 건강도
"""

def check_absolute_momentum(spy_12m_return):
    """절대 모멘텀: SPY 12개월 수익률 > 0%"""
    return {
        'pass': spy_12m_return > 0,
        'value': round(spy_12m_return, 2),
        'label': f'SPY 12M: {spy_12m_return:+.1f}%',
    }

def check_relative_momentum(returns_dict):
    """상대 모멘텀: 시장/섹터 간 비교"""
    sorted_markets = sorted(returns_dict.items(), key=lambda x: x[1], reverse=True)
    return {
        'ranking': sorted_markets,
        'strongest': sorted_markets[0] if sorted_markets else ('N/A', 0),
        'top3': sorted_markets[:3],
    }

def check_market_health(spy_vs_200d, new_high_low, ad_trend, vix):
    """시장 건강도 4가지 체크"""
    checks = {}
    
    checks['spy_200d'] = {
        'pass': spy_vs_200d == 'above',
        'label': f'S&P vs 200일선: {"위 ✅" if spy_vs_200d == "above" else "아래 ❌"}',
    }
    checks['new_hl'] = {
        'pass': new_high_low == 'bullish',
        'label': f'신고가/신저가: {"강세 ✅" if new_high_low == "bullish" else "약세 ❌"}',
    }
    checks['ad_line'] = {
        'pass': ad_trend == 'up',
        'label': f'A/D라인: {"상승 ✅" if ad_trend == "up" else "하락 ❌"}',
    }
    checks['vix'] = {
        'pass': vix < 20,
        'label': f'VIX: {vix:.1f} {"안정 ✅" if vix < 20 else "⚠️" if vix < 30 else "공포 ❌"}',
    }
    
    pass_count = sum(1 for c in checks.values() if c['pass'])
    return checks, pass_count

def determine_market_mode(abs_momentum, health_score):
    """시장 모드 종합 판정"""
    if not abs_momentum['pass']:
        return {
            'mode': 'cash',
            'emoji': '🔴',
            'label': '현금 모드',
            'description': '절대 모멘텀 FAIL → 신규 매수 전면 중단',
            'max_allocation': 0,
        }
    
    if health_score >= 3:
        return {
            'mode': 'attack',
            'emoji': '🟢',
            'label': '공격 모드',
            'description': f'절대 모멘텀 PASS + 건강도 {health_score}/4 → 정상 매매',
            'max_allocation': 100,
        }
    else:
        return {
            'mode': 'defense',
            'emoji': '🟡',
            'label': '방어 모드',
            'description': f'절대 모멘텀 PASS + 건강도 {health_score}/4 → 비중 50% 제한',
            'max_allocation': 50,
        }

def run_market_filter(spy_12m, market_returns, spy_200d, new_hl, ad_trend, vix):
    """시장 필터 전체 실행"""
    abs_mom = check_absolute_momentum(spy_12m)
    rel_mom = check_relative_momentum(market_returns)
    health_checks, health_score = check_market_health(spy_200d, new_hl, ad_trend, vix)
    mode = determine_market_mode(abs_mom, health_score)
    
    # 강세 섹터 (상위 3)
    sector_returns = {k: v for k, v in market_returns.items() if k.startswith('XL') or k.startswith('섹터')}
    strong_sectors = check_relative_momentum(sector_returns)
    
    return {
        'absolute_momentum': abs_mom,
        'relative_momentum': rel_mom,
        'health': health_checks,
        'health_score': health_score,
        'market_mode': mode,
        'strong_sectors': strong_sectors.get('top3', []),
    }

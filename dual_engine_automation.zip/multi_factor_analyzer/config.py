"""
멀티팩터 × 멀티타임프레임 분석 시스템 — 설정 파일
200종목 전광판 기반
"""

# ============================================================
# 한국 주식 (KRX) — yfinance 포맷: 종목코드.KS (코스피) / .KQ (코스닥)
# ============================================================
KR_STOCKS = {
    # === 지수 ETF ===
    "069500.KS": {"name": "KODEX200", "sector": "지수ETF"},
    "229200.KQ": {"name": "KODEX 코스닥150", "sector": "지수ETF"},
    "114800.KS": {"name": "KODEX인버스", "sector": "지수ETF"},
    "251340.KS": {"name": "KODEX코스닥인버스", "sector": "지수ETF"},

    # === AI반도체 ===
    "000660.KS": {"name": "SK하이닉스", "sector": "AI반도체", "score": 96.5},
    "005930.KS": {"name": "삼성전자", "sector": "AI반도체", "score": 84},
    "042700.KQ": {"name": "한미반도체", "sector": "AI반도체", "score": 81},
    "403870.KQ": {"name": "HPSP", "sector": "AI반도체", "score": 90.5},
    "058470.KQ": {"name": "리노공업", "sector": "AI반도체", "score": 92},

    # === 전력설비 ===
    "267260.KS": {"name": "HD현대일렉트릭", "sector": "전력설비", "score": 78.5},
    "010120.KS": {"name": "LS ELECTRIC", "sector": "전력설비", "score": 80.5},
    "298040.KS": {"name": "효성중공업", "sector": "전력설비", "score": 73},
    "229640.KQ": {"name": "LS에코에너지", "sector": "전력설비", "score": 59.5},
    "001440.KS": {"name": "대한전선", "sector": "전력설비", "score": 56.5},

    # === 원전SMR ===
    "034020.KS": {"name": "두산에너빌리티", "sector": "원전SMR", "score": 69},
    "052690.KS": {"name": "한전기술", "sector": "원전SMR", "score": 61},
    "051600.KS": {"name": "한전KPS", "sector": "원전SMR", "score": 64},
    "105840.KQ": {"name": "우진", "sector": "원전SMR", "score": 59.5},
    "083650.KQ": {"name": "비에이치아이", "sector": "원전SMR", "score": 66},

    # === K-방산 ===
    "012450.KS": {"name": "한화에어로스페이스", "sector": "K-방산", "score": 78},
    "064350.KS": {"name": "현대로템", "sector": "K-방산", "score": 71},
    "079550.KS": {"name": "LIG넥스원", "sector": "K-방산", "score": 65},
    "047810.KS": {"name": "한국항공우주", "sector": "K-방산", "score": 65},
    "272210.KS": {"name": "한화시스템", "sector": "K-방산", "score": 54},

    # === 우주 ===
    "189300.KQ": {"name": "인텔리안테크", "sector": "우주", "score": 57},
    "099320.KQ": {"name": "세트렉아이", "sector": "우주", "score": 53},
    "211270.KQ": {"name": "AP위성", "sector": "우주", "score": 38},
    "450190.KQ": {"name": "컨텍", "sector": "우주", "score": 39},

    # === 로봇 ===
    "277810.KQ": {"name": "레인보우로보틱스", "sector": "로봇", "score": 36.5},
    "454910.KQ": {"name": "두산로보틱스", "sector": "로봇", "score": 26.5},
    "098460.KQ": {"name": "고영", "sector": "로봇", "score": 54},
    "108490.KQ": {"name": "로보티즈", "sector": "로봇", "score": 43},
    "022100.KS": {"name": "포스코DX", "sector": "로봇", "score": 50.5},
    "058610.KQ": {"name": "에스피지", "sector": "로봇", "score": 64.5},

    # === 조선해양 ===
    "329180.KS": {"name": "HD현대중공업", "sector": "조선해양", "score": 66.5},
    "010140.KS": {"name": "삼성중공업", "sector": "조선해양", "score": 71.5},
    "042660.KS": {"name": "한화오션", "sector": "조선해양", "score": 72.5},
    "009540.KS": {"name": "HD한국조선해양", "sector": "조선해양", "score": 81.5},
    "082740.KS": {"name": "한화엔진", "sector": "조선해양", "score": 61.5},

    # === 바이오 ===
    "207940.KS": {"name": "삼성바이오로직스", "sector": "바이오", "score": 77.5},
    "196170.KQ": {"name": "알테오젠", "sector": "바이오", "score": 64.5},
    "068270.KS": {"name": "셀트리온", "sector": "바이오", "score": 81},
    "000100.KS": {"name": "유한양행", "sector": "바이오", "score": 62},
    "253840.KQ": {"name": "수젠택", "sector": "바이오"},
    "237690.KQ": {"name": "에스티팜", "sector": "바이오"},

    # === 이차전지 ===
    "373220.KS": {"name": "LG에너지솔루션", "sector": "이차전지", "score": 40},
    "005490.KS": {"name": "POSCO홀딩스", "sector": "이차전지", "score": 58},
    "247540.KQ": {"name": "에코프로비엠", "sector": "이차전지", "score": 32.5},
    "006400.KS": {"name": "삼성SDI", "sector": "이차전지", "score": 56},
    "066970.KQ": {"name": "엘앤에프", "sector": "이차전지"},

    # === 태양광 ===
    "009830.KS": {"name": "한화솔루션", "sector": "태양광", "score": 36},
    "322000.KS": {"name": "HD현대에너지", "sector": "태양광"},
    "010060.KS": {"name": "OCI홀딩스", "sector": "태양광"},
    "011930.KS": {"name": "신성이엔지", "sector": "태양광"},
    "389260.KQ": {"name": "대명에너지", "sector": "태양광"},

    # === K-뷰티 ===
    "257720.KQ": {"name": "실리콘투", "sector": "K-뷰티", "score": 72},
    "192820.KQ": {"name": "코스맥스", "sector": "K-뷰티", "score": 61},
    "278470.KQ": {"name": "에이피알", "sector": "K-뷰티", "score": 93},
    "214150.KQ": {"name": "클래시스", "sector": "K-뷰티", "score": 89},
    "214450.KQ": {"name": "파마리서치", "sector": "K-뷰티", "score": 84},

    # === 가상자산 ===
    "041190.KQ": {"name": "우리기술투자", "sector": "가상자산"},
    "112040.KQ": {"name": "위메이드", "sector": "가상자산"},
    "094480.KQ": {"name": "갤럭시아머니트리", "sector": "가상자산"},
    "063170.KQ": {"name": "서울옥션", "sector": "가상자산"},

    # === 반도체장비 ===
    "240810.KQ": {"name": "원익IPS", "sector": "반도체장비"},
    "036930.KQ": {"name": "주성엔지니어링", "sector": "반도체장비", "score": 66.5},
    "039030.KQ": {"name": "이오테크닉스", "sector": "반도체장비"},
    "067310.KQ": {"name": "하나마이크론", "sector": "반도체장비"},
    "036540.KQ": {"name": "SFA반도체", "sector": "반도체장비"},
    "489790.KQ": {"name": "한화비전", "sector": "반도체장비"},

    # === 자동차부품 ===
    "005380.KS": {"name": "현대차", "sector": "자동차부품", "score": 78.8},
    "000270.KS": {"name": "기아", "sector": "자동차부품", "score": 70.5},
    "012330.KS": {"name": "현대모비스", "sector": "자동차부품", "score": 68},
    "204320.KS": {"name": "HL만도", "sector": "자동차부품", "score": 57},
    "086280.KS": {"name": "현대글로비스", "sector": "자동차부품", "score": 69.5},

    # === 엔터테인먼트 ===
    "352820.KS": {"name": "하이브", "sector": "엔터", "score": 72},
    "035900.KQ": {"name": "JYP Ent.", "sector": "엔터"},
    "041510.KS": {"name": "에스엠", "sector": "엔터"},
    "035760.KS": {"name": "CJ ENM", "sector": "엔터"},
    "253450.KS": {"name": "스튜디오드래곤", "sector": "엔터"},

    # === 소프트웨어 ===
    "035420.KS": {"name": "NAVER", "sector": "소프트웨어", "score": 85.5},
    "035720.KS": {"name": "카카오", "sector": "소프트웨어", "score": 79},
    "018260.KS": {"name": "삼성SDS", "sector": "소프트웨어"},
    "067160.KQ": {"name": "SOOP(숲)", "sector": "소프트웨어"},
    "012510.KS": {"name": "더존비즈온", "sector": "소프트웨어"},

    # === 핀테크결제 ===
    "377300.KS": {"name": "카카오페이", "sector": "핀테크결제"},
    "035600.KQ": {"name": "KG이니시스", "sector": "핀테크결제"},
    "323410.KS": {"name": "카카오뱅크", "sector": "핀테크결제"},
    "046440.KQ": {"name": "KG모빌리언스", "sector": "핀테크결제"},
    "036800.KQ": {"name": "나이스정보통신", "sector": "핀테크결제"},
}

# ============================================================
# 미국 주식 (US)
# ============================================================
US_STOCKS = {
    # === AI반도체 ===
    "NVDA": {"name": "엔비디아", "sector": "AI반도체", "score": 91.5},
    "AVGO": {"name": "브로드컴", "sector": "AI반도체", "score": 83},
    "AMD": {"name": "AMD", "sector": "AI반도체", "score": 77.5},
    "ASML": {"name": "ASML", "sector": "AI반도체", "score": 90.5},
    "TSM": {"name": "TSMC", "sector": "AI반도체", "score": 87},
    "MU": {"name": "마이크론", "sector": "AI반도체", "score": 80},
    "INTC": {"name": "인텔", "sector": "AI반도체", "score": 30},
    "ARM": {"name": "ARM홀딩스", "sector": "AI반도체", "score": 70.5},
    "SNDK": {"name": "샌디스크", "sector": "AI반도체", "score": 74.5},

    # === 반도체장비 ===
    "AMAT": {"name": "어플라이드머티리얼즈", "sector": "반도체장비", "score": 79},
    "LRCX": {"name": "램리서치", "sector": "반도체장비", "score": 80},
    "KLAC": {"name": "KLA", "sector": "반도체장비", "score": 71.5},
    "SNPS": {"name": "시놉시스", "sector": "반도체장비", "score": 68},
    "CDNS": {"name": "케이던스", "sector": "반도체장비", "score": 80.5},

    # === 빅테크 ===
    "MSFT": {"name": "마이크로소프트", "sector": "빅테크", "score": 85.5},
    "GOOGL": {"name": "알파벳(구글)", "sector": "빅테크", "score": 88.6},
    "AMZN": {"name": "아마존", "sector": "빅테크", "score": 59},
    "META": {"name": "메타", "sector": "빅테크", "score": 74},
    "AAPL": {"name": "애플", "sector": "빅테크", "score": 86},

    # === 클라우드 ===
    "ORCL": {"name": "오라클", "sector": "클라우드", "score": 62},
    "PLTR": {"name": "팔란티어", "sector": "클라우드", "score": 85},
    "SNOW": {"name": "스노우플레이크", "sector": "클라우드", "score": 78},
    "ADBE": {"name": "어도비", "sector": "클라우드", "score": 80},
    "CRM": {"name": "세일즈포스", "sector": "클라우드", "score": 80.5},

    # === 사이버보안 ===
    "PANW": {"name": "팔로알토네트웍스", "sector": "사이버보안", "score": 70},
    "CRWD": {"name": "크라우드스트라이크", "sector": "사이버보안", "score": 70},
    "FTNT": {"name": "포티넷", "sector": "사이버보안"},
    "NET": {"name": "클라우드플레어", "sector": "사이버보안"},
    "ZS": {"name": "지스케일러", "sector": "사이버보안"},

    # === 전력인프라 ===
    "VST": {"name": "비스트라에너지", "sector": "전력인프라", "score": 75},
    "GEV": {"name": "GE버노바", "sector": "전력인프라", "score": 82.5},
    "VRT": {"name": "버티브", "sector": "전력인프라", "score": 84.5},
    "PWR": {"name": "콴타서비스", "sector": "전력인프라", "score": 82.5},

    # === 원자력 ===
    "CCJ": {"name": "카메코", "sector": "원자력"},
    "CEG": {"name": "컨스텔레이션에너지", "sector": "원자력", "score": 41.5},
    "BWXT": {"name": "BWX테크놀로지", "sector": "원자력"},
    "OKLO": {"name": "오클로", "sector": "원자력", "score": 38},
    "LEU": {"name": "센트러스에너지", "sector": "원자력"},

    # === 태양광 ===
    "FSLR": {"name": "퍼스트솔라", "sector": "태양광", "score": 63.5},
    "ENPH": {"name": "엔파스에너지", "sector": "태양광", "score": 50},
    "NEE": {"name": "넥스트에라에너지", "sector": "태양광", "score": 81},
    "RUN": {"name": "썬런", "sector": "태양광"},
    "CSIQ": {"name": "캐너디안솔라", "sector": "태양광"},

    # === 방산우주 ===
    "RTX": {"name": "RTX(레이시온)", "sector": "방산우주", "score": 73.5},
    "LMT": {"name": "록히드마틴", "sector": "방산우주", "score": 70.5},
    "NOC": {"name": "노스롭그루먼", "sector": "방산우주", "score": 80},
    "GD": {"name": "제너럴다이내믹스", "sector": "방산우주", "score": 71.5},
    "KTOS": {"name": "크라토스", "sector": "방산우주", "score": 54.5},

    # === 로봇자율 ===
    "TSLA": {"name": "테슬라", "sector": "로봇자율", "score": 55},
    "ISRG": {"name": "인튜이티브서지컬", "sector": "로봇자율", "score": 82.5},
    "ROK": {"name": "로크웰오토메이션", "sector": "로봇자율", "score": 62.5},
    "DE": {"name": "디어앤컴퍼니", "sector": "로봇자율", "score": 62.5},
    "UBER": {"name": "우버", "sector": "로봇자율", "score": 77.5},

    # === 비만치료 ===
    "LLY": {"name": "일라이릴리", "sector": "비만치료", "score": 91},
    "NVO": {"name": "노보노디스크", "sector": "비만치료", "score": 61},
    "VRTX": {"name": "버텍스파마슈티컬", "sector": "비만치료", "score": 79},
    "AMGN": {"name": "암젠", "sector": "비만치료", "score": 76.5},
    "VKTX": {"name": "바이킹테라퓨틱스", "sector": "비만치료", "score": 59},

    # === 의료기기 ===
    "BSX": {"name": "보스턴사이언티픽", "sector": "의료기기"},
    "SYK": {"name": "스트라이커", "sector": "의료기기"},
    "ABT": {"name": "애보트", "sector": "의료기기"},
    "DXCM": {"name": "덱스콤", "sector": "의료기기"},
    "EW": {"name": "에드워즈라이프사이언스", "sector": "의료기기"},

    # === 산업재 ===
    "CAT": {"name": "캐터필러", "sector": "산업재", "score": 76},
    "URI": {"name": "유나이티드렌탈", "sector": "산업재", "score": 78},
    "PH": {"name": "파커하니핀", "sector": "산업재", "score": 77},
    "GE": {"name": "GE에어로스페이스", "sector": "산업재", "score": 75},
    "WM": {"name": "웨이스트매니지먼트", "sector": "산업재", "score": 72.5},

    # === 크립토 ===
    "MSTR": {"name": "마이크로스트래티지", "sector": "크립토"},
    "COIN": {"name": "코인베이스", "sector": "크립토", "score": 56.5},
    "CRCL": {"name": "써클", "sector": "크립토", "score": 56},
    "HOOD": {"name": "로빈후드", "sector": "크립토", "score": 65},
    "XYZ": {"name": "블록(스퀘어)", "sector": "크립토"},

    # === 금융결제 ===
    "V": {"name": "비자", "sector": "금융결제"},
    "MA": {"name": "마스터카드", "sector": "금융결제"},
    "JPM": {"name": "JP모건체이스", "sector": "금융결제"},
    "AXP": {"name": "아메리칸익스프레스", "sector": "금융결제"},
    "KKR": {"name": "KKR", "sector": "금융결제"},

    # === 소비재 ===
    "COST": {"name": "코스트코", "sector": "소비재"},
    "WMT": {"name": "월마트", "sector": "소비재"},
    "NFLX": {"name": "넷플릭스", "sector": "소비재", "score": 78.5},
    "CMG": {"name": "치폴레", "sector": "소비재"},
    "BKNG": {"name": "부킹홀딩스", "sector": "소비재"},

    # === 제약 ===
    "MRK": {"name": "머크", "sector": "제약", "score": 73},
    "ABBV": {"name": "애브비", "sector": "제약", "score": 78},
    "JNJ": {"name": "존슨앤존슨", "sector": "제약", "score": 77.5},
    "PFE": {"name": "화이자", "sector": "제약", "score": 51},
    "BMY": {"name": "브리스톨마이어스", "sector": "제약", "score": 68},

    # === 데이터센터 ===
    "SMCI": {"name": "슈퍼마이크로", "sector": "데이터센터", "score": 48},
    "DELL": {"name": "델테크놀로지", "sector": "데이터센터", "score": 74},
    "EQIX": {"name": "에퀴닉스", "sector": "데이터센터", "score": 79},
    "DLR": {"name": "디지털리얼티", "sector": "데이터센터", "score": 77.5},
    "IRM": {"name": "아이언마운틴", "sector": "데이터센터", "score": 74},

    # === 광케이블 ===
    "ANET": {"name": "아리스타네트웍스", "sector": "광케이블", "score": 80},
    "GLW": {"name": "코닝", "sector": "광케이블", "score": 81.5},
    "CIEN": {"name": "시에나", "sector": "광케이블", "score": 68},
    "LITE": {"name": "루멘텀", "sector": "광케이블", "score": 53},
    "COHR": {"name": "코히런트", "sector": "광케이블", "score": 64},

    # === 우주 ===
    "RKLB": {"name": "로켓랩", "sector": "우주", "score": 58.5},
    "ASTS": {"name": "AST스페이스모바일", "sector": "우주", "score": 36},

    # === 원유 ===
    "OXY": {"name": "옥시덴탈", "sector": "원유", "score": 48.5},
    "XOM": {"name": "엑슨모빌", "sector": "원유", "score": 70},
    "RIG": {"name": "트랜스오션", "sector": "원유", "score": 46.5},
}

# ============================================================
# ETF / 원자재 / 국가지수
# ============================================================
ETFS = {
    "PDBC": {"name": "원자재", "sector": "원자재"},
    "GLD": {"name": "금", "sector": "원자재"},
    "SLV": {"name": "은", "sector": "원자재"},
    "COPX": {"name": "구리", "sector": "원자재"},
    "VOO": {"name": "S&P500", "sector": "미국지수"},
    "EWY": {"name": "한국지수", "sector": "국가지수"},
    "KWEB": {"name": "중국지수", "sector": "국가지수"},
    "EWJ": {"name": "일본지수", "sector": "국가지수"},
    "INDA": {"name": "인도지수", "sector": "국가지수"},
    "VNM": {"name": "베트남지수", "sector": "국가지수"},
    "EWG": {"name": "독일지수", "sector": "국가지수"},
    "EWW": {"name": "멕시코지수", "sector": "국가지수"},
    "FXY": {"name": "엔화", "sector": "통화"},
    "TLT": {"name": "미국장기채", "sector": "채권"},
    "QQQ": {"name": "나스닥", "sector": "미국지수"},
    "SOXX": {"name": "반도체ETF", "sector": "미국지수"},
    "PSQ": {"name": "나스닥인버스", "sector": "미국지수"},
    "SH": {"name": "S&P인버스", "sector": "미국지수"},
}

# ============================================================
# 포트폴리오 보유종목 (추가 티커)
# ============================================================
PORTFOLIO_EXTRA = {
    "KMI": {"name": "킨더모건", "sector": "에너지인프라"},
    "O": {"name": "리얼티인컴", "sector": "리츠"},
    "MP": {"name": "MP머티리얼즈", "sector": "희토류"},
    "IREN": {"name": "아이렌", "sector": "크립토마이닝"},
    "FLNC": {"name": "프루언스에너지", "sector": "에너지저장"},
}

# ============================================================
# 분석 파라미터
# ============================================================
ANALYSIS_PARAMS = {
    "short_term": {
        "period": "6mo",        # 데이터 기간
        "interval": "1d",       # 캔들 간격
        "rsi_period": 14,
        "stoch_k": 14,
        "stoch_d": 3,
        "bb_period": 20,
        "bb_std": 2,
        "macd_fast": 12,
        "macd_slow": 26,
        "macd_signal": 9,
    },
    "mid_term": {
        "period": "2y",
        "interval": "1wk",
        "rsi_period": 14,
        "macd_fast": 12,
        "macd_slow": 26,
        "macd_signal": 9,
        "adx_period": 14,
    },
    "long_term": {
        "period": "10y",
        "interval": "1mo",
        "rsi_period": 14,
        "macd_fast": 12,
        "macd_slow": 26,
        "macd_signal": 9,
        "ma_period": 60,  # 60개월 이동평균
    },
}

def get_all_tickers():
    """모든 티커 목록 반환"""
    all_tickers = {}
    all_tickers.update(KR_STOCKS)
    all_tickers.update(US_STOCKS)
    all_tickers.update(ETFS)
    all_tickers.update(PORTFOLIO_EXTRA)
    return all_tickers

def get_us_tickers():
    """미국 주식 + ETF + 포트폴리오 추가 티커"""
    t = {}
    t.update(US_STOCKS)
    t.update(ETFS)
    t.update(PORTFOLIO_EXTRA)
    return t

def get_kr_tickers():
    """한국 주식 티커"""
    return KR_STOCKS

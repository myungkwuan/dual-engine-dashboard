# 🎯 듀얼엔진 자동화 가이드

## 전체 구조도

```
매일 오전 7:30 KST (크론잡 또는 Claude Code)
 │
 ├─ [1] 시장 필터 ──── SPY/VIX/섹터 ETF 수집
 │     └─ 듀얼모멘텀 → 🟢공격 / 🟡방어 / 🔴현금 모드 판정
 │
 ├─ [2] 데이터 수집 ── yfinance로 200종목 일봉/주봉/월봉
 │
 ├─ [3] 멀티팩터 분석 ─ 3Factor × 3Timeframe = 9셀 매트릭스
 │     ├─ F1: 가격구조 (SMC/VCP/Dow)
 │     ├─ F2: 거래량 (VWAP/VP/OBV)
 │     └─ F3: 모멘텀 (RSI/MACD/BB/ADX)
 │
 ├─ [4] SEPA 분석 ──── TT(8조건) + VCP(7체크) + RS Rating
 │
 ├─ [5] 대시보드 ────── HTML 파일 자동 갱신
 │
 ├─ [6] 알림 전송 ──── 텔레그램 + 슬랙
 │     ├─ 일일 리포트 (매수준비/워치/듀얼TOP)
 │     └─ 변동 알림 (신규 시그널/이탈 종목)
 │
 └─ [7] 히스토리 ────── 일별 결과 저장 (전일 비교용)
```

---

## 1. 기본 설치

```bash
# 프로젝트 다운로드 후
cd multi_factor_analyzer

# 의존성 설치
pip install yfinance pandas numpy

# 디렉토리 생성
mkdir -p output cache logs history
```

---

## 2. 텔레그램 봇 설정 (5분)

### Step 1: 봇 생성
1. 텔레그램에서 **@BotFather** 검색
2. `/newbot` 입력
3. 봇 이름 입력 (예: `DualEngine분석봇`)
4. 봇 username 입력 (예: `dual_engine_bot`)
5. **토큰**이 발급됨 → 복사

### Step 2: 채팅 ID 확인
1. 생성된 봇과 대화 시작 (아무 메시지 전송)
2. 브라우저에서 접속:
   ```
   https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates
   ```
3. JSON 응답에서 `"chat":{"id":123456789}` → 이 숫자가 채팅 ID

### Step 3: .env 파일 설정
```bash
cp .env.example .env
nano .env
```

```env
ENABLE_TELEGRAM=true
TELEGRAM_BOT_TOKEN=7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxx
TELEGRAM_CHAT_ID=123456789
```

### Step 4: 테스트
```bash
python3 notifier.py
# → 텔레그램에 테스트 메시지가 오면 성공!
```

---

## 3. 슬랙 웹훅 설정 (선택)

1. https://api.slack.com/apps → Create New App
2. **Incoming Webhooks** → Activate
3. **Add New Webhook to Workspace** → 채널 선택
4. Webhook URL 복사

```env
ENABLE_SLACK=true
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/T00/B00/xxxx
```

---

## 4. 실행 방법

### 수동 실행
```bash
# 전체 200종목 분석 + 알림
python3 auto_runner.py --mode all

# 미국만 / 한국만
python3 auto_runner.py --mode us
python3 auto_runner.py --mode kr

# 테스트 (10종목, 알림 없이)
python3 auto_runner.py --limit 10 --no-notify

# 알림만 테스트
python3 auto_runner.py --test-notify
```

### 크론잡 자동화 (원클릭)
```bash
chmod +x setup.sh
./setup.sh
```

### 크론잡 수동 등록
```bash
crontab -e

# 매일 오전 7:30 (평일만) 전체 분석 실행
30 7 * * 1-5 cd /path/to/multi_factor_analyzer && python3 auto_runner.py --mode all >> logs/cron.log 2>&1

# 미국장 마감 후 추가 분석 (오전 6시, 선택)
0 6 * * 2-6 cd /path/to/multi_factor_analyzer && python3 auto_runner.py --mode us --no-html >> logs/cron_us.log 2>&1
```

---

## 5. Claude Code 연동

### 방법 A: Claude Code에서 직접 실행
```bash
# Claude Code 터미널에서
cd /path/to/multi_factor_analyzer
python3 auto_runner.py --mode all --no-notify

# Claude Code가 결과를 읽고 해석
cat output/combined_results.json | head -100
```

### 방법 B: Claude Code + CLAUDE.md 자동화
프로젝트 루트에 `CLAUDE.md` 파일을 만들면 Claude Code가 자동으로 참조합니다:

```markdown
# CLAUDE.md

## 프로젝트 개요
200종목 듀얼엔진(멀티팩터 + SEPA) 분석 시스템

## 일일 루틴
1. `python3 auto_runner.py --mode all` 실행
2. `output/combined_results.json` 결과 분석
3. SEPA 매수준비(🟢) 종목의 진입 타점 검토
4. 전일 대비 변동 사항 확인

## 핵심 규칙
- 컨플루언스 점수 2/3 이상만 진입 후보
- 상위 타임프레임 우선 (월봉 > 주봉 > 일봉)
- SEPA TT 7/8 이상 + VCP 4/7 이상만 워치리스트
- 듀얼엔진 TOP PICK = SEPA🟢 + MF 1.8점 이상

## 파일 구조
- auto_runner.py: 전체 파이프라인
- output/combined_results.json: 최신 분석 결과
- history/results_YYYYMMDD.json: 일별 히스토리
```

### 방법 C: Claude Code 스케줄 실행
```bash
# Claude Code에서 일일 분석 요청 예시:
# "auto_runner.py를 실행하고 SEPA 매수준비 종목을 분석해줘"
# "오늘 새로 매수 시그널이 뜬 종목이 있는지 확인해줘"
# "history 폴더에서 최근 5일간 NVDA의 점수 변화를 추적해줘"
```

---

## 6. 텔레그램 알림 예시

```
🎯 듀얼엔진 일일 리포트
2025-02-25 07:30

━━━ 시장 필터 ━━━
🟢 미국: 공격 모드 (건강도 3/4)
🟢 한국: 공격 모드 (건강도 3/4)

━━━ 🟢 SEPA 매수준비 (3) ━━━
NVIDIA (NVDA)
  $875.20 (+2.3%) | TT:8/8 VCP:6/7
  피봇: $882.50 | R:R 2.3:1

GE Vernova (GEV)
  $412.30 (+1.8%) | TT:8/8 VCP:5/7
  피봇: $418.00 | R:R 2.1:1

━━━ ⭐ 듀얼엔진 TOP PICK ━━━
🏆 NVIDIA (NVDA)
  현재: $875.20
  진입: $882.50 → 손절: $820.73 → 목표: $1,014.88
  MF: 2.3 | SEPA: TT8/8

━━━ 📊 요약 ━━━
분석종목: 119개
SEPA매수: 3 | 워치: 12
MF강매수: 8 | 듀얼TOP: 1
```

---

## 7. 파일 구조

```
multi_factor_analyzer/
├── auto_runner.py        ← 🔥 메인 자동화 스크립트
├── notifier.py           ← 📱 텔레그램/슬랙 알림
├── setup.sh              ← 🔧 원클릭 설정
├── .env.example          ← 📝 설정 템플릿
├── .env                  ← 🔑 실제 설정 (git 제외)
│
├── config.py             ← 200종목 리스트
├── data_fetcher.py       ← yfinance 데이터 수집
├── factors/
│   ├── price_structure.py   Factor 1: 가격구조
│   ├── volume_profile.py    Factor 2: 거래량
│   └── momentum.py          Factor 3: 모멘텀
├── confluence.py         ← 컨플루언스 스코어링
├── sepa_analyzer.py      ← SEPA 엔진
├── market_filter.py      ← 듀얼 모멘텀 필터
├── main.py               ← 레거시 실행기
│
├── output/
│   ├── combined_dashboard.html  ← 대시보드
│   └── combined_results.json    ← 최신 결과
├── history/
│   └── results_20250225.json    ← 일별 히스토리
├── logs/
│   └── run_20250225_073000.log  ← 실행 로그
└── cache/                       ← 데이터 캐시
```

---

## 8. 트러블슈팅

| 문제 | 해결 |
|------|------|
| `ModuleNotFoundError: yfinance` | `pip install yfinance` |
| 텔레그램 전송 실패 | `.env`에서 토큰/채팅ID 확인 |
| 데이터 수집 느림 | `--limit 50`으로 종목 수 제한 |
| 크론잡 실행 안됨 | `crontab -l`로 등록 확인, 파이썬 경로 확인 |
| 일부 한국 종목 실패 | `.KS` → `.KQ` (코스닥) 확인 |
| Permission denied | `chmod +x setup.sh auto_runner.py` |
| 캐시 만료 | `rm -rf cache/*` 후 재실행 |

---

## 9. 확장 로드맵

- [ ] **실적 캘린더 연동** — 실적 발표 3일전 경고
- [ ] **포트폴리오 트래커** — 실제 매수 후 손익 추적
- [ ] **백테스트 모듈** — 과거 데이터로 전략 검증
- [ ] **Claude API 해석** — 상위 10종목 자연어 리포트
- [ ] **웹 대시보드** — Streamlit/Flask 실시간 서비스
- [ ] **모바일 앱** — Telegram Mini App으로 대시보드 접근

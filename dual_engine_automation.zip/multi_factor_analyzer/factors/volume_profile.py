"""
Factor 2: 거래량 프로파일 분석 (Volume Profile)
- 단기: VWAP + 세션별 VP
- 중기: 고정범위 Volume Profile (HVN/LVN)
- 장기: 누적 VP + OBV 추세
"""
import pandas as pd
import numpy as np

# ====================================================================
# VWAP 계산
# ====================================================================
def calc_vwap(df, period=20):
    """VWAP (Volume Weighted Average Price) 계산"""
    if df is None or len(df) < period:
        return None, None, None
    
    subset = df.tail(period).copy()
    tp = (subset['High'] + subset['Low'] + subset['Close']) / 3
    cumvol = subset['Volume'].cumsum()
    cumtp = (tp * subset['Volume']).cumsum()
    
    vwap = cumtp / cumvol
    
    # VWAP 밴드 (±1 표준편차)
    squared_diff = ((tp - vwap) ** 2 * subset['Volume']).cumsum() / cumvol
    std = np.sqrt(squared_diff)
    
    vwap_val = float(vwap.iloc[-1])
    upper = float((vwap + std).iloc[-1])
    lower = float((vwap - std).iloc[-1])
    
    return vwap_val, upper, lower

# ====================================================================
# Volume Profile 계산
# ====================================================================
def calc_volume_profile(df, bins=30):
    """
    가격대별 거래량 분포 계산
    Returns: POC(Point of Control), Value Area High/Low, HVN, LVN
    """
    if df is None or len(df) < 10:
        return {}
    
    price_min = float(df['Low'].min())
    price_max = float(df['High'].max())
    
    if price_max <= price_min:
        return {}
    
    bin_edges = np.linspace(price_min, price_max, bins + 1)
    bin_volume = np.zeros(bins)
    
    for _, row in df.iterrows():
        low = float(row['Low'])
        high = float(row['High'])
        vol = float(row['Volume'])
        
        for j in range(bins):
            bin_low = bin_edges[j]
            bin_high = bin_edges[j + 1]
            
            if high >= bin_low and low <= bin_high:
                overlap = min(high, bin_high) - max(low, bin_low)
                total_range = high - low if high > low else 1
                bin_volume[j] += vol * (overlap / total_range)
    
    # POC: 최대 거래량 가격대
    poc_idx = np.argmax(bin_volume)
    poc = float((bin_edges[poc_idx] + bin_edges[poc_idx + 1]) / 2)
    
    # Value Area (70% of total volume)
    total_vol = bin_volume.sum()
    target_vol = total_vol * 0.70
    
    sorted_indices = np.argsort(bin_volume)[::-1]
    cumulative = 0
    va_indices = []
    for idx in sorted_indices:
        va_indices.append(idx)
        cumulative += bin_volume[idx]
        if cumulative >= target_vol:
            break
    
    va_indices = sorted(va_indices)
    va_high = float(bin_edges[max(va_indices) + 1]) if va_indices else price_max
    va_low = float(bin_edges[min(va_indices)]) if va_indices else price_min
    
    # HVN (High Volume Node) — 상위 20% 거래량 노드
    threshold_high = np.percentile(bin_volume, 80)
    hvn = []
    for j in range(bins):
        if bin_volume[j] >= threshold_high:
            hvn.append(round(float((bin_edges[j] + bin_edges[j+1]) / 2), 2))
    
    # LVN (Low Volume Node) — 하위 20% 거래량 노드 (빈 구간)
    threshold_low = np.percentile(bin_volume[bin_volume > 0], 20) if np.any(bin_volume > 0) else 0
    lvn = []
    for j in range(bins):
        if 0 < bin_volume[j] <= threshold_low:
            lvn.append(round(float((bin_edges[j] + bin_edges[j+1]) / 2), 2))
    
    return {
        'poc': round(poc, 2),
        'va_high': round(va_high, 2),
        'va_low': round(va_low, 2),
        'hvn': hvn[:5],
        'lvn': lvn[:5],
    }

# ====================================================================
# OBV (On-Balance Volume) 분석
# ====================================================================
def calc_obv(df):
    """OBV 계산 및 추세 분석"""
    if df is None or len(df) < 20:
        return {'trend': '중립', 'divergence': None}
    
    close = df['Close'].values
    volume = df['Volume'].values
    
    obv = np.zeros(len(close))
    obv[0] = volume[0]
    
    for i in range(1, len(close)):
        if close[i] > close[i-1]:
            obv[i] = obv[i-1] + volume[i]
        elif close[i] < close[i-1]:
            obv[i] = obv[i-1] - volume[i]
        else:
            obv[i] = obv[i-1]
    
    # OBV 추세 (20기간 기울기)
    lookback = min(20, len(obv) - 1)
    obv_slope = (obv[-1] - obv[-lookback]) / lookback if lookback > 0 else 0
    price_slope = (close[-1] - close[-lookback]) / lookback if lookback > 0 else 0
    
    # OBV 추세 방향
    if obv_slope > 0:
        obv_trend = '상승'
    elif obv_slope < 0:
        obv_trend = '하락'
    else:
        obv_trend = '중립'
    
    # 다이버전스 체크
    divergence = None
    if price_slope > 0 and obv_slope < 0:
        divergence = 'bearish'  # 가격↑ OBV↓ → 약세 다이버전스
    elif price_slope < 0 and obv_slope > 0:
        divergence = 'bullish'  # 가격↓ OBV↑ → 강세 다이버전스
    
    return {
        'trend': obv_trend,
        'divergence': divergence,
        'obv_current': float(obv[-1]),
    }

# ====================================================================
# 종합 거래량 분석
# ====================================================================
def analyze_short_term_volume(df):
    """단기 거래량 분석"""
    if df is None or len(df) < 20:
        return {'signal': '중립'}
    
    current_price = float(df['Close'].iloc[-1])
    vwap, vwap_upper, vwap_lower = calc_vwap(df, period=20)
    
    # 최근 20일 VP
    vp = calc_volume_profile(df.tail(30))
    obv = calc_obv(df.tail(60))
    
    signal = '중립'
    
    if vwap:
        # VWAP 하단이고 HVN 지지 겹침 → 매수
        if current_price < vwap and vp.get('hvn'):
            for hvn in vp['hvn']:
                if abs(current_price - hvn) / current_price < 0.03:
                    signal = '매수'
                    break
        
        # VWAP 상단이고 저항 겹침 → 매도
        if current_price > vwap_upper:
            signal = '매도'
        
        # VWAP 근처 + OBV 강세 → 매수
        if abs(current_price - vwap) / vwap < 0.02 and obv['trend'] == '상승':
            signal = '매수'
    
    # OBV 다이버전스 오버라이드
    if obv['divergence'] == 'bearish' and signal == '매수':
        signal = '중립'
    elif obv['divergence'] == 'bullish' and signal == '매도':
        signal = '중립'
    
    return {
        'signal': signal,
        'vwap': round(vwap, 2) if vwap else None,
        'vwap_upper': round(vwap_upper, 2) if vwap_upper else None,
        'vwap_lower': round(vwap_lower, 2) if vwap_lower else None,
        'vp': vp,
        'obv': obv,
        'premium_discount': 'premium' if (vwap and current_price > vwap) else 'discount',
    }

def analyze_mid_term_volume(df):
    """중기 거래량 분석 (주봉)"""
    if df is None or len(df) < 12:
        return {'signal': '중립'}
    
    current_price = float(df['Close'].iloc[-1])
    
    # 3~6개월 VP
    lookback = min(26, len(df))
    vp = calc_volume_profile(df.tail(lookback))
    obv = calc_obv(df)
    
    # 최근 4주 평균 거래량 vs 이전 12주 평균
    recent_vol = float(df['Volume'].tail(4).mean())
    prior_vol = float(df['Volume'].tail(16).head(12).mean()) if len(df) >= 16 else recent_vol
    vol_ratio = recent_vol / prior_vol if prior_vol > 0 else 1
    
    signal = '중립'
    
    # VP HVN 지지 + 거래량 건조함 → 매수 (매집 신호)
    if vp.get('hvn') and vol_ratio < 0.7:
        for hvn in vp['hvn']:
            if abs(current_price - hvn) / current_price < 0.05:
                signal = '매수'
                break
    
    # OBV 추세로 보강
    if obv['trend'] == '상승' and signal == '중립':
        if vp.get('va_low') and current_price >= vp['va_low']:
            signal = '매수'
    elif obv['trend'] == '하락' and signal == '중립':
        if vp.get('va_high') and current_price <= vp['va_high']:
            signal = '매도'
    
    return {
        'signal': signal,
        'vp': vp,
        'obv': obv,
        'vol_ratio': round(vol_ratio, 2),
        'volume_dry': vol_ratio < 0.7,
    }

def analyze_long_term_volume(df):
    """장기 거래량 분석 (월봉)"""
    if df is None or len(df) < 12:
        return {'signal': '중립'}
    
    current_price = float(df['Close'].iloc[-1])
    
    # 전체 기간 VP
    vp = calc_volume_profile(df)
    obv = calc_obv(df)
    
    signal = '중립'
    
    # VA 하단 근접 + OBV 상승 → 장기 매수
    if vp.get('va_low'):
        if current_price <= vp['va_low'] * 1.05 and obv['trend'] == '상승':
            signal = '매수'
        elif current_price >= vp.get('va_high', float('inf')) * 0.95 and obv['trend'] == '하락':
            signal = '매도'
    
    # OBV 다이버전스
    if obv['divergence'] == 'bullish':
        signal = '매수'
    elif obv['divergence'] == 'bearish':
        signal = '매도'
    
    return {
        'signal': signal,
        'vp': vp,
        'obv': obv,
    }

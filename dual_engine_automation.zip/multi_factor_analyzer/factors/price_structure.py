"""
Factor 1: 가격 구조 분석 (Price Structure)
- 단기: SMC(Order Block, FVG, BOS/CHoCH)
- 중기: VCP + 피보나치
- 장기: 다우이론 + 이동평균
"""
import pandas as pd
import numpy as np

# ====================================================================
# 공통 유틸리티
# ====================================================================
def identify_swing_highs_lows(df, window=5):
    """스윙 고점/저점 식별"""
    highs = []
    lows = []
    close = df['Close'].values
    high = df['High'].values
    low = df['Low'].values
    
    for i in range(window, len(df) - window):
        if high[i] == max(high[i-window:i+window+1]):
            highs.append((i, float(high[i])))
        if low[i] == min(low[i-window:i+window+1]):
            lows.append((i, float(low[i])))
    
    return highs, lows

def determine_trend(df, lookback=50):
    """추세 판정: 고점-저점 구조 기반"""
    if df is None or len(df) < lookback:
        return "중립", []
    
    subset = df.tail(lookback)
    highs, lows = identify_swing_highs_lows(subset, window=3)
    
    if len(highs) < 2 or len(lows) < 2:
        return "중립", []
    
    # 고점이 높아지고 저점이 높아지면 상승추세
    higher_highs = highs[-1][1] > highs[-2][1] if len(highs) >= 2 else False
    higher_lows = lows[-1][1] > lows[-2][1] if len(lows) >= 2 else False
    lower_highs = highs[-1][1] < highs[-2][1] if len(highs) >= 2 else False
    lower_lows = lows[-1][1] < lows[-2][1] if len(lows) >= 2 else False
    
    if higher_highs and higher_lows:
        trend = "상승추세"
    elif lower_highs and lower_lows:
        trend = "하락추세"
    else:
        trend = "횡보"
    
    return trend, highs + lows

# ====================================================================
# 단기 분석: SMC 컨셉
# ====================================================================
def find_order_blocks(df, lookback=50):
    """오더블록(OB) 식별 — 강한 이동 직전의 마지막 반대 캔들"""
    if df is None or len(df) < lookback:
        return []
    
    subset = df.tail(lookback).copy()
    obs = []
    close = subset['Close'].values
    open_p = subset['Open'].values
    high = subset['High'].values
    low = subset['Low'].values
    idx = subset.index
    
    for i in range(2, len(subset) - 1):
        # Bullish OB: 하락 캔들 후 강한 상승
        if close[i-1] < open_p[i-1]:  # 하락 캔들
            if close[i] > high[i-1] and (close[i] - open_p[i]) > 0:  # 강한 상승
                obs.append({
                    'type': 'bullish',
                    'top': float(open_p[i-1]),
                    'bottom': float(close[i-1]),
                    'date': str(idx[i-1].date()) if hasattr(idx[i-1], 'date') else str(idx[i-1]),
                })
        
        # Bearish OB: 상승 캔들 후 강한 하락
        if close[i-1] > open_p[i-1]:  # 상승 캔들
            if close[i] < low[i-1] and (open_p[i] - close[i]) > 0:  # 강한 하락
                obs.append({
                    'type': 'bearish',
                    'top': float(close[i-1]),
                    'bottom': float(open_p[i-1]),
                    'date': str(idx[i-1].date()) if hasattr(idx[i-1], 'date') else str(idx[i-1]),
                })
    
    return obs[-5:]  # 최근 5개만

def find_fvg(df, lookback=30):
    """Fair Value Gap(FVG) 식별"""
    if df is None or len(df) < lookback:
        return []
    
    subset = df.tail(lookback).copy()
    fvgs = []
    high = subset['High'].values
    low = subset['Low'].values
    idx = subset.index
    
    for i in range(2, len(subset)):
        # Bullish FVG: 3번째 캔들 저가 > 1번째 캔들 고가
        if low[i] > high[i-2]:
            fvgs.append({
                'type': 'bullish',
                'top': float(low[i]),
                'bottom': float(high[i-2]),
                'date': str(idx[i].date()) if hasattr(idx[i], 'date') else str(idx[i]),
            })
        
        # Bearish FVG: 3번째 캔들 고가 < 1번째 캔들 저가
        if high[i] < low[i-2]:
            fvgs.append({
                'type': 'bearish',
                'top': float(low[i-2]),
                'bottom': float(high[i]),
                'date': str(idx[i].date()) if hasattr(idx[i], 'date') else str(idx[i]),
            })
    
    return fvgs[-5:]

def detect_bos_choch(df, lookback=50):
    """BOS(Break of Structure) / CHoCH(Change of Character) 감지"""
    if df is None or len(df) < lookback:
        return {"bos": None, "choch": None}
    
    subset = df.tail(lookback)
    highs, lows = identify_swing_highs_lows(subset, window=3)
    
    result = {"bos": None, "choch": None}
    close_now = float(subset['Close'].iloc[-1])
    
    if len(highs) >= 2 and len(lows) >= 2:
        last_high = highs[-1][1]
        prev_high = highs[-2][1]
        last_low = lows[-1][1]
        prev_low = lows[-2][1]
        
        # 상승추세에서 BOS: 직전 고점 돌파
        if close_now > last_high and last_high > prev_high:
            result['bos'] = {'direction': 'bullish', 'level': last_high}
        
        # 하락추세에서 BOS: 직전 저점 이탈
        if close_now < last_low and last_low < prev_low:
            result['bos'] = {'direction': 'bearish', 'level': last_low}
        
        # CHoCH: 추세 전환 (상승추세에서 저점 이탈)
        if last_high < prev_high and close_now < last_low:
            result['choch'] = {'direction': 'bearish', 'level': last_low}
        elif last_low > prev_low and close_now > last_high:
            result['choch'] = {'direction': 'bullish', 'level': last_high}
    
    return result

def analyze_short_term_structure(df):
    """단기 가격구조 종합 분석"""
    if df is None or len(df) < 30:
        return {'signal': '중립', 'details': {}}
    
    trend, _ = determine_trend(df, lookback=30)
    obs = find_order_blocks(df)
    fvgs = find_fvg(df)
    structure = detect_bos_choch(df)
    
    current_price = float(df['Close'].iloc[-1])
    
    # 매수/매도 신호 판정
    signal = '중립'
    support_levels = []
    resistance_levels = []
    
    # Bullish OB 근처이고 상승추세 → 매수
    for ob in obs:
        if ob['type'] == 'bullish':
            support_levels.append(ob['bottom'])
            if current_price <= ob['top'] * 1.02 and current_price >= ob['bottom'] * 0.98:
                signal = '매수'
        elif ob['type'] == 'bearish':
            resistance_levels.append(ob['top'])
            if current_price >= ob['bottom'] * 0.98 and current_price <= ob['top'] * 1.02:
                signal = '매도'
    
    # BOS 강화
    if structure['bos']:
        if structure['bos']['direction'] == 'bullish':
            signal = '매수' if signal != '매도' else '중립'
        else:
            signal = '매도' if signal != '매수' else '중립'
    
    # CHoCH는 강한 전환 시그널
    if structure['choch']:
        signal = '매수' if structure['choch']['direction'] == 'bullish' else '매도'
    
    # 추세가 상승인데 조정 중이면 매수 우세
    if trend == '상승추세' and signal == '중립':
        # 20일 이평선 위에 있으면 매수 유지
        ma20 = df['Close'].rolling(20).mean().iloc[-1]
        if current_price > ma20:
            signal = '매수'
    elif trend == '하락추세' and signal == '중립':
        signal = '매도'
    
    return {
        'signal': signal,
        'trend': trend,
        'current_price': current_price,
        'order_blocks': obs,
        'fvg': fvgs,
        'structure': structure,
        'support': sorted(support_levels)[-3:] if support_levels else [],
        'resistance': sorted(resistance_levels)[:3] if resistance_levels else [],
    }

# ====================================================================
# 중기 분석: VCP + 피보나치
# ====================================================================
def calc_fibonacci_levels(high, low):
    """피보나치 되돌림 레벨 계산"""
    diff = high - low
    return {
        '0.0': high,
        '0.236': high - diff * 0.236,
        '0.382': high - diff * 0.382,
        '0.5': high - diff * 0.5,
        '0.618': high - diff * 0.618,
        '0.786': high - diff * 0.786,
        '1.0': low,
        '1.272': low - diff * 0.272,
        '1.618': low - diff * 0.618,
    }

def detect_vcp(df, lookback=52):
    """VCP(Volatility Contraction Pattern) 감지"""
    if df is None or len(df) < lookback:
        return {'detected': False}
    
    subset = df.tail(lookback)
    close = subset['Close'].values
    high = subset['High'].values
    low = subset['Low'].values
    
    # 4구간으로 나누어 변동성 수축 확인
    quarter = lookback // 4
    volatilities = []
    for i in range(4):
        start = i * quarter
        end = start + quarter
        segment_range = (max(high[start:end]) - min(low[start:end])) / np.mean(close[start:end])
        volatilities.append(segment_range)
    
    # 변동성이 점차 줄어드는지 확인
    contracting = all(volatilities[i] >= volatilities[i+1] for i in range(len(volatilities)-1))
    
    # 피봇 포인트 (최근 고점)
    recent_high = float(max(high[-quarter:]))
    
    return {
        'detected': contracting,
        'volatilities': [round(v * 100, 2) for v in volatilities],
        'pivot_point': recent_high,
        'contraction_ratio': round(volatilities[-1] / volatilities[0] * 100, 1) if volatilities[0] > 0 else 0,
    }

def analyze_mid_term_structure(df):
    """중기 가격구조 종합 분석"""
    if df is None or len(df) < 20:
        return {'signal': '중립', 'details': {}}
    
    trend, _ = determine_trend(df, lookback=min(52, len(df)))
    current_price = float(df['Close'].iloc[-1])
    
    # 최근 고점/저점으로 피보나치
    lookback = min(52, len(df))
    subset = df.tail(lookback)
    swing_high = float(subset['High'].max())
    swing_low = float(subset['Low'].min())
    fib = calc_fibonacci_levels(swing_high, swing_low)
    
    # VCP 감지
    vcp = detect_vcp(df)
    
    # 20주 이평선
    ma20 = float(df['Close'].rolling(20).mean().iloc[-1]) if len(df) >= 20 else current_price
    
    # 신호 판정
    signal = '중립'
    
    # 피보나치 38.2~61.8% 구간에 있고 추세 상승이면 매수
    if fib['0.618'] <= current_price <= fib['0.382']:
        if trend == '상승추세':
            signal = '매수'
        elif trend == '하락추세':
            signal = '매도'
    
    # VCP 감지되고 피봇 근처면 매수
    if vcp['detected'] and current_price >= vcp['pivot_point'] * 0.97:
        signal = '매수'
    
    # 20주 이평 위/아래
    if current_price > ma20 and trend == '상승추세':
        if signal == '중립':
            signal = '매수'
    elif current_price < ma20 and trend == '하락추세':
        if signal == '중립':
            signal = '매도'
    
    return {
        'signal': signal,
        'trend': trend,
        'current_price': current_price,
        'fibonacci': {k: round(v, 2) for k, v in fib.items()},
        'vcp': vcp,
        'ma20w': round(ma20, 2),
        'swing_high': round(swing_high, 2),
        'swing_low': round(swing_low, 2),
    }

# ====================================================================
# 장기 분석: 다우이론 + 이동평균
# ====================================================================
def analyze_long_term_structure(df):
    """장기 가격구조 종합 분석"""
    if df is None or len(df) < 12:
        return {'signal': '중립', 'details': {}}
    
    trend, _ = determine_trend(df, lookback=min(60, len(df)))
    current_price = float(df['Close'].iloc[-1])
    
    # 60개월(5년) 이동평균
    ma60 = float(df['Close'].rolling(min(60, len(df))).mean().iloc[-1])
    
    # 200일선 근사 (월봉에서 ~10개월)
    ma10 = float(df['Close'].rolling(min(10, len(df))).mean().iloc[-1])
    
    # 역사적 고점/저점
    all_high = float(df['High'].max())
    all_low = float(df['Low'].min())
    
    # 현재 가격의 역사적 위치 (0~100%)
    if all_high > all_low:
        historical_position = (current_price - all_low) / (all_high - all_low) * 100
    else:
        historical_position = 50
    
    # 신호 판정
    signal = '중립'
    
    if current_price > ma60 and trend == '상승추세':
        signal = '매수'
    elif current_price < ma60 and trend == '하락추세':
        signal = '매도'
    
    # 역사적 저점 근처 (하위 25%)면 장기 매수 기회
    if historical_position < 25 and current_price > ma10:
        signal = '매수'
    elif historical_position > 90:
        signal = '매도'
    
    return {
        'signal': signal,
        'trend': trend,
        'current_price': current_price,
        'ma60m': round(ma60, 2),
        'ma10m': round(ma10, 2),
        'all_time_high': round(all_high, 2),
        'all_time_low': round(all_low, 2),
        'historical_position': round(historical_position, 1),
    }

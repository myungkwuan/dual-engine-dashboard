"""
Factor 3: 모멘텀 & 오실레이터 분석 (Momentum)
- 단기: RSI + 스토캐스틱 + 볼린저밴드 + MACD
- 중기: MACD 주봉 + RSI + ADX
- 장기: RSI 월봉 + MACD 히스토그램 + 200일선 기울기
"""
import pandas as pd
import numpy as np

# ====================================================================
# 지표 계산 함수들
# ====================================================================
def calc_rsi(series, period=14):
    """RSI 계산"""
    delta = series.diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    
    avg_gain = gain.ewm(span=period, adjust=False).mean()
    avg_loss = loss.ewm(span=period, adjust=False).mean()
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calc_stochastic(df, k_period=14, d_period=3):
    """스토캐스틱 K, D 계산"""
    low_min = df['Low'].rolling(k_period).min()
    high_max = df['High'].rolling(k_period).max()
    
    k = 100 * (df['Close'] - low_min) / (high_max - low_min)
    d = k.rolling(d_period).mean()
    
    return k, d

def calc_macd(series, fast=12, slow=26, signal=9):
    """MACD, Signal, Histogram 계산"""
    ema_fast = series.ewm(span=fast, adjust=False).mean()
    ema_slow = series.ewm(span=slow, adjust=False).mean()
    
    macd = ema_fast - ema_slow
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line
    
    return macd, signal_line, histogram

def calc_bollinger(series, period=20, std_dev=2):
    """볼린저밴드 계산"""
    middle = series.rolling(period).mean()
    std = series.rolling(period).std()
    
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    
    return upper, middle, lower

def calc_adx(df, period=14):
    """ADX (Average Directional Index) 계산"""
    high = df['High']
    low = df['Low']
    close = df['Close']
    
    plus_dm = high.diff()
    minus_dm = -low.diff()
    
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0)
    
    tr = pd.DataFrame({
        'a': high - low,
        'b': abs(high - close.shift()),
        'c': abs(low - close.shift())
    }).max(axis=1)
    
    atr = tr.ewm(span=period, adjust=False).mean()
    plus_di = 100 * (plus_dm.ewm(span=period, adjust=False).mean() / atr)
    minus_di = 100 * (minus_dm.ewm(span=period, adjust=False).mean() / atr)
    
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    adx = dx.ewm(span=period, adjust=False).mean()
    
    return adx, plus_di, minus_di

# ====================================================================
# 다이버전스 체크
# ====================================================================
def check_divergence(price_series, indicator_series, lookback=20):
    """가격 vs 지표 다이버전스 확인"""
    if len(price_series) < lookback or len(indicator_series) < lookback:
        return None
    
    price = price_series.tail(lookback).values
    indicator = indicator_series.tail(lookback).values
    
    # 최근 2개 저점/고점 비교
    half = lookback // 2
    
    price_first_half_low = np.min(price[:half])
    price_second_half_low = np.min(price[half:])
    ind_first_half_low = np.min(indicator[:half])
    ind_second_half_low = np.min(indicator[half:])
    
    price_first_half_high = np.max(price[:half])
    price_second_half_high = np.max(price[half:])
    ind_first_half_high = np.max(indicator[:half])
    ind_second_half_high = np.max(indicator[half:])
    
    # Bullish divergence: 가격 저점 ↓ but 지표 저점 ↑
    if price_second_half_low < price_first_half_low and ind_second_half_low > ind_first_half_low:
        return 'bullish'
    
    # Bearish divergence: 가격 고점 ↑ but 지표 고점 ↓
    if price_second_half_high > price_first_half_high and ind_second_half_high < ind_first_half_high:
        return 'bearish'
    
    return None

# ====================================================================
# 추세 강도 판정
# ====================================================================
def get_trend_strength(adx_val=None, rsi_val=None, macd_hist=None):
    """추세 강도 5단계 판정"""
    score = 0
    
    if adx_val is not None:
        if adx_val > 40:
            score += 2
        elif adx_val > 25:
            score += 1
        elif adx_val < 15:
            score -= 1
    
    if rsi_val is not None:
        if rsi_val > 60:
            score += 1
        elif rsi_val < 40:
            score -= 1
    
    if macd_hist is not None:
        if macd_hist > 0:
            score += 1
        elif macd_hist < 0:
            score -= 1
    
    if score >= 3:
        return "강한 상승"
    elif score >= 1:
        return "약한 상승"
    elif score <= -3:
        return "강한 하락"
    elif score <= -1:
        return "약한 하락"
    else:
        return "중립"

# ====================================================================
# 타임프레임별 모멘텀 분석
# ====================================================================
def analyze_short_term_momentum(df):
    """단기 모멘텀 분석 (일봉)"""
    if df is None or len(df) < 30:
        return {'signal': '중립'}
    
    close = df['Close']
    current_price = float(close.iloc[-1])
    
    # RSI
    rsi = calc_rsi(close, 14)
    rsi_val = float(rsi.iloc[-1])
    
    # 스토캐스틱
    k, d = calc_stochastic(df, 14, 3)
    k_val = float(k.iloc[-1])
    d_val = float(d.iloc[-1])
    stoch_golden = k_val > d_val and float(k.iloc[-2]) <= float(d.iloc[-2]) if len(k) > 2 else False
    
    # 볼린저밴드
    bb_upper, bb_middle, bb_lower = calc_bollinger(close, 20, 2)
    bb_upper_val = float(bb_upper.iloc[-1])
    bb_lower_val = float(bb_lower.iloc[-1])
    bb_middle_val = float(bb_middle.iloc[-1])
    
    # MACD
    macd, signal_line, histogram = calc_macd(close, 12, 26, 9)
    macd_val = float(macd.iloc[-1])
    signal_val = float(signal_line.iloc[-1])
    hist_val = float(histogram.iloc[-1])
    macd_golden = macd_val > signal_val and float(macd.iloc[-2]) <= float(signal_line.iloc[-2]) if len(macd) > 2 else False
    
    # 다이버전스
    rsi_div = check_divergence(close, rsi)
    macd_div = check_divergence(close, macd)
    
    # 신호 판정
    signal = '중립'
    buy_signals = 0
    sell_signals = 0
    
    # RSI 과매도 + 스토캐스틱 골든크로스
    if rsi_val <= 35:
        buy_signals += 1
    elif rsi_val >= 70:
        sell_signals += 1
    
    if stoch_golden and k_val < 30:
        buy_signals += 1
    elif k_val > 80 and k_val < d_val:
        sell_signals += 1
    
    # 볼린저밴드 하단 터치
    if current_price <= bb_lower_val * 1.01:
        buy_signals += 1
    elif current_price >= bb_upper_val * 0.99:
        sell_signals += 1
    
    # MACD 골든크로스
    if macd_golden:
        buy_signals += 1
    elif hist_val < 0 and float(histogram.iloc[-2]) > 0 if len(histogram) > 2 else False:
        sell_signals += 1
    
    if buy_signals >= 2:
        signal = '매수'
    elif sell_signals >= 2:
        signal = '매도'
    elif buy_signals == 1 and sell_signals == 0:
        signal = '매수'
    elif sell_signals == 1 and buy_signals == 0:
        signal = '매도'
    
    # 다이버전스 오버라이드
    if rsi_div == 'bullish' or macd_div == 'bullish':
        if signal != '매도':
            signal = '매수'
    elif rsi_div == 'bearish' or macd_div == 'bearish':
        if signal != '매수':
            signal = '매도'
    
    return {
        'signal': signal,
        'rsi': round(rsi_val, 1),
        'stoch_k': round(k_val, 1),
        'stoch_d': round(d_val, 1),
        'stoch_golden_cross': stoch_golden,
        'bb_upper': round(bb_upper_val, 2),
        'bb_middle': round(bb_middle_val, 2),
        'bb_lower': round(bb_lower_val, 2),
        'macd': round(macd_val, 4),
        'macd_signal': round(signal_val, 4),
        'macd_histogram': round(hist_val, 4),
        'macd_golden_cross': macd_golden,
        'divergence_rsi': rsi_div,
        'divergence_macd': macd_div,
        'overbought': rsi_val >= 70,
        'oversold': rsi_val <= 30,
        'trend_strength': get_trend_strength(rsi_val=rsi_val, macd_hist=hist_val),
    }

def analyze_mid_term_momentum(df):
    """중기 모멘텀 분석 (주봉)"""
    if df is None or len(df) < 26:
        return {'signal': '중립'}
    
    close = df['Close']
    
    # RSI 주봉
    rsi = calc_rsi(close, 14)
    rsi_val = float(rsi.iloc[-1])
    
    # MACD 주봉
    macd, signal_line, histogram = calc_macd(close, 12, 26, 9)
    hist_val = float(histogram.iloc[-1])
    prev_hist = float(histogram.iloc[-2]) if len(histogram) > 1 else hist_val
    hist_slowing = abs(hist_val) < abs(prev_hist) and np.sign(hist_val) == np.sign(prev_hist)
    
    # ADX
    adx, plus_di, minus_di = calc_adx(df, 14)
    adx_val = float(adx.iloc[-1])
    
    # 신호 판정
    signal = '중립'
    
    # MACD 히스토그램 둔화 반전 + RSI 40~55 지지
    if hist_slowing and hist_val < 0 and 40 <= rsi_val <= 55:
        signal = '매수'
    elif hist_slowing and hist_val > 0 and rsi_val > 65:
        signal = '매도'
    
    # ADX 강한 추세 + RSI 방향
    if adx_val > 25:
        if rsi_val > 50 and hist_val > 0:
            signal = '매수'
        elif rsi_val < 50 and hist_val < 0:
            signal = '매도'
    
    rsi_div = check_divergence(close, rsi, lookback=min(20, len(close) - 1))
    
    return {
        'signal': signal,
        'rsi': round(rsi_val, 1),
        'macd_histogram': round(hist_val, 4),
        'histogram_slowing': hist_slowing,
        'adx': round(adx_val, 1),
        'trend_strength': get_trend_strength(adx_val, rsi_val, hist_val),
        'divergence_rsi': rsi_div,
    }

def analyze_long_term_momentum(df):
    """장기 모멘텀 분석 (월봉)"""
    if df is None or len(df) < 12:
        return {'signal': '중립'}
    
    close = df['Close']
    
    # RSI 월봉
    rsi = calc_rsi(close, 14)
    rsi_val = float(rsi.iloc[-1])
    
    # MACD 월봉 히스토그램
    macd, signal_line, histogram = calc_macd(close, 12, 26, 9)
    hist_val = float(histogram.iloc[-1])
    prev_hist = float(histogram.iloc[-2]) if len(histogram) > 1 else hist_val
    hist_reversal = (hist_val > prev_hist) if hist_val < 0 else (hist_val < prev_hist)
    
    # 200일선 근사 (월봉 ~10개월)
    ma10 = close.rolling(min(10, len(close))).mean()
    ma10_slope = float(ma10.iloc[-1] - ma10.iloc[-2]) if len(ma10) > 1 else 0
    
    # 신호 판정
    signal = '중립'
    
    # 월봉 RSI 40 이하 + MACD 히스토그램 바닥 반전
    if rsi_val <= 40 and hist_reversal and hist_val < 0:
        signal = '매수'
    elif rsi_val >= 70 and hist_reversal and hist_val > 0:
        signal = '매도'
    
    # 장기 이평선 기울기
    if ma10_slope > 0 and rsi_val > 45:
        if signal == '중립':
            signal = '매수'
    elif ma10_slope < 0 and rsi_val < 55:
        if signal == '중립':
            signal = '매도'
    
    return {
        'signal': signal,
        'rsi': round(rsi_val, 1),
        'macd_histogram': round(hist_val, 4),
        'histogram_reversal': hist_reversal,
        'ma_slope': 'positive' if ma10_slope > 0 else 'negative',
        'trend_strength': get_trend_strength(rsi_val=rsi_val, macd_hist=hist_val),
    }

"""
데모 데이터 생성기 — PDF 전광판의 실제 데이터를 기반으로 샘플 분석 결과 생성
로컬 실행 전 대시보드 미리보기용
"""
import json
import random
import os

# PDF에서 추출한 실제 데이터 기반
DEMO_DATA = [
    # 한국 AI반도체
    {"ticker": "000660.KS", "name": "SK하이닉스", "sector": "AI반도체", "price": 1018000, "score": 96.5, "kr": True},
    {"ticker": "005930.KS", "name": "삼성전자", "sector": "AI반도체", "price": 203500, "score": 84, "kr": True},
    {"ticker": "042700.KQ", "name": "한미반도체", "sector": "AI반도체", "price": 214500, "score": 81, "kr": True},
    {"ticker": "403870.KQ", "name": "HPSP", "sector": "AI반도체", "price": 41000, "score": 90.5, "kr": True},
    {"ticker": "058470.KQ", "name": "리노공업", "sector": "AI반도체", "price": 97200, "score": 92, "kr": True},
    # 전력설비
    {"ticker": "267260.KS", "name": "HD현대일렉트릭", "sector": "전력설비", "price": 1065000, "score": 78.5, "kr": True},
    {"ticker": "010120.KS", "name": "LS ELECTRIC", "sector": "전력설비", "price": 753000, "score": 80.5, "kr": True},
    {"ticker": "298040.KS", "name": "효성중공업", "sector": "전력설비", "price": 2763000, "score": 73, "kr": True},
    # K-방산
    {"ticker": "012450.KS", "name": "한화에어로스페이스", "sector": "K-방산", "price": 1212000, "score": 78, "kr": True},
    {"ticker": "064350.KS", "name": "현대로템", "sector": "K-방산", "price": 222500, "score": 71, "kr": True},
    # 조선해양
    {"ticker": "329180.KS", "name": "HD현대중공업", "sector": "조선해양", "price": 594000, "score": 66.5, "kr": True},
    {"ticker": "009540.KS", "name": "HD한국조선해양", "sector": "조선해양", "price": 467500, "score": 81.5, "kr": True},
    # 바이오
    {"ticker": "207940.KS", "name": "삼성바이오로직스", "sector": "바이오", "price": 1728000, "score": 77.5, "kr": True},
    {"ticker": "068270.KS", "name": "셀트리온", "sector": "바이오", "price": 244500, "score": 81, "kr": True},
    # K-뷰티
    {"ticker": "278470.KQ", "name": "에이피알", "sector": "K-뷰티", "price": 302000, "score": 93, "kr": True},
    {"ticker": "214150.KQ", "name": "클래시스", "sector": "K-뷰티", "price": 59900, "score": 89, "kr": True},
    # 자동차
    {"ticker": "005380.KS", "name": "현대차", "sector": "자동차부품", "price": 572000, "score": 78.8, "kr": True},
    {"ticker": "000270.KS", "name": "기아", "sector": "자동차부품", "price": 196100, "score": 70.5, "kr": True},
    # 소프트웨어
    {"ticker": "035420.KS", "name": "NAVER", "sector": "소프트웨어", "price": 253000, "score": 85.5, "kr": True},
    {"ticker": "035720.KS", "name": "카카오", "sector": "소프트웨어", "price": 57400, "score": 79, "kr": True},
    # 엔터
    {"ticker": "352820.KS", "name": "하이브", "sector": "엔터", "price": 396500, "score": 72, "kr": True},
    # 이차전지
    {"ticker": "373220.KS", "name": "LG에너지솔루션", "sector": "이차전지", "price": 426000, "score": 40, "kr": True},
    {"ticker": "006400.KS", "name": "삼성SDI", "sector": "이차전지", "price": 433000, "score": 56, "kr": True},
    # 로봇
    {"ticker": "277810.KQ", "name": "레인보우로보틱스", "sector": "로봇", "price": 788000, "score": 36.5, "kr": True},
    {"ticker": "058610.KQ", "name": "에스피지", "sector": "로봇", "price": 147300, "score": 64.5, "kr": True},
    
    # 미국 AI반도체
    {"ticker": "NVDA", "name": "엔비디아", "sector": "AI반도체", "price": 192.85, "score": 91.5},
    {"ticker": "AVGO", "name": "브로드컴", "sector": "AI반도체", "price": 325.49, "score": 83},
    {"ticker": "AMD", "name": "AMD", "sector": "AI반도체", "price": 213.84, "score": 77.5},
    {"ticker": "ASML", "name": "ASML", "sector": "AI반도체", "price": 1497.80, "score": 90.5},
    {"ticker": "TSM", "name": "TSMC", "sector": "AI반도체", "price": 385.75, "score": 87},
    {"ticker": "MU", "name": "마이크론", "sector": "AI반도체", "price": 418.01, "score": 80},
    # 빅테크
    {"ticker": "MSFT", "name": "마이크로소프트", "sector": "빅테크", "price": 389.00, "score": 85.5},
    {"ticker": "GOOGL", "name": "알파벳(구글)", "sector": "빅테크", "price": 310.90, "score": 88.6},
    {"ticker": "AMZN", "name": "아마존", "sector": "빅테크", "price": 208.56, "score": 59},
    {"ticker": "META", "name": "메타", "sector": "빅테크", "price": 639.30, "score": 74},
    {"ticker": "AAPL", "name": "애플", "sector": "빅테크", "price": 272.14, "score": 86},
    # 클라우드
    {"ticker": "PLTR", "name": "팔란티어", "sector": "클라우드", "price": 128.84, "score": 85},
    {"ticker": "ADBE", "name": "어도비", "sector": "클라우드", "price": 255.17, "score": 80},
    {"ticker": "CRM", "name": "세일즈포스", "sector": "클라우드", "price": 185.42, "score": 80.5},
    # 전력인프라
    {"ticker": "GEV", "name": "GE버노바", "sector": "전력인프라", "price": 879.73, "score": 82.5},
    {"ticker": "VRT", "name": "버티브", "sector": "전력인프라", "price": 253.15, "score": 84.5},
    {"ticker": "PWR", "name": "콴타서비스", "sector": "전력인프라", "price": 568.21, "score": 82.5},
    {"ticker": "VST", "name": "비스트라에너지", "sector": "전력인프라", "price": 171.62, "score": 75},
    # 반도체장비
    {"ticker": "AMAT", "name": "어플라이드머티리얼즈", "sector": "반도체장비", "price": 377.93, "score": 79},
    {"ticker": "LRCX", "name": "램리서치", "sector": "반도체장비", "price": 244.25, "score": 80},
    {"ticker": "CDNS", "name": "케이던스", "sector": "반도체장비", "price": 290.63, "score": 80.5},
    # 방산우주
    {"ticker": "RTX", "name": "RTX(레이시온)", "sector": "방산우주", "price": 198.46, "score": 73.5},
    {"ticker": "LMT", "name": "록히드마틴", "sector": "방산우주", "price": 664.43, "score": 70.5},
    {"ticker": "NOC", "name": "노스롭그루먼", "sector": "방산우주", "price": 727.73, "score": 80},
    # 로봇자율
    {"ticker": "TSLA", "name": "테슬라", "sector": "로봇자율", "price": 409.38, "score": 55},
    {"ticker": "ISRG", "name": "인튜이티브서지컬", "sector": "로봇자율", "price": 494.02, "score": 82.5},
    {"ticker": "UBER", "name": "우버", "sector": "로봇자율", "price": 71.38, "score": 77.5},
    # 비만치료
    {"ticker": "LLY", "name": "일라이릴리", "sector": "비만치료", "price": 1042.15, "score": 91},
    {"ticker": "VRTX", "name": "버텍스파마슈티컬", "sector": "비만치료", "price": 487.43, "score": 79},
    {"ticker": "AMGN", "name": "암젠", "sector": "비만치료", "price": 382.87, "score": 76.5},
    # 산업재
    {"ticker": "CAT", "name": "캐터필러", "sector": "산업재", "price": 768.23, "score": 76},
    {"ticker": "GE", "name": "GE에어로스페이스", "sector": "산업재", "price": 345.64, "score": 75},
    # 데이터센터
    {"ticker": "EQIX", "name": "에퀴닉스", "sector": "데이터센터", "price": 951.90, "score": 79},
    {"ticker": "DLR", "name": "디지털리얼티", "sector": "데이터센터", "price": 178.24, "score": 77.5},
    # 광케이블
    {"ticker": "ANET", "name": "아리스타네트웍스", "sector": "광케이블", "price": 128.77, "score": 80},
    {"ticker": "GLW", "name": "코닝", "sector": "광케이블", "price": 151.59, "score": 81.5},
    # 제약
    {"ticker": "ABBV", "name": "애브비", "sector": "제약", "price": 228.44, "score": 78},
    {"ticker": "JNJ", "name": "존슨앤존슨", "sector": "제약", "price": 246.28, "score": 77.5},
    # 크립토
    {"ticker": "COIN", "name": "코인베이스", "sector": "크립토", "price": 162.03, "score": 56.5},
    {"ticker": "HOOD", "name": "로빈후드", "sector": "크립토", "price": 73.39, "score": 65},
    # 소비재
    {"ticker": "NFLX", "name": "넷플릭스", "sector": "소비재", "price": 78.04, "score": 78.5},
    {"ticker": "COST", "name": "코스트코", "sector": "소비재", "price": 998.43, "score": 0},
    # 태양광
    {"ticker": "NEE", "name": "넥스트에라에너지", "sector": "태양광", "price": 95.68, "score": 81},
    {"ticker": "FSLR", "name": "퍼스트솔라", "sector": "태양광", "price": 243.21, "score": 63.5},
    # 원자력
    {"ticker": "CEG", "name": "컨스텔레이션에너지", "sector": "원자력", "price": 312.64, "score": 41.5},
    # 사이버보안
    {"ticker": "CRWD", "name": "크라우드스트라이크", "sector": "사이버보안", "price": 350.25, "score": 70},
    {"ticker": "PANW", "name": "팔로알토네트웍스", "sector": "사이버보안", "price": 141.67, "score": 70},
    # 우주
    {"ticker": "RKLB", "name": "로켓랩", "sector": "우주", "price": 69.97, "score": 58.5},
    # ETF
    {"ticker": "VOO", "name": "S&P500", "sector": "미국지수", "price": 632.21, "score": 0},
    {"ticker": "QQQ", "name": "나스닥", "sector": "미국지수", "price": 607.82, "score": 0},
    {"ticker": "GLD", "name": "금", "sector": "원자재", "price": 474.61, "score": 0},
    {"ticker": "SOXX", "name": "반도체ETF", "sector": "미국지수", "price": 362.04, "score": 0},
]

SIGNALS = ['매수', '매도', '중립']
TRENDS = ['상승추세', '하락추세', '횡보']
STRENGTHS = ['강한 상승', '약한 상승', '중립', '약한 하락', '강한 하락']

def gen_signal_weighted(bias=0):
    """bias: -1~1, positive=buy bias"""
    r = random.random() + bias * 0.3
    if r > 0.65: return '매수'
    elif r < 0.35: return '매도'
    return '중립'

def calc_confluence(s1, s2, s3):
    sigs = [s1, s2, s3]
    buy = sigs.count('매수')
    sell = sigs.count('매도')
    
    if buy == 3: return 3, '매수', '⭐ 강한 매수'
    if sell == 3: return 3, '매도', '⭐ 강한 매도'
    if buy == 2: return 2, '매수', '✅ 매수 우세'
    if sell == 2: return 2, '매도', '✅ 매도 우세'
    if buy == 1 and sell == 0: return 1, '매수', '⚠️ 약한 매수'
    if sell == 1 and buy == 0: return 1, '매도', '⚠️ 약한 매도'
    return 0, '중립', '❌ 관망'

def generate_demo_results():
    results = []
    random.seed(42)
    
    for d in DEMO_DATA:
        price = d['price']
        score = d['score']
        is_kr = d.get('kr', False)
        
        # 펀더멘탈 점수가 높으면 매수 bias
        bias = (score - 60) / 40 if score > 0 else 0
        
        # 각 타임프레임별 3-Factor 생성
        sf1 = gen_signal_weighted(bias)
        sf2 = gen_signal_weighted(bias * 0.8)
        sf3 = gen_signal_weighted(bias * 0.6)
        s_score, s_dir, s_grade = calc_confluence(sf1, sf2, sf3)
        
        mf1 = gen_signal_weighted(bias * 0.7)
        mf2 = gen_signal_weighted(bias * 0.5)
        mf3 = gen_signal_weighted(bias * 0.4)
        m_score, m_dir, m_grade = calc_confluence(mf1, mf2, mf3)
        
        lf1 = gen_signal_weighted(bias * 0.9)
        lf2 = gen_signal_weighted(bias * 0.6)
        lf3 = gen_signal_weighted(bias * 0.5)
        l_score, l_dir, l_grade = calc_confluence(lf1, lf2, lf3)
        
        # 정렬 상태
        dirs = [s_dir, m_dir, l_dir]
        if all(x == '매수' for x in dirs):
            alignment = {'status': '완전 정렬 (매수)', 'bonus': True, 'conflict': False}
        elif all(x == '매도' for x in dirs):
            alignment = {'status': '완전 정렬 (매도)', 'bonus': True, 'conflict': False}
        elif l_dir != s_dir and l_dir != '중립' and s_dir != '중립':
            alignment = {'status': f'⚠️ 충돌', 'bonus': False, 'conflict': True}
        else:
            alignment = {'status': '부분 정렬', 'bonus': False, 'conflict': False}
        
        # 가격 레벨
        rsi = round(random.uniform(25, 75), 1)
        trend = random.choice(TRENDS)
        strength = random.choice(STRENGTHS)
        
        mult = 1 if not is_kr else 1
        
        result = {
            'ticker': d['ticker'],
            'name': d['name'],
            'sector': d['sector'],
            'fundamental_score': score,
            'current_price': price,
            'short_term': {
                'f1': {'signal': sf1, 'trend': trend, 'support': [round(price*0.97,2)], 'resistance': [round(price*1.03,2)]},
                'f2': {'signal': sf2, 'vwap': round(price*0.99,2), 'vwap_upper': round(price*1.02,2), 'vwap_lower': round(price*0.97,2), 'vp': {'poc': round(price*0.98,2), 'hvn': [round(price*0.97,2)], 'lvn': [round(price*1.01,2)]},'obv': {'trend': '상승' if bias > 0 else '하락'}},
                'f3': {'signal': sf3, 'rsi': rsi, 'stoch_k': round(random.uniform(20,80),1), 'stoch_d': round(random.uniform(20,80),1), 'bb_upper': round(price*1.04,2), 'bb_middle': round(price*1.0,2), 'bb_lower': round(price*0.96,2), 'macd': round(random.uniform(-2,2),4), 'macd_histogram': round(random.uniform(-1,1),4), 'trend_strength': strength},
                'score': s_score, 'direction': s_dir, 'grade': s_grade,
            },
            'mid_term': {
                'f1': {'signal': mf1, 'trend': trend, 'fibonacci': {'0.382': round(price*0.95,2), '0.5': round(price*0.92,2), '0.618': round(price*0.89,2)}, 'vcp': {'detected': random.random() > 0.7}, 'ma20w': round(price*0.95,2), 'swing_high': round(price*1.08,2), 'swing_low': round(price*0.85,2)},
                'f2': {'signal': mf2, 'vp': {'poc': round(price*0.96,2)}, 'obv': {'trend': '상승' if bias > 0 else '하락'}, 'vol_ratio': round(random.uniform(0.5,1.5),2)},
                'f3': {'signal': mf3, 'rsi': round(random.uniform(35,65),1), 'macd_histogram': round(random.uniform(-1,1),4), 'adx': round(random.uniform(15,45),1), 'trend_strength': strength},
                'score': m_score, 'direction': m_dir, 'grade': m_grade,
            },
            'long_term': {
                'f1': {'signal': lf1, 'trend': trend, 'ma60m': round(price*0.85,2), 'ma10m': round(price*0.93,2), 'all_time_high': round(price*1.3,2), 'all_time_low': round(price*0.4,2), 'historical_position': round(random.uniform(30,85),1)},
                'f2': {'signal': lf2, 'vp': {'va_high': round(price*1.1,2), 'va_low': round(price*0.8,2)}, 'obv': {'trend': '상승' if bias > 0.2 else '하락'}},
                'f3': {'signal': lf3, 'rsi': round(random.uniform(35,65),1), 'macd_histogram': round(random.uniform(-0.5,0.5),4), 'trend_strength': strength},
                'score': l_score, 'direction': l_dir, 'grade': l_grade,
            },
            'alignment': alignment,
            'levels': {
                'short': {'entry': round(price*0.98,2), 'stop': round(price*0.95,2), 'target': round(price*1.05,2), 'rr': round(random.uniform(1.2,3.5),2)},
                'mid': {'entry': round(price*0.93,2), 'stop': round(price*0.85,2), 'target': round(price*1.15,2), 'rr': round(random.uniform(1.5,4.0),2)},
                'long': {'entry': round(price*0.85,2), 'stop': round(price*0.7,2), 'target': round(price*1.3,2), 'rr': round(random.uniform(2.0,5.0),2)},
            },
            'total_score': round(l_score * 0.4 + m_score * 0.35 + s_score * 0.25, 2),
            'total_direction': l_dir if l_dir != '중립' else (m_dir if m_dir != '중립' else s_dir),
        }
        
        results.append(result)
    
    results.sort(key=lambda x: x['total_score'], reverse=True)
    return results

if __name__ == '__main__':
    results = generate_demo_results()
    
    # 대시보드 생성
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from report_generator import generate_dashboard
    
    output_path = os.path.join(os.path.dirname(__file__), 'output', 'dashboard.html')
    generate_dashboard(results, output_path)
    print(f"✅ 데모 대시보드 생성: {output_path}")

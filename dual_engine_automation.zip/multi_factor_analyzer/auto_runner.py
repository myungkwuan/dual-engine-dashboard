#!/usr/bin/env python3
"""
듀얼엔진 자동 실행기 (Auto Runner)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
크론잡으로 매일 자동 실행:
  1) yfinance 데이터 수집 (200종목)
  2) 멀티팩터 3×3 분석
  3) SEPA 분석 (TT + VCP + RS)
  4) 시장 필터 (듀얼 모멘텀)
  5) HTML 대시보드 생성
  6) 텔레그램/슬랙 알림 전송
  7) 전일 대비 변동 추적
"""
import sys
import os
import json
import time
import logging
from datetime import datetime, timedelta

# 프로젝트 루트
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from config import get_all_tickers, US_STOCKS, KR_STOCKS, ETFS, PORTFOLIO_EXTRA
from data_fetcher import fetch_batch
from confluence import analyze_stock
from sepa_analyzer import run_sepa_analysis as _run_sepa
from market_filter import run_market_filter
from notifier import send_all

# ============================================================
# 로깅 설정
# ============================================================
LOG_DIR = os.path.join(ROOT, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

log_file = os.path.join(LOG_DIR, f'run_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler(sys.stdout),
    ]
)
log = logging.getLogger(__name__)

# ============================================================
# 결과 저장/로드 (전일 비교용)
# ============================================================
HISTORY_DIR = os.path.join(ROOT, 'history')
os.makedirs(HISTORY_DIR, exist_ok=True)

def save_results(results, market_data):
    """오늘 분석 결과를 history에 저장"""
    date_str = datetime.now().strftime('%Y%m%d')
    path = os.path.join(HISTORY_DIR, f'results_{date_str}.json')
    data = {
        'date': date_str,
        'timestamp': datetime.now().isoformat(),
        'market': market_data,
        'results': results,
    }
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, default=str)
    log.info(f'결과 저장: {path}')
    return path

def load_previous_results():
    """직전 분석 결과 로드"""
    files = sorted([f for f in os.listdir(HISTORY_DIR) if f.startswith('results_')])
    if len(files) < 2:
        return None
    prev_file = os.path.join(HISTORY_DIR, files[-2])
    try:
        with open(prev_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def cleanup_old_history(keep_days=30):
    """오래된 히스토리 정리"""
    cutoff = datetime.now() - timedelta(days=keep_days)
    for f in os.listdir(HISTORY_DIR):
        if f.startswith('results_'):
            try:
                date_str = f.replace('results_', '').replace('.json', '')
                file_date = datetime.strptime(date_str, '%Y%m%d')
                if file_date < cutoff:
                    os.remove(os.path.join(HISTORY_DIR, f))
                    log.info(f'히스토리 정리: {f}')
            except ValueError:
                pass

# ============================================================
# 시장 필터 데이터 수집
# ============================================================
def fetch_market_filter_data():
    """시장 필터용 데이터를 yfinance로 수집"""
    import yfinance as yf
    
    log.info('시장 필터 데이터 수집 중...')
    
    # SPY 12개월 수익률
    spy = yf.Ticker('SPY')
    spy_hist = spy.history(period='1y')
    spy_12m = 0
    spy_vs_200d = 'below'
    if len(spy_hist) > 0:
        spy_12m = ((spy_hist['Close'].iloc[-1] / spy_hist['Close'].iloc[0]) - 1) * 100
        if len(spy_hist) >= 200:
            ma200 = spy_hist['Close'].rolling(200).mean().iloc[-1]
            spy_vs_200d = 'above' if spy_hist['Close'].iloc[-1] > ma200 else 'below'
        else:
            ma_all = spy_hist['Close'].mean()
            spy_vs_200d = 'above' if spy_hist['Close'].iloc[-1] > ma_all else 'below'
    
    # VIX
    vix_val = 18.0
    try:
        vix = yf.Ticker('^VIX')
        vix_hist = vix.history(period='5d')
        if len(vix_hist) > 0:
            vix_val = float(vix_hist['Close'].iloc[-1])
    except Exception:
        pass
    
    # 시장/섹터 수익률 (12개월)
    etfs = {
        'SPY': 'S&P500', 'IWM': '러셀2000', 'EFA': '선진국', 'EEM': '신흥국',
        'XLK': '기술', 'XLI': '산업재', 'XLE': '에너지', 'XLF': '금융',
        'XLV': '헬스케어', 'XLU': '유틸리티', 'XLC': '통신',
    }
    
    market_returns = {}
    try:
        tickers_str = ' '.join(etfs.keys())
        data = yf.download(tickers_str, period='1y', progress=False)
        if data is not None and len(data) > 0:
            for tk, name in etfs.items():
                try:
                    if tk in data['Close'].columns:
                        series = data['Close'][tk].dropna()
                        if len(series) > 0:
                            ret = ((series.iloc[-1] / series.iloc[0]) - 1) * 100
                            market_returns[name] = round(ret, 1)
                except Exception:
                    pass
    except Exception as e:
        log.warning(f'ETF 수익률 수집 실패: {e}')
    
    # 간이 건강도 판정
    # 신고가/신저가 비율 (간이 — SPY가 상승추세면 bullish)
    new_hl = 'bullish' if spy_12m > 5 else 'bearish'
    # A/D 라인 (간이 — 최근 10일 상승일 비율)
    ad_trend = 'up'
    if len(spy_hist) >= 10:
        recent = spy_hist['Close'].tail(10)
        up_days = sum(1 for i in range(1, len(recent)) if recent.iloc[i] > recent.iloc[i-1])
        ad_trend = 'up' if up_days >= 5 else 'down'
    
    result = run_market_filter(
        spy_12m=spy_12m,
        market_returns=market_returns,
        spy_200d=spy_vs_200d,
        new_hl=new_hl,
        ad_trend=ad_trend,
        vix=vix_val,
    )
    
    # 한국 시장 필터 (코스피 기반)
    kr_result = {'mode': 'attack', 'mode_emoji': '🟢', 'mode_label': '공격 모드', 'health_score': 3}
    try:
        kospi = yf.Ticker('^KS11')
        k_hist = kospi.history(period='1y')
        if len(k_hist) > 0:
            k_12m = ((k_hist['Close'].iloc[-1] / k_hist['Close'].iloc[0]) - 1) * 100
            if k_12m < 0:
                kr_result = {'mode': 'cash', 'mode_emoji': '🔴', 'mode_label': '현금 모드', 'health_score': 1}
            elif k_12m < 5:
                kr_result = {'mode': 'defense', 'mode_emoji': '🟡', 'mode_label': '방어 모드', 'health_score': 2}
    except Exception:
        pass
    
    # 최종 포맷
    us_market = {
        'mode': result['market_mode']['mode'],
        'mode_emoji': result['market_mode']['emoji'],
        'mode_label': result['market_mode']['label'],
        'health_score': result['health_score'],
        'spy_12m': round(spy_12m, 1),
        'abs_pass': result['absolute_momentum']['pass'],
        'vix': round(vix_val, 1),
        'sectors': [(k, v) for k, v in sorted(market_returns.items(), key=lambda x: x[1], reverse=True) if k not in ['S&P500','러셀2000','선진국','신흥국']][:5],
        'markets': [(k, v) for k, v in sorted(market_returns.items(), key=lambda x: x[1], reverse=True) if k in ['S&P500','러셀2000','선진국','신흥국']],
    }
    
    market_data = {'us': us_market, 'kr': kr_result}
    log.info(f'시장 필터 완료: US={us_market["mode_label"]}, KR={kr_result["mode_label"]}')
    return market_data


# ============================================================
# SEPA 분석 래퍼
# ============================================================
def run_sepa_on_stock(ticker, daily_df, info, is_kr=False):
    """개별 종목 SEPA 분석 — sepa_analyzer.run_sepa_analysis 래퍼
    출력을 대시보드/알림 포맷으로 정규화"""
    current_price = float(daily_df['Close'].iloc[-1]) if daily_df is not None and len(daily_df) > 0 else 0
    
    try:
        raw = _run_sepa(ticker, info, daily_df, benchmark_df=None)
        
        # 템플릿 정규화
        tt = raw.get('template', {})
        template = {
            'score': tt.get('score', 0),
            'stage': tt.get('stage', 'N/A'),
            'ma50': round(tt.get('ma50', 0), 0 if is_kr else 2),
            'ma150': round(tt.get('ma150', 0), 0 if is_kr else 2),
            'ma200': round(tt.get('ma200', 0), 0 if is_kr else 2),
            'high_52w': round(tt.get('high_52w', 0), 0 if is_kr else 2),
            'low_52w': round(tt.get('low_52w', 0), 0 if is_kr else 2),
        }
        
        # RS 정규화
        rs_raw = raw.get('rs', {})
        rs = {
            'outperform': rs_raw.get('outperform', False) or rs_raw.get('rs_score', 0) > 0,
            'stock_6m': rs_raw.get('stock_6m', 0),
            'stock_3m': rs_raw.get('stock_3m', 0),
            'bench_6m': rs_raw.get('bench_6m', 0),
            'bench_3m': rs_raw.get('bench_3m', 0),
        }
        
        # VCP 정규화
        vcp_raw = raw.get('vcp', {})
        vcp = {
            'score': vcp_raw.get('score', 0),
            'maturity': vcp_raw.get('maturity', '🔴 미성숙'),
            'contractions': vcp_raw.get('contractions', vcp_raw.get('contraction_depths', [])),
            'pivot': vcp_raw.get('pivot_line', vcp_raw.get('pivot', current_price * 1.02)),
            'pct_to_pivot': vcp_raw.get('pct_to_pivot', 0),
        }
        
        # Trade 정규화
        tp = raw.get('trade_plan', raw.get('trade', {}))
        trade = {
            'entry': tp.get('entry', current_price * 1.02),
            'stop': tp.get('stop', tp.get('stop_loss', current_price * 0.93)),
            'target1': tp.get('target1', tp.get('target_1', current_price * 1.17)),
            'target2': tp.get('target2', tp.get('target_2', current_price * 1.32)),
            'rr': tp.get('rr', tp.get('risk_reward', '2.1')),
        }
        
        return {
            'template': template,
            'rs': rs,
            'vcp': vcp,
            'verdict': raw.get('verdict', '🔴 패스'),
            'trade': trade,
        }
    
    except Exception as e:
        log.warning(f'SEPA 분석 폴백: {ticker} - {e}')
        return {
            'template': {'score': 0, 'stage': 'N/A', 'ma50': 0, 'ma150': 0, 'ma200': 0, 'high_52w': 0, 'low_52w': 0},
            'rs': {'outperform': False, 'stock_6m': 0, 'stock_3m': 0, 'bench_6m': 0, 'bench_3m': 0},
            'vcp': {'score': 0, 'maturity': '🔴 미성숙', 'contractions': [], 'pivot': current_price * 1.02, 'pct_to_pivot': 2.0},
            'verdict': '🔴 패스',
            'trade': {'entry': current_price * 1.02, 'stop': current_price * 0.93, 'target1': current_price * 1.17, 'target2': current_price * 1.32, 'rr': '2.1'},
        }


# ============================================================
# 메인 파이프라인
# ============================================================
def run_full_pipeline(mode='all', limit=None, notify=True, generate_html=True):
    """
    전체 파이프라인 실행
    
    Args:
        mode: 'all' | 'us' | 'kr'
        limit: 종목 수 제한 (테스트용)
        notify: 알림 전송 여부
        generate_html: 대시보드 생성 여부
    """
    start_time = time.time()
    
    log.info('=' * 60)
    log.info('🎯 듀얼엔진 자동 분석 시작')
    log.info(f'📅 {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    log.info(f'📊 모드: {mode} | 제한: {limit or "없음"} | 알림: {notify}')
    log.info('=' * 60)
    
    # ── Step 1: 시장 필터 ──
    log.info('\n[1/5] 📡 시장 필터 데이터 수집...')
    try:
        market_data = fetch_market_filter_data()
    except Exception as e:
        log.error(f'시장 필터 실패: {e}')
        market_data = {
            'us': {'mode': 'defense', 'mode_emoji': '🟡', 'mode_label': '방어 모드 (데이터 없음)', 'health_score': 2, 'spy_12m': 0, 'abs_pass': True, 'vix': 20, 'sectors': [], 'markets': []},
            'kr': {'mode': 'defense', 'mode_emoji': '🟡', 'mode_label': '방어 모드 (데이터 없음)', 'health_score': 2},
        }
    
    # ── Step 2: 종목 선택 ──
    if mode == 'us':
        tickers = {**US_STOCKS, **PORTFOLIO_EXTRA}
    elif mode == 'kr':
        tickers = KR_STOCKS
    else:
        tickers = get_all_tickers()
    
    if limit:
        tickers = dict(list(tickers.items())[:limit])
    
    total = len(tickers)
    log.info(f'\n[2/5] 📊 {total}개 종목 데이터 수집 시작...')
    
    # ── Step 3: 데이터 수집 ──
    raw_data = fetch_batch(tickers)
    log.info(f'  ✅ {len(raw_data)}/{total}개 수집 완료 ({time.time()-start_time:.0f}초)')
    
    # ── Step 4: 듀얼 엔진 분석 ──
    log.info(f'\n[3/5] 🔬 듀얼엔진 분석 중...')
    results = []
    errors = []
    
    for i, (ticker, stock_data) in enumerate(raw_data.items(), 1):
        info = stock_data.get('info', {})
        name = info.get('name', ticker)
        is_kr = '.KS' in ticker or '.KQ' in ticker
        daily = stock_data.get('data', {}).get('daily')
        weekly = stock_data.get('data', {}).get('weekly')
        monthly = stock_data.get('data', {}).get('monthly')
        
        try:
            # 멀티팩터 분석
            mf_result = analyze_stock(ticker, info, stock_data['data'])
            
            # SEPA 분석
            sepa_result = run_sepa_on_stock(ticker, daily, info, is_kr)
            
            # 현재가 & 변동률
            current_price = 0
            change_pct = 0
            if daily is not None and len(daily) >= 2:
                current_price = float(daily['Close'].iloc[-1])
                prev_close = float(daily['Close'].iloc[-2])
                change_pct = ((current_price / prev_close) - 1) * 100 if prev_close > 0 else 0
            
            # 통합 결과
            result = {
                'ticker': ticker,
                'name': name,
                'sector': info.get('sector', '기타'),
                'is_kr': is_kr,
                'current_price': round(current_price, 2) if not is_kr else round(current_price),
                'change_pct': round(change_pct, 2),
                'fundamental_score': info.get('score', 50),
                'breakout_22d': info.get('breakout_22d', False),
                'mf': {
                    'short': {
                        'score': mf_result.get('short_term', {}).get('confluence_score', 0),
                        'dir': mf_result.get('short_term', {}).get('direction', '중립'),
                        'f1': mf_result.get('short_term', {}).get('f1_signal', '중립'),
                        'f2': mf_result.get('short_term', {}).get('f2_signal', '중립'),
                        'f3': mf_result.get('short_term', {}).get('f3_signal', '중립'),
                        'strength': mf_result.get('short_term', {}).get('strength', '중립'),
                        'rsi': mf_result.get('short_term', {}).get('rsi', 50),
                    },
                    'mid': {
                        'score': mf_result.get('mid_term', {}).get('confluence_score', 0),
                        'dir': mf_result.get('mid_term', {}).get('direction', '중립'),
                        'f1': mf_result.get('mid_term', {}).get('f1_signal', '중립'),
                        'f2': mf_result.get('mid_term', {}).get('f2_signal', '중립'),
                        'f3': mf_result.get('mid_term', {}).get('f3_signal', '중립'),
                        'adx': mf_result.get('mid_term', {}).get('adx', 20),
                    },
                    'long': {
                        'score': mf_result.get('long_term', {}).get('confluence_score', 0),
                        'dir': mf_result.get('long_term', {}).get('direction', '중립'),
                        'f1': mf_result.get('long_term', {}).get('f1_signal', '중립'),
                        'f2': mf_result.get('long_term', {}).get('f2_signal', '중립'),
                        'f3': mf_result.get('long_term', {}).get('f3_signal', '중립'),
                    },
                    'total_score': mf_result.get('total_score', 0),
                    'total_dir': mf_result.get('total_direction', '중립'),
                    'alignment': mf_result.get('alignment', {}),
                    'levels': mf_result.get('entry_levels', {}),
                },
                'sepa': sepa_result,
            }
            
            results.append(result)
            
            # 진행 표시 (10종목마다)
            if i % 10 == 0 or i == len(raw_data):
                log.info(f'  [{i}/{len(raw_data)}] 분석 완료...')
        
        except Exception as e:
            errors.append((ticker, name, str(e)))
            log.warning(f'  [{i}] {name} 분석 실패: {e}')
    
    elapsed = time.time() - start_time
    log.info(f'  ✅ {len(results)}개 분석 완료, {len(errors)}개 실패 ({elapsed:.0f}초)')
    
    # ── Step 5: 결과 저장 & 대시보드 ──
    log.info(f'\n[4/5] 💾 결과 저장 & 대시보드 생성...')
    
    # JSON 저장 (대시보드용)
    output_dir = os.path.join(ROOT, 'output')
    os.makedirs(output_dir, exist_ok=True)
    
    combined_data = {'results': results, 'market': market_data}
    json_path = os.path.join(output_dir, 'combined_results.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(combined_data, f, ensure_ascii=False, default=str)
    
    # 히스토리 저장
    save_results(results, market_data)
    
    # HTML 대시보드 생성
    if generate_html:
        try:
            from combined_demo import generate_combined_dashboard
            generate_combined_dashboard(results, market_data, 
                                       os.path.join(output_dir, 'combined_dashboard.html'))
            log.info(f'  ✅ 대시보드 생성 완료')
        except Exception as e:
            log.warning(f'  ⚠️ 대시보드 생성 실패 (기존 JSON으로 대체): {e}')
    
    # ── Step 6: 알림 전송 ──
    if notify:
        log.info(f'\n[5/5] 📢 알림 전송 중...')
        prev_results = load_previous_results()
        try:
            sent = send_all(results, market_data, prev_results)
            for channel, ok in sent:
                log.info(f'  {channel}: {"✅" if ok else "❌"}')
        except Exception as e:
            log.error(f'  알림 전송 실패: {e}')
    
    # 오래된 히스토리 정리
    cleanup_old_history(keep_days=60)
    
    # ── 최종 요약 ──
    total_time = time.time() - start_time
    sepa_buys = [r for r in results if '🟢' in r.get('sepa', {}).get('verdict', '')]
    sepa_watch = [r for r in results if '🟡' in r.get('sepa', {}).get('verdict', '')]
    mf_strong = [r for r in results if r.get('mf', {}).get('total_score', 0) >= 2.0]
    
    log.info('\n' + '=' * 60)
    log.info('📊 분석 완료 요약')
    log.info('=' * 60)
    log.info(f'  분석 종목: {len(results)}개 ({len(errors)}개 실패)')
    log.info(f'  SEPA 매수준비: {len(sepa_buys)}개')
    log.info(f'  SEPA 워치리스트: {len(sepa_watch)}개')
    log.info(f'  MF 강매수: {len(mf_strong)}개')
    log.info(f'  소요시간: {total_time:.0f}초 ({total_time/60:.1f}분)')
    log.info(f'  결과: {json_path}')
    log.info('=' * 60)
    
    return results, market_data


# ============================================================
# CLI 실행
# ============================================================
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='듀얼엔진 자동 분석기')
    parser.add_argument('--mode', choices=['all', 'us', 'kr'], default='all',
                        help='분석 모드: all=전체, us=미국만, kr=한국만')
    parser.add_argument('--limit', type=int, default=None,
                        help='종목 수 제한 (테스트용)')
    parser.add_argument('--no-notify', action='store_true',
                        help='알림 전송 건너뛰기')
    parser.add_argument('--no-html', action='store_true',
                        help='대시보드 생성 건너뛰기')
    parser.add_argument('--test-notify', action='store_true',
                        help='알림 시스템만 테스트')
    
    args = parser.parse_args()
    
    if args.test_notify:
        from notifier import send_all
        # 테스트용 더미 데이터
        test_results = [{
            'ticker': 'TEST', 'name': '테스트종목', 'sector': 'IT',
            'is_kr': False, 'current_price': 100, 'change_pct': 2.5,
            'mf': {'total_score': 2.5, 'total_dir': '매수',
                    'short': {'score': 3}, 'mid': {'score': 2}, 'long': {'score': 2},
                    'alignment': {'bonus': True}},
            'sepa': {'verdict': '🟢 매수준비', 'template': {'score': 8},
                     'vcp': {'score': 6, 'pivot': 102},
                     'rs': {'outperform': True, 'stock_6m': 25, 'stock_3m': 12},
                     'trade': {'entry': 102, 'stop': 95, 'target1': 117, 'target2': 133, 'rr': '2.1'}},
        }]
        test_market = {
            'us': {'mode': 'attack', 'mode_emoji': '🟢', 'mode_label': '공격 모드', 'health_score': 3},
            'kr': {'mode': 'attack', 'mode_emoji': '🟢', 'mode_label': '공격 모드', 'health_score': 3},
        }
        send_all(test_results, test_market)
    else:
        run_full_pipeline(
            mode=args.mode,
            limit=args.limit,
            notify=not args.no_notify,
            generate_html=not args.no_html,
        )

"""
데이터 수집 모듈 — yfinance 기반
일봉/주봉/월봉 OHLCV 데이터를 수집하고 캐싱
"""
import yfinance as yf
import pandas as pd
import os
import json
from datetime import datetime, timedelta

CACHE_DIR = os.path.join(os.path.dirname(__file__), "cache")

def ensure_cache_dir():
    os.makedirs(CACHE_DIR, exist_ok=True)

def get_cache_path(ticker, interval):
    safe_ticker = ticker.replace(".", "_").replace("/", "_")
    return os.path.join(CACHE_DIR, f"{safe_ticker}_{interval}.pkl")

def is_cache_fresh(path, max_age_hours=12):
    if not os.path.exists(path):
        return False
    mtime = os.path.getmtime(path)
    age = datetime.now().timestamp() - mtime
    return age < max_age_hours * 3600

def fetch_single(ticker, period="2y", interval="1d", use_cache=True):
    """단일 종목 데이터 수집"""
    ensure_cache_dir()
    cache_path = get_cache_path(ticker, interval)
    
    if use_cache and is_cache_fresh(cache_path):
        try:
            return pd.read_pickle(cache_path)
        except:
            pass
    
    try:
        data = yf.download(ticker, period=period, interval=interval, progress=False, auto_adjust=True)
        if data is not None and len(data) > 0:
            # Handle multi-level columns from yfinance
            if isinstance(data.columns, pd.MultiIndex):
                data.columns = data.columns.get_level_values(0)
            data.to_pickle(cache_path)
            return data
    except Exception as e:
        print(f"  ⚠️ {ticker} 다운로드 실패: {e}")
    
    return None

def fetch_multi_timeframe(ticker):
    """
    하나의 종목에 대해 3개 타임프레임 데이터를 한번에 수집
    Returns: dict with keys 'daily', 'weekly', 'monthly'
    """
    result = {}
    
    # 단기: 6개월 일봉
    result['daily'] = fetch_single(ticker, period="1y", interval="1d")
    
    # 중기: 2년 주봉
    result['weekly'] = fetch_single(ticker, period="3y", interval="1wk")
    
    # 장기: 10년 월봉
    result['monthly'] = fetch_single(ticker, period="10y", interval="1mo")
    
    return result

def fetch_batch(tickers_dict, max_workers=5):
    """
    여러 종목 일괄 수집 (순차 처리 — API rate limit 고려)
    """
    results = {}
    total = len(tickers_dict)
    
    for i, (ticker, info) in enumerate(tickers_dict.items(), 1):
        name = info.get('name', ticker)
        print(f"  [{i}/{total}] {name} ({ticker}) 데이터 수집중...")
        
        data = fetch_multi_timeframe(ticker)
        
        # 최소 일봉 데이터가 있어야 유효
        if data.get('daily') is not None and len(data['daily']) > 20:
            results[ticker] = {
                'info': info,
                'data': data
            }
        else:
            print(f"  ⚠️ {name} ({ticker}) — 데이터 부족, 건너뜀")
    
    return results

def get_current_price(df):
    """데이터프레임에서 최신 종가 추출"""
    if df is None or len(df) == 0:
        return None
    return float(df['Close'].iloc[-1])

def get_price_info(daily_df):
    """기본 가격 정보 추출"""
    if daily_df is None or len(daily_df) < 2:
        return {}
    
    close = daily_df['Close']
    return {
        'current_price': float(close.iloc[-1]),
        'prev_close': float(close.iloc[-2]),
        'change_pct': float((close.iloc[-1] / close.iloc[-2] - 1) * 100),
        'high_22d': float(close.tail(22).max()) if len(close) >= 22 else float(close.max()),
        'low_22d': float(close.tail(22).min()) if len(close) >= 22 else float(close.min()),
        'high_50d': float(close.tail(50).max()) if len(close) >= 50 else float(close.max()),
        'low_50d': float(close.tail(50).min()) if len(close) >= 50 else float(close.min()),
    }

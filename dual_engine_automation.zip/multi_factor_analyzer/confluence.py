"""
컨플루언스 스코어링 엔진
3-Factor 교차 검증 및 점수 산출
"""

def score_signal(signal):
    """신호를 숫자로 변환: 매수=1, 중립=0, 매도=-1"""
    if signal == '매수':
        return 1
    elif signal == '매도':
        return -1
    return 0

def calc_confluence(f1_signal, f2_signal, f3_signal):
    """
    3개 팩터 신호로 컨플루언스 점수 계산
    Returns: (score, direction, grade)
    """
    signals = [score_signal(f1_signal), score_signal(f2_signal), score_signal(f3_signal)]
    total = sum(signals)
    
    buy_count = signals.count(1)
    sell_count = signals.count(-1)
    neutral_count = signals.count(0)
    
    if buy_count == 3:
        return 3, '매수', '⭐ 강한 매수'
    elif sell_count == 3:
        return 3, '매도', '⭐ 강한 매도'
    elif buy_count == 2:
        return 2, '매수', '✅ 매수 우세'
    elif sell_count == 2:
        return 2, '매도', '✅ 매도 우세'
    elif buy_count == 1 and sell_count == 0:
        return 1, '매수', '⚠️ 약한 매수'
    elif sell_count == 1 and buy_count == 0:
        return 1, '매도', '⚠️ 약한 매도'
    else:
        return 0, '중립', '❌ 관망'

def analyze_stock(ticker, info, data):
    """단일 종목 전체 분석 실행"""
    from factors.price_structure import (
        analyze_short_term_structure,
        analyze_mid_term_structure,
        analyze_long_term_structure
    )
    from factors.volume_profile import (
        analyze_short_term_volume,
        analyze_mid_term_volume,
        analyze_long_term_volume
    )
    from factors.momentum import (
        analyze_short_term_momentum,
        analyze_mid_term_momentum,
        analyze_long_term_momentum
    )
    
    daily = data.get('daily')
    weekly = data.get('weekly')
    monthly = data.get('monthly')
    
    # === 단기 분석 ===
    short_f1 = analyze_short_term_structure(daily)
    short_f2 = analyze_short_term_volume(daily)
    short_f3 = analyze_short_term_momentum(daily)
    short_score, short_dir, short_grade = calc_confluence(
        short_f1['signal'], short_f2['signal'], short_f3['signal']
    )
    
    # === 중기 분석 ===
    mid_f1 = analyze_mid_term_structure(weekly)
    mid_f2 = analyze_mid_term_volume(weekly)
    mid_f3 = analyze_mid_term_momentum(weekly)
    mid_score, mid_dir, mid_grade = calc_confluence(
        mid_f1['signal'], mid_f2['signal'], mid_f3['signal']
    )
    
    # === 장기 분석 ===
    long_f1 = analyze_long_term_structure(monthly)
    long_f2 = analyze_long_term_volume(monthly)
    long_f3 = analyze_long_term_momentum(monthly)
    long_score, long_dir, long_grade = calc_confluence(
        long_f1['signal'], long_f2['signal'], long_f3['signal']
    )
    
    # === 타임프레임 간 정렬 ===
    alignment = _check_alignment(short_dir, mid_dir, long_dir)
    
    # === 진입가/손절가/목표가 산출 ===
    levels = _calc_trade_levels(daily, weekly, monthly, short_f1, mid_f1, long_f1, short_f2, short_f3)
    
    current_price = float(daily['Close'].iloc[-1]) if daily is not None and len(daily) > 0 else 0
    
    return {
        'ticker': ticker,
        'name': info.get('name', ticker),
        'sector': info.get('sector', ''),
        'fundamental_score': info.get('score', 0),
        'current_price': current_price,
        
        'short_term': {
            'f1': short_f1, 'f2': short_f2, 'f3': short_f3,
            'score': short_score, 'direction': short_dir, 'grade': short_grade,
        },
        'mid_term': {
            'f1': mid_f1, 'f2': mid_f2, 'f3': mid_f3,
            'score': mid_score, 'direction': mid_dir, 'grade': mid_grade,
        },
        'long_term': {
            'f1': long_f1, 'f2': long_f2, 'f3': long_f3,
            'score': long_score, 'direction': long_dir, 'grade': long_grade,
        },
        
        'alignment': alignment,
        'levels': levels,
        
        # 종합 점수 (가중 평균: 장기 40%, 중기 35%, 단기 25%)
        'total_score': round(
            long_score * 0.4 + mid_score * 0.35 + short_score * 0.25, 2
        ),
        'total_direction': _overall_direction(short_dir, mid_dir, long_dir),
    }

def _check_alignment(short_dir, mid_dir, long_dir):
    """타임프레임 간 정렬 상태"""
    dirs = [short_dir, mid_dir, long_dir]
    
    if all(d == '매수' for d in dirs):
        return {'status': '완전 정렬 (매수)', 'bonus': True, 'conflict': False}
    elif all(d == '매도' for d in dirs):
        return {'status': '완전 정렬 (매도)', 'bonus': True, 'conflict': False}
    elif long_dir != short_dir and long_dir != '중립' and short_dir != '중립':
        return {'status': f'⚠️ 충돌 (장기:{long_dir} vs 단기:{short_dir})', 'bonus': False, 'conflict': True}
    else:
        return {'status': '부분 정렬', 'bonus': False, 'conflict': False}

def _overall_direction(short_dir, mid_dir, long_dir):
    """종합 방향 판정 (상위 TF 우선)"""
    # 장기 우선
    if long_dir != '중립':
        if mid_dir == long_dir:
            return long_dir
        elif mid_dir == '중립':
            return long_dir
    
    if mid_dir != '중립':
        return mid_dir
    
    return short_dir

def _calc_trade_levels(daily, weekly, monthly, short_f1, mid_f1, long_f1, short_f2, short_f3):
    """진입가, 손절가, 목표가 산출"""
    levels = {}
    
    if daily is not None and len(daily) > 0:
        current = float(daily['Close'].iloc[-1])
        
        # 단기 레벨
        short_support = short_f1.get('support', [])
        short_resist = short_f1.get('resistance', [])
        bb_lower = short_f3.get('bb_lower', current * 0.97)
        bb_upper = short_f3.get('bb_upper', current * 1.03)
        vwap_lower = short_f2.get('vwap_lower', current * 0.98)
        
        # 단기 진입가: OB 하단 또는 VWAP 하단 중 높은 값
        short_entry = max(short_support[-1] if short_support else current * 0.98, vwap_lower)
        short_stop = short_entry * 0.97  # 3% 손절
        short_target = min(short_resist[0] if short_resist else current * 1.05, bb_upper)
        
        risk = short_entry - short_stop
        reward = short_target - short_entry
        short_rr = round(reward / risk, 2) if risk > 0 else 0
        
        levels['short'] = {
            'entry': round(short_entry, 2),
            'stop': round(short_stop, 2),
            'target': round(short_target, 2),
            'rr': short_rr,
        }
    
    if weekly is not None and len(weekly) > 0:
        current = float(weekly['Close'].iloc[-1])
        fib = mid_f1.get('fibonacci', {})
        ma20w = mid_f1.get('ma20w', current * 0.95)
        
        mid_entry = fib.get('0.5', current * 0.95)
        mid_stop = min(fib.get('0.786', current * 0.9), ma20w * 0.97)
        mid_target = fib.get('1.272', current * 1.15) if isinstance(fib.get('1.272'), (int, float)) else current * 1.15
        
        # 1.272와 0.0(swing high) 중 적절한 값
        swing_high = mid_f1.get('swing_high', current * 1.1)
        mid_target = max(swing_high, mid_target) if mid_target else swing_high
        
        risk = mid_entry - mid_stop
        reward = mid_target - mid_entry
        mid_rr = round(reward / risk, 2) if risk > 0 else 0
        
        levels['mid'] = {
            'entry': round(mid_entry, 2),
            'stop': round(mid_stop, 2),
            'target': round(mid_target, 2),
            'rr': mid_rr,
        }
    
    if monthly is not None and len(monthly) > 0:
        current = float(monthly['Close'].iloc[-1])
        ma60 = long_f1.get('ma60m', current * 0.8)
        ath = long_f1.get('all_time_high', current * 1.5)
        atl = long_f1.get('all_time_low', current * 0.5)
        
        long_entry = ma60
        long_stop = atl * 1.05 if atl < ma60 else ma60 * 0.85
        long_target = ath
        
        risk = long_entry - long_stop
        reward = long_target - long_entry
        long_rr = round(reward / risk, 2) if risk > 0 else 0
        
        levels['long'] = {
            'entry': round(long_entry, 2),
            'stop': round(long_stop, 2),
            'target': round(long_target, 2),
            'rr': long_rr,
        }
    
    return levels
